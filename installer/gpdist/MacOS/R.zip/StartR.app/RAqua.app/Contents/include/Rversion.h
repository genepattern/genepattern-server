/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H
#define R_VERSION 67585
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "1"
#define R_MINOR  "8.1"
#define R_STATUS ""
#define R_YEAR   "2003"
#define R_MONTH  "11"
#define R_DAY    "21"
#define R_FILEVERSION    1,81,31121,0
#endif /* not R_VERSION_H */
