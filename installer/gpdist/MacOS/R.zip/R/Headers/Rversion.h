/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 131073
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "2"
#define R_MINOR  "0.1"
#define R_STATUS ""
#define R_YEAR   "2004"
#define R_MONTH  "11"
#define R_DAY    "15"
#define R_FILEVERSION    2,01,41115,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
