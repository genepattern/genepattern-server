/* Rconfig.h.  Generated automatically */
#ifndef R_CONFIG_H
#define R_CONFIG_H

#ifndef _CONFIG_H

#define HAVE_F77_UNDERSCORE 1
#define IEEE_754 1
#define WORDS_BIGENDIAN 1
#define HAVE_WORKING_ISFINITE 1
#define R_INLINE inline

#endif /* not _CONFIG_H */

#endif /* not R_CONFIG_H */
