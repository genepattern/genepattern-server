/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 132352
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "2"
#define R_MINOR  "5.0"
#define R_STATUS ""
#define R_YEAR   "2007"
#define R_MONTH  "04"
#define R_DAY    "23"
#define R_SVN_REVISION "41293"
#define R_FILEVERSION    2,50,41293,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
