/* This is an automatically generated universal stub for architecture-dependent headers. */
#ifdef __i386__
#include <i386/Rconfig.h>
#else
#ifdef __ppc__
#include <ppc/Rconfig.h>
#else
#ifdef __ppc64__
#include <ppc64/Rconfig.h>
#else
#ifdef __x86_64__
#include <x86_64/Rconfig.h>
#else
#error Cannot determine the correct architecture. To force a certain configuration, include architecture-specific include path *before* general R headers path.
#endif
#endif
#endif
#endif
