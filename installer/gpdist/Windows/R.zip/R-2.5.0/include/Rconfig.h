/* Rconfig.h.  Generated automatically */
#ifndef R_RCONFIG_H
#define R_RCONFIG_H

#ifndef R_CONFIG_H

#define HAVE_F77_UNDERSCORE 1
#define IEEE_754 1
/* #undef WORDS_BIGENDIAN */
#define HAVE_WORKING_ISFINITE 1
#define R_INLINE inline
/* #undef HAVE_VISIBILITY_ATTRIBUTE */
/* #undef SUPPORT_UTF8 */
#define SUPPORT_MBCS 1
#define ENABLE_NLS 1

#endif /* not R_CONFIG_H */

#endif /* not R_RCONFIG_H */
