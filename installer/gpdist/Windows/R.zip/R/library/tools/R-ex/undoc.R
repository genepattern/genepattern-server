### Name: undoc
### Title: Find Undocumented Objects
### Aliases: undoc print.undoc
### Keywords: documentation

### ** Examples

undoc("tools")                  # Undocumented objects in 'tools'



