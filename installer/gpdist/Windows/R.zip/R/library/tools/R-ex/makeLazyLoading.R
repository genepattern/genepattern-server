### Name: makeLazyLoading
### Title: Lazy Loading of Packages
### Aliases: makeLazyLoading
### Keywords: utilities

### ** Examples

  # set up package "splines" for lazy loading -- already done
  ## Not run: 
##D     tools:::makeLazyLoading("splines")
##D   
## End(Not run)



