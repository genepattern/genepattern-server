### Name: write.foreign
### Title: Write text files and code to read them.
### Aliases: write.foreign
### Keywords: file

### ** Examples

## Not run: 
##D datafile<-tempfile()
##D codefile<-tempfile()
##D write.foreign(esoph,datafile,codefile,package="SPSS")
##D file.show(datafile)
##D file.show(codefile)
##D unlink(datafile)
##D unlink(codefile)
## End(Not run)



