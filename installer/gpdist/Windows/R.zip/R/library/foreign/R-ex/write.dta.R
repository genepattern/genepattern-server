### Name: write.dta
### Title: Write Files in Stata Binary Format
### Aliases: write.dta
### Keywords: file

### ** Examples

write.dta(swiss, swissfile <- tempfile())
read.dta(swissfile)



