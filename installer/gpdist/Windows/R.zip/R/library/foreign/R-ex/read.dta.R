### Name: read.dta
### Title: Read Stata binary files
### Aliases: read.dta
### Keywords: file

### ** Examples

data(swiss)
write.dta(swiss,swissfile<-tempfile())
read.dta(swissfile)



