### Name: lookup.xport
### Title: Lookup information on a SAS XPORT format library
### Aliases: lookup.xport
### Keywords: file

### ** Examples

## Not run: 
##D lookup.xport("transport")
## End(Not run)



