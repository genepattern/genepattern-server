### Name: read.xport
### Title: Read a SAS XPORT format library
### Aliases: read.xport
### Keywords: file

### ** Examples

## Not run: 
##D read.xport("transport")
## End(Not run)



