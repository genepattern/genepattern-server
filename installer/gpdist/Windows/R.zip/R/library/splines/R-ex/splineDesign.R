### Name: splineDesign
### Title: Design Matrix for B-splines
### Aliases: splineDesign spline.des
### Keywords: models

### ** Examples

splineDesign(knots = 1:10, x = 4:7)



