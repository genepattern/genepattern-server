### Name: lvqtest
### Title: Classify Test Set from LVQ Codebook
### Aliases: lvqtest
### Keywords: classif

### ** Examples

# The function is currently defined as
function(codebk, test) knn1(codebk$x, test, codebk$cl)



