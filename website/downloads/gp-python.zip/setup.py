from distutils.core import setup

setup(name='gp', version='1.0', py_modules=['gp'])