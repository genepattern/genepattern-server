#!/bin/sh
#
# Script for running jdnc applications
# 
# Usage: run.sh 

if [ $# -eq 0 ]; then
    echo "Usage: ${0##/*/} <filename> <logging>"
    echo "Where:"
    echo " <filename> : relative path to a .jdnc file"
    echo " <logging>  : Logging level [ severe | warning | info | fine ] default is warning"
    exit 0
fi

FILENAME=$1
LEVEL=$2

ant -emacs -f make/run.xml -Djdnc.file=$FILENAME -Djdnc.log.level=${LEVEL:=info}
