JDesktop Network Components
===========================

Requirements
------------
- Ant 1.6.0 or greater http://ant.apache.org
- JUnit 3.8.1 or greater http://www.junit.org

Note: The junit jar should be installed in the $ANT_HOME/lib directory.

Edit the build.properties file
------------------------------
Edit the valies in the jdnc/make/build.properties to reflect your
environment

Directory Structure
-------------------
There are 3 distinct sub-projects within the JDNC project.

swingx		JFC/Swing extensions. This project contains classes that
		extend the JFC/Swing apis.

jdnc_api	These represent the simple JDNC components.

jdnc_markup	Support classes for the Object Realizer which transforms
		the xml jdnc documents into Java object graphs.


make		Contains the common build scripts.

www		Web site documentation for this project.

deployment	Scripts and documents for deploying to javadesktop.org

All sub-projects require the 'make' directory. There are dependencies
within the sub-projects as well. The jdnc_api project depends on the swingx
project. The jdnc_markup project depends on the jdnc_api project.

Within each sub-project, the directory structures are as follows:

lib    Sub-project specific 3rd party libraries
src    Files requires to build the binaries
make   Ant build commands
docs   Documentation for the project
test   Test cases and data

build and dist directories are created within each sub-project and the top level
project. These directories will be deleted using the 'clean' target

How to Build
------------
Change to the 'JDNC_ROOT/make' directory. Type 'ant'.

If you make changes to a sub-project, then go into the make directory of that
project and type 'ant'.

How to run
----------
The JDNC root directory contains a run.sh or run.bat script which will allow you
to execute a JDNC application written in the JDNC XML markup language. There
are many demos in the jdnc_markup/demo that you can run to explore the JDNC markup
language.

For example, to show the simple table demo on Linux, invoke the command from
the JDNC_ROOT directory:

$ ./run jdnc_markup/demo/simpleTable.jdnc


