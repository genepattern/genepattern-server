/*
 * $Id: BaseAttribute.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.RealizationUtils;

/**
 * A utility class to abstract the resolution of referenced objects. This probably belongs
 * somewhere else. Perhaps in the org.jdesktop.jdnc.markup package.
 */
public class BaseAttribute {

    /**
     * This method insulates the ObjectRealizer implementation to get the Realized Object
     * from the Element that has been referenced by the attributeValue.
     */
    public static Object getReferencedObject(Realizable target, String attributeValue) {
	return RealizationUtils.getReferencedObject(target, attributeValue);
    }

    public static Element getReferencedElement(Realizable target,
                                               String attributeValue) {
	return RealizationUtils.getReferencedElement(target, attributeValue);
    }

}
