/*
 * $Id: AlternateRowsElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Map;

import org.w3c.dom.Element;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.*;

/**
 *
 * @author Ramesh Gupta
 */
public class AlternateRowsElement extends HighlighterElement {
    public AlternateRowsElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.ODD_ROW_BACKGROUND);
        applyAttribute(Namespace.JDNC, Attributes.EVEN_ROW_BACKGROUND);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           Attributes.EVEN_ROW_BACKGROUND,
                           evenRowBackgroundAttrHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ODD_ROW_BACKGROUND,
                           oddRowBackgroundAttrHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler	evenRowBackgroundAttrHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.EVEN_ROW_BACKGROUND,
                             HighlighterAttributes.evenRowBackgroundApplier);
    private static final AttributeHandler	oddRowBackgroundAttrHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ODD_ROW_BACKGROUND,
                             HighlighterAttributes.oddRowBackgroundApplier);
}
