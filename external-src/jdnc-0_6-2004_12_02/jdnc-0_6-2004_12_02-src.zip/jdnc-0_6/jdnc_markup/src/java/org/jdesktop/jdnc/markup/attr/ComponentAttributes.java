/*
 * $Id: ComponentAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JComponent;

import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;

/**
 * @author Ramesh Gupta
 * @author Amy Fowler
 */
public class ComponentAttributes {

    public static void applyBackground(Component component, String attributeValue) {
        Color value = Decoder.decodeColor(attributeValue);
        if (value != null) {
            component.setBackground(value);
        }
    }

    public static void applyForeground(Component component, String attributeValue) {
        Color value = Decoder.decodeColor(attributeValue);
         if (value != null) {
             component.setForeground(value);
         }
    }

    // ...

    public static final AttributeApplier backgroundApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            applyBackground((Component)target.getObject(), attributeValue);
        }
    };

    public static final AttributeApplier	isEnabledApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Component	component = (Component) target.getObject();
            boolean		isEnabled = Boolean.valueOf(attributeValue).booleanValue();
            component.setEnabled(isEnabled);
        }
    };

    public static final AttributeApplier	isVisibleApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Component	component = (Component) target.getObject();
            boolean		isVisible = Boolean.valueOf(attributeValue).booleanValue();
            component.setVisible(isVisible);
        }
    };

    public static final AttributeApplier	fontApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Component	component = (Component) target.getObject();
            Font font = (Font)BaseAttribute.getReferencedObject(target, attributeValue);
            component.setFont(font);
        }
    };

    public static final AttributeApplier foregroundApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            applyForeground( (Component) target.getObject(), attributeValue);
        }
    };

    public static final AttributeApplier nameApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            JComponent component = (JComponent) target.getObject();
            component.setName(attributeValue);
        }
     };

     public static final AttributeApplier	preferredSizeApplier = new AttributeApplier() {
         public void apply(Realizable target, String namespaceURI,
                           String attributeName, String attributeValue) {
             String[]		args = attributeValue.split("\\s");
             if (args.length == 2) {
                 Dimension	size = new Dimension(
                     Integer.parseInt(args[0]), Integer.parseInt(args[1]));
                 JComponent	component = (JComponent) target.getObject();
                 component.setPreferredSize(size);
             }
         }
    };

    public static final AttributeApplier sizeApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            String[]		args = attributeValue.split("\\s");
            if (args.length == 2) {
                Dimension	size = new Dimension(
                    Integer.parseInt(args[0]), Integer.parseInt(args[1]));
                JComponent	component = (JComponent) target.getObject();
                component.setSize(size);
            }
        }
    };

    // ...
}
