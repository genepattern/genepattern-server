/*
 * $Id: DataFieldAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;


import org.jdesktop.swing.data.Converters;
import org.jdesktop.swing.data.Converter;
import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.NumberMetaData;
import org.jdesktop.swing.data.StringMetaData;
import org.jdesktop.swing.table.TabularDataMetaData;

import java.text.SimpleDateFormat;

import java.util.Date;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.elem.ElementProxy;

/**
 * @author Amy Fowler
 */
public class DataFieldAttributes {

    public static final AttributeApplier	typeApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            MetaData	metaData = (MetaData) target.getObject();
            Class klass = Decoder.decodeType(attributeValue);
            if (klass != null) {
                metaData.setElementClass(klass);
            }
        }
    };

    public static final AttributeApplier	decodeFormatApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            MetaData	metaData = (MetaData) target.getObject();
            if (metaData.getElementClass() == Date.class) {
                metaData.setDecodeFormat(new SimpleDateFormat(attributeValue));
            }
            /**@todo aim: should the "else" generate a warning? */
        }
    };

    public static final AttributeApplier	encodeFormatApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            MetaData	metaData = (MetaData) target.getObject();
            if (metaData.getElementClass() == Date.class) {
                metaData.setEncodeFormat(new SimpleDateFormat(attributeValue));
            }
            /**@todo aim: should the "else" generate a warning? */
        }
    };


    public static final AttributeApplier	titleApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            MetaData	metaData = (MetaData) target.getObject();
            metaData.setLabel(attributeValue);
        }
    };

    public static final AttributeApplier	displaySizeApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            StringMetaData	metaData = (StringMetaData) target.getObject();
            try {
                metaData.setDisplayWidth(Integer.parseInt(attributeValue));
            } catch (Exception ex) {
                System.out.println("DataElementAttributes.displayWidthApplier: " + ex);
            }
        }
    };

    public static final AttributeApplier	maximumApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            try {
                NumberMetaData	metaData = (NumberMetaData) target.getObject();
                /**@todo aim: handle other number types */
                metaData.setMaximum(new Integer(Integer.parseInt(attributeValue)));
            } catch (Exception ex) {
                System.out.println("DataElementAttributes.maximumApplier: " + ex);
            }
        }
    };

    public static final AttributeApplier	maximumFieldSizeApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            try {
                StringMetaData	metaData = (StringMetaData) target.getObject();
                /**@todo aim: handle other number types */
                metaData.setMaxLength(Integer.parseInt(attributeValue));
            } catch (Exception ex) {
                System.out.println("DataElementAttributes.maximumLengthApplier: " + ex);
            }
        }
    };

    public static final AttributeApplier	minimumApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            try {
                NumberMetaData	metaData = (NumberMetaData) target.getObject();
                /**@todo aim: handle other number types */
                metaData.setMinimum(new Integer(Integer.parseInt(attributeValue)));
            } catch (Exception ex) {
                System.out.println("DataElementAttributes.minimumApplier: " + ex);
            }
        }
    };

    public static final AttributeApplier	minimumFieldSizeApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            try {
                StringMetaData	metaData = (StringMetaData) target.getObject();
                /**@todo aim: handle other number types */
                metaData.setMinLength(Integer.parseInt(attributeValue));
            } catch (Exception ex) {
                System.out.println("DataElementAttributes.minimumLengthApplier: " + ex);
            }
        }
    };

    public static final AttributeApplier	multiLineApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            try {
                StringMetaData	metaData = (StringMetaData) target.getObject();
                metaData.setMultiLine(Boolean.valueOf(attributeValue).booleanValue());
            } catch (Exception ex) {
                System.out.println("DataElementAttributes.multiLineApplier: " + ex);
            }
        }
    };

    public static final AttributeApplier	nameApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            MetaData	metaData = (MetaData) target.getObject();
            metaData.setName(attributeValue);
        }
    };

    public static final AttributeApplier	isReadOnlyApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            MetaData	metaData = (MetaData) target.getObject();
            metaData.setReadOnly(Boolean.valueOf(attributeValue).booleanValue());
        }
    };

    public static final AttributeApplier	isRequiredApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            MetaData	metaData = (MetaData) target.getObject();
            metaData.setRequired(Boolean.valueOf(attributeValue).booleanValue());
        }
    };


}
