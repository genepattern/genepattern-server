/*
 * $Id: EditorElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import org.w3c.dom.Element;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.EditorAttributes;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;

public class EditorElement
    extends ComponentElement {
    private static final Map attrMap = new Hashtable();

    public EditorElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SOURCE,
                           sourceHandler);
        }
        return handlerMap;
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.SOURCE);
    }

    private static final AttributeHandler sourceHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SOURCE,
                             EditorAttributes.sourceApplier);

}