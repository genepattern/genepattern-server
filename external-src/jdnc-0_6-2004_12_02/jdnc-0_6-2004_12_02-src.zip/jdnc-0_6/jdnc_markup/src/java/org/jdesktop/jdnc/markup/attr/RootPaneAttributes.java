/*
 * $Id: RootPaneAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.swing.Application;

import java.awt.BorderLayout;

import javax.swing.JComponent;
import javax.swing.JRootPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Document;
import net.openmarkup.Realizable;

/**
 * @author Amy Fowler
 */
public class RootPaneAttributes {
    public static final AttributeApplier appApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) 
	    throws ApplierException {
            Application app = (Application)BaseAttribute.getReferencedObject(target, 
									     attributeValue);
            JRootPane rootPane = (JRootPane) target.getObject();
            rootPane.putClientProperty("Application", app);
        }
    };
     // ...
}
