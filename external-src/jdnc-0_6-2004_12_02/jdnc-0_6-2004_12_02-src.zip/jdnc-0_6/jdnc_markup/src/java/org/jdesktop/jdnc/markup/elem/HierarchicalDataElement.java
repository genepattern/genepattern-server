/*
 * $Id: HierarchicalDataElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.HierarchicalDataAttributes;

/**
 *
 * @author Ramesh Gupta
 */
public class HierarchicalDataElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();
    private static final Map	elementMap = new Hashtable();
    private static final Map	mediaTypeRepresentation = new Hashtable();

    public HierarchicalDataElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.SOURCE);
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SOURCE, sourceHandler);
        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.META_DATA.getLocalName(),
                           metaDataElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator metaDataAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {

        }
    };

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }


    private static final AttributeHandler	sourceHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SOURCE, HierarchicalDataAttributes.sourceApplier);

    private static final ElementHandler		metaDataElementHandler =
        new ElementHandler(ElementTypes.META_DATA, metaDataAssimilator);

}
