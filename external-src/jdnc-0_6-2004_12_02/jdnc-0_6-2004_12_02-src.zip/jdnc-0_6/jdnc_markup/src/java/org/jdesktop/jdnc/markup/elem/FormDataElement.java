/*
 * $Id: FormDataElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.data.DefaultDataModel;
import org.jdesktop.swing.data.MetaData;

import org.jdesktop.jdnc.JNForm;

import java.io.IOException;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.DataAttributes;
import org.jdesktop.jdnc.markup.attr.NullAttribute;

/**
 *
 * @author Amy Fowler
 */
public class FormDataElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();
    private static final Map	elementMap = new Hashtable();
    private static final Map	mediaTypeRepresentation = new Hashtable();

    public FormDataElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

/*
    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        //applyAttribute(Namespace.JDNC, Attributes.COLUMN_DELIMITER);
    }
*/

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            //handlerMap.put(Namespace.JDNC + ":" + Attributes.COLUMN_DELIMITER, columnDelimiterHandler);
	    // Register null appliers. These attributes are handled elsewhere
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ID,
                           NullAttribute.idHandler);

        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                         ElementTypes.META_DATA.getLocalName(),
                         metaDataElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator metaDataAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            DefaultDataModel data = (DefaultDataModel)parent.getObject();
            List	list = (List) child.getObject();
            for (int i = 0; i < list.size(); i++) {
                MetaData metaData = (MetaData) list.get(i);
                data.addField(metaData);
            }
        }
    };

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    private static final ElementHandler		metaDataElementHandler =
        new ElementHandler(ElementTypes.META_DATA, metaDataAssimilator);

}
