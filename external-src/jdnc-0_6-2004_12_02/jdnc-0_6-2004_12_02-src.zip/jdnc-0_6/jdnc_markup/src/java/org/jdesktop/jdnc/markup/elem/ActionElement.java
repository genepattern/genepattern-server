/*
 * $Id: ActionElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import javax.swing.Action;

import org.w3c.dom.Element;
import org.jdesktop.swing.Application;
import org.jdesktop.swing.actions.ActionManager;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.RealizationUtils;
import org.jdesktop.jdnc.markup.attr.ActionAttributes;
import org.jdesktop.jdnc.markup.attr.NullAttribute;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;

/**
 *
 * @author Ramesh Gupta
 * @author Mark Davidson
 */
public class ActionElement
    extends ElementProxy {
    private static final Map attrMap = new Hashtable();

    public ActionElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Object instantiate() {
        Action action;
        String id = this.getAttributeNSOptional(Namespace.JDNC,
                                                Attributes.ACTION_REF);
        if (id.length() > 0) {
            // Look in defs,
            action = (Action) RealizationUtils.getReferencedObject(this, id);
            if (action == null) {
                throw new RuntimeException(id + " action not found");
            }
        }
        else {
            action = (Action)super.instantiate();

			// RG: XML namespace prefix required for id attribute
            id = this.getAttribute("xml:id");
            if (id.equals("")) {
                // This cannot be empty
                id = (String) action.getValue(Action.NAME);
            }

            /*TODO: Should peek ahead to see if the <exec> element exists
              to create a bound action
              NodeList list = getElementsByTagname("exec");
              if (list.getLength != 0) {
                  action = new BoundAction();
                     } else {
                  action = new TargetableAction();
                     }
             */

            ActionManager manager = Application.getInstance().getActionManager();
            action.putValue(Action.ACTION_COMMAND_KEY, id);
            manager.addAction(action);
        }
        return action;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.DELEGATE);
        //applyAttribute(Namespace.JDNC, Attributes.ID);
        applyAttribute(Namespace.JDNC, Attributes.IS_TOGGLE);
        applyAttribute(Namespace.JDNC, Attributes.GROUP);
        applyAttribute(Namespace.JDNC, Attributes.TITLE);
        applyAttribute(Namespace.JDNC, Attributes.MNEMONIC);
        applyAttribute(Namespace.JDNC, Attributes.ICON);
        applyAttribute(Namespace.JDNC, Attributes.SMALL_ICON);
        applyAttribute(Namespace.JDNC, Attributes.ACCELERATOR);
        applyAttribute(Namespace.JDNC, Attributes.DESCRIPTION);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DELEGATE,
                           delegateHandler);
            //handlerMap.put(Namespace.JDNC + ":" + Attributes.ID, idHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_TOGGLE,
                           toggleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.GROUP,
                           groupHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TITLE,
                           titleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MNEMONIC,
                           mnemonicHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ICON, iconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SMALL_ICON,
                           smallIconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ACCELERATOR,
                           acceleratorHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DESCRIPTION,
                           descriptionHandler);
	    // id and actionRef are attributes which are not handled 
	    // in appliers
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ID,
                           NullAttribute.idHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ACTION_REF,
                           actionRefHandler);
	    
        }

        return handlerMap;
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    private static final AttributeHandler delegateHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DELEGATE,
                             ActionAttributes.delegateApplier);
    private static final AttributeHandler actionRefHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ACTION_REF,
                             NullAttribute.nullApplier);
    private static final AttributeHandler toggleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_TOGGLE,
                             ActionAttributes.isToggleApplier);
    private static final AttributeHandler groupHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.GROUP,
                             ActionAttributes.groupApplier);
    private static final AttributeHandler titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE,
                             ActionAttributes.titleApplier);
    private static final AttributeHandler mnemonicHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.MNEMONIC,
                             ActionAttributes.mnemonicApplier);
    private static final AttributeHandler iconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ICON,
                             ActionAttributes.iconApplier);
    private static final AttributeHandler smallIconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SMALL_ICON,
                             ActionAttributes.smallIconApplier);
    private static final AttributeHandler acceleratorHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ACCELERATOR,
                             ActionAttributes.acceleratorApplier);
    private static final AttributeHandler descriptionHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DESCRIPTION,
                             ActionAttributes.descriptionApplier);
}
