/*
 * $Id: ActionAttributes.java,v 1.2 2004/07/23 04:15:07 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import java.net.URL;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import org.jdesktop.swing.Application;
import org.jdesktop.swing.actions.AbstractActionExt;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;
import net.openmarkup.Scribe;

/**
 * Attribute appliers for the Action element
 *
 * @author Ramesh Gupta
 * @author Mark Davidson
 */
public class ActionAttributes {
/*
    public static final AttributeApplier idApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();
            action.putValue(Action.ACTION_COMMAND_KEY, attributeValue);
        }
    };
*/
    public static final AttributeApplier titleApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();
            action.putValue(Action.NAME, attributeValue);
        }
    };

    public static final AttributeApplier isToggleApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            AbstractActionExt action = (AbstractActionExt) target.getObject();
            action.setStateAction(Boolean.valueOf(attributeValue).booleanValue());
        }
    };

    public static final AttributeApplier groupApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            AbstractActionExt action = (AbstractActionExt) target.getObject();
            action.setGroup(attributeValue);
        }
    };

    public static final AttributeApplier mnemonicApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();
            action.putValue(Action.MNEMONIC_KEY,
                            new Integer(attributeValue.charAt(0)));
        }
    };

    public static final AttributeApplier iconApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();

            Icon icon = ActionAttributes.getIcon(target, attributeValue);
            action.putValue(AbstractActionExt.LARGE_ICON, icon);
        }
    };

    // If the URI represents a valid URL or classpath then create an
    // ImageIcon. Otherwise, return null.
    public static Icon getIcon(Realizable target, String uri) {
        URL url = ActionAttributes.class.getResource(uri);
        if (url == null) {
            url = target.getResolvedURL(uri);
        }
        Icon icon = null;
        try {
            // test to see if the url is valid
            url.openStream();
            // icon is in a place which is relative to the document
            icon = new ImageIcon(url);
        }
        catch (Exception ex) {
	    Scribe.getLogger().warning("Error getting icon: " + url.toExternalForm());
            // XXX - this should be consolidated with getResolvedURL.
            // getResolvedURL should produce a URL from a
            // classpath: /com/sun/foo/resources/Foo/gif
            // It doesn't make sense to use the Action as the basis for
	    // the url
            icon = Application.getIcon(uri, (Action) target.getObject());
        }
        return icon;
    }

    public static final AttributeApplier smallIconApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();
            action.putValue(Action.SMALL_ICON,
                            ActionAttributes.getIcon(target, attributeValue));
        }
    };

    public static final AttributeApplier acceleratorApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();
            action.putValue(Action.ACCELERATOR_KEY,
                            KeyStroke.getKeyStroke(attributeValue));
        }
    };

    public static final AttributeApplier descriptionApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();
            action.putValue(Action.SHORT_DESCRIPTION, attributeValue);
            // TODO: Perhaps add a long description attribute
            action.putValue(Action.LONG_DESCRIPTION, attributeValue);
        }
    };

    // TODO: The delegate attribute will probably go away.
    public static final AttributeApplier delegateApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Action action = (Action) target.getObject();
            Object delegate = BaseAttribute.getReferencedObject(target,
                attributeValue);
            action.putValue("delegate", delegate);
        }
    };
}
