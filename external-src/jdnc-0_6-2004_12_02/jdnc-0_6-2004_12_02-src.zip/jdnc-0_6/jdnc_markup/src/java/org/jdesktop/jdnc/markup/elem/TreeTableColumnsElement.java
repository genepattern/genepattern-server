/*
 * $Id: TreeTableColumnsElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.table.TableColumnExt;

import java.util.Hashtable;
import java.util.Map;

import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableColumnModel;

import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;

/**
 *
 * @author Ramesh Gupta
 */
public class TreeTableColumnsElement extends TableColumnsElement {
    private static final Map    elementMap = new Hashtable();

    public TreeTableColumnsElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TREE_TABLE_COLUMN.getLocalName(),
                           tableColumnElementHandler);
        }
        return handlerMap;
    }

    private static final ElementHandler		tableColumnElementHandler =
         new ElementHandler(ElementTypes.TREE_TABLE_COLUMN, tableColumnAssimilator);
}
