/*
 * $Id: DataAttributes.java,v 1.2 2004/07/23 04:20:38 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.data.TabularDataTextLoader;

import org.jdesktop.swing.data.DOMAdapter;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.parsers.DocumentBuilderFactory;

import net.openmarkup.ApplierError;
import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

import org.w3c.dom.Document;

import org.jdesktop.jdnc.markup.RealizationUtils;

/**
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class DataAttributes {
    // ...

    public static void actuateData(TabularDataModel data, String actuateValue) throws IOException {
        if (actuateValue.equals("") || actuateValue.equals("onLoad")) {
	    data.startLoading();
        }
        // "other", "none", "onRequest" values handled elsewhere
    }

    public static final AttributeApplier actuateApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            //REMIND(aim): TabularData is only one type of data object - also need to support
            // RowSet and possible other data object types
            String mediaType = target.getAttributeNSOptional(Namespace.JDNC,
                Attributes.MEDIA_TYPE);
            try {
                if (mediaType.equals("text/jdnc-hierarchical-data")) {
                    //REMIND(aim):data already loaded?
                }
                else {
                    TabularDataModel data = (TabularDataModel) target.getObject();
                    actuateData(data, attributeValue);
                }
            }
            catch (Exception ex) {
                throw new ApplierException("Couldn't actuate data " +
                                           attributeName + "=" + attributeValue,
                                           ex);
            }
        }
    };

    public static final AttributeApplier	columnDelimiterApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            TabularDataModel data = (TabularDataModel) target.getObject();
            /** @todo Fix this! Can't assume TabularDataTextReader */
            ((TabularDataTextLoader) data.getLoader()).setColumnDelimiter(
                attributeValue);
        }
    };

    public static final AttributeApplier	firstRowHeaderApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            TabularDataModel data = (TabularDataModel) target.getObject();
            /** @todo Fix this! Can't assume TabularDataTextReader */
            try {
                ((TabularDataTextLoader)data.getLoader()).setFirstRowHeader(
                    Boolean.valueOf(attributeValue).booleanValue());
            } catch (Exception e) {
                throw new ApplierException(attributeName + "not supported for loader", e);
            }
        }
    };

    public static final AttributeApplier	sourceApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
	    // Validate the URL before we do anything else.
	    URL url = target.getResolvedURL(attributeValue);
	    RealizationUtils.validateURL(url);

            //REMIND(aim): TabularData is only one type of data object - also need to support
            // RowSet and possible other data object types
            String  mediaType = target.getAttributeNSOptional(Namespace.JDNC,
                                                        Attributes.MEDIA_TYPE);
            try {
                if (mediaType.equals("text/jdnc-hierarchical-data")) {
                    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                    dbf.setNamespaceAware(true);
                    dbf.setIgnoringComments(true);
                    Document dom = dbf.newDocumentBuilder().parse(
                        url.toExternalForm());
                    ((DOMAdapter) target.getObject()).bind(dom);
                }
                else {
                    TabularDataModel data = (TabularDataModel) target.getObject();
		    data.setSource(url);
                }
            }
            catch (Exception ex) {
                throw new ApplierError("Couldn't set data source " +
                    attributeName + "=" + attributeValue, ex);
            }
        }
    };

}
