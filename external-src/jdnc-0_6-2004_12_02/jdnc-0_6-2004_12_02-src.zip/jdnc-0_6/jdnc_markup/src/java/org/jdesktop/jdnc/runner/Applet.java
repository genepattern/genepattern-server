/*
 * $Id: Applet.java,v 1.1.1.1 2004/06/16 01:43:41 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.runner;

import java.awt.Component;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.HeadlessException;

import java.net.URL;

import java.util.logging.Level;

import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.UIManager;

import net.openmarkup.Scribe;

/**
 * <p>
 * Applet class which instantiates its user interface based on the
 * XML configuration file specified in the applet tag's &quot;config&quot;
 * parameter.</p>
 * <p>
 * The configuration file must adhere to the JDNC schema:<br>
 *    TBD
 * </p>
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class Applet extends JApplet {
    public static final String CONFIG_PARAM = "config";
    public static final String LEVEL_PARAM = "level";
    private static final String[][] paramInfo = {
	{ CONFIG_PARAM, "String",
	  "XML configuration file URL used to instantiate user interface" },
	{ LEVEL_PARAM, "String",
	  "The logging level to use" }
    };

    public Applet() throws HeadlessException {
        try {
          UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e) {
          e.printStackTrace();
        }
    }

    public void init() {
	super.init();

	// Set the logging level
	Application.setLogLevel(getParameter(LEVEL_PARAM));

        String configuration = getParameter(CONFIG_PARAM);
        if (configuration == null) {
            Scribe.getLogger().severe("applet parameter \"" + CONFIG_PARAM +
				      "\" must be specified");
            return;
        }

	JComponent ui = null;
	try {
	    ui = Application.realizeObject(new URL(getDocumentBase(), configuration));
	} catch (Exception ex) {
	    Scribe.getLogger().log(Level.SEVERE,
				   "Exception realizing: " + configuration, ex);
	    return;
	}


	org.jdesktop.swing.Application app = Application.getApplication(ui);
	if (app == null) {
	    app = org.jdesktop.swing.Application.getInstance(this);
	}
        app.registerApplet(this);

        //REMIND(aim): this should probably be codebase???
        //need to be careful not to clobber the setting from other applets
        //who share this app object
        app.setBaseURL(getDocumentBase());

	if (ui instanceof JRootPane) {
	    setRootPane((JRootPane)ui);
	} else {
            getContentPane().add(BorderLayout.CENTER, ui);
        }
    }

    public void destroy() {
        org.jdesktop.swing.Application.getApp(this).unregisterApplet(this);
    }

    public String[][] getParameterInfo() {
	return paramInfo;
    }
}
