/*
 * $Id: TreeTableElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import org.w3c.dom.Element;
import org.jdesktop.swing.treetable.TreeTableModel;
import org.jdesktop.jdnc.JNTreeTable;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.TreeTableAttributes;


/**
 *
 * @author Ramesh Gupta
 */
public class TreeTableElement extends TableElement {
    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    public TreeTableElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    public Object instantiate() {
        object = super.instantiate();
        applyAttribute(Namespace.JDNC, Attributes.DATA_SOURCE);
        applyAttribute(Namespace.JDNC, Attributes.COLLAPSED_ICON);
        applyAttribute(Namespace.JDNC, Attributes.CONTAINER_ICON);
        applyAttribute(Namespace.JDNC, Attributes.CLOSED_ICON);
        applyAttribute(Namespace.JDNC, Attributes.OPEN_ICON);
        applyAttribute(Namespace.JDNC, Attributes.EXPANDED_ICON);
        applyAttribute(Namespace.JDNC, Attributes.LEAF_ICON);
        return object;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.EXPANDS_ALL);
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DATA_SOURCE,
                           dataSourceHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.COLLAPSED_ICON,
                           collapsedIconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.CLOSED_ICON,
                           containerClosedIconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.OPEN_ICON,
                           containerOpenIconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.EXPANDS_ALL,
                           expandsAllHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.EXPANDED_ICON,
                           expandedIconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.LEAF_ICON,
                           leafIconHandler);
        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.HIERARCHICAL_DATA.getLocalName(),
                           hierarchicalDataElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TREE_TABLE_COLUMNS.getLocalName(),
                           tableColumnsElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator	dataAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNTreeTable 	table = (JNTreeTable)parent.getObject();
            TreeTableModel	model = (TreeTableModel)child.getObject();
            table.setTreeTableModel(model);
            table.expandRow(0);
        }
    };

    protected static final AttributeHandler	dataSourceHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DATA_SOURCE, TreeTableAttributes.dataSourceApplier);

    protected static final AttributeHandler	collapsedIconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.COLLAPSED_ICON, TreeTableAttributes.collapsedIconApplier);

    protected static final AttributeHandler	containerClosedIconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.CLOSED_ICON, TreeTableAttributes.closedIconApplier);

    protected static final AttributeHandler	containerOpenIconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.OPEN_ICON, TreeTableAttributes.openIconApplier);

    protected static final AttributeHandler	expandsAllHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.EXPANDS_ALL, TreeTableAttributes.expandsAllApplier);

    protected static final AttributeHandler	expandedIconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.EXPANDED_ICON, TreeTableAttributes.expandedIconApplier);

    protected static final AttributeHandler	leafIconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.LEAF_ICON, TreeTableAttributes.leafIconApplier);

    protected static final ElementHandler		hierarchicalDataElementHandler =
        new ElementHandler(ElementTypes.HIERARCHICAL_DATA, dataAssimilator);

    private static final ElementHandler		tableColumnsElementHandler =
        new ElementHandler(ElementTypes.TREE_TABLE_COLUMNS, tableColumnsAssimilator);

}
