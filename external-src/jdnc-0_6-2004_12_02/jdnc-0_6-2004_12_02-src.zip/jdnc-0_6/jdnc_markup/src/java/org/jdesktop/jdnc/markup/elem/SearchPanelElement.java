/*
 * $Id: SearchPanelElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Map;

import org.w3c.dom.Element;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.SearchPanelAttributes;

/**
 *
 * @author Ramesh Gupta
 */
public class SearchPanelElement extends ComponentElement {
    public SearchPanelElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.PATTERN_FILTER);
        applyAttribute(Namespace.JDNC, Attributes.PATTERN_HIGHLIGHTER);
        applyAttribute(Namespace.JDNC, Attributes.TARGET);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.PATTERN_FILTER,
                           patternFilterHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.PATTERN_HIGHLIGHTER,
                           patternHighlighterHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TARGET,
                           targetHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler	patternFilterHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.PATTERN_FILTER, SearchPanelAttributes.patternFilterApplier);

    private static final AttributeHandler	patternHighlighterHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.PATTERN_HIGHLIGHTER, SearchPanelAttributes.patternHighlighterApplier);

    private static final AttributeHandler	targetHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TARGET, SearchPanelAttributes.targetApplier);
}
