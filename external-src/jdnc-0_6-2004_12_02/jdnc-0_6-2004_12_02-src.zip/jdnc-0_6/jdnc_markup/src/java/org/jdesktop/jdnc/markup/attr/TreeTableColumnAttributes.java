/*
 * $Id: TreeTableColumnAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.table.TabularDataMetaData;
import org.jdesktop.swing.table.TableColumnExt;
import org.jdesktop.jdnc.JNTreeTable;
import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.elem.ElementProxy;
import org.jdesktop.swing.data.DOMAdapter;
import org.jdesktop.swing.treetable.TreeTableModel;
/**
 * @author Ramesh Gupta
 */
public class TreeTableColumnAttributes {
    public static final AttributeApplier	bindingApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            JNTreeTable	table = getTreeTable(target);
            if (table != null) {
                DOMAdapter	data = (DOMAdapter) table.getTreeTableModel();
                if (data != null) {
                    int count = data.getColumnCount();
                    for (int i = 0; i < count; i++) {
                        if (data.getColumnName(i).equals(attributeValue)) {
                            TableColumnExt column = (TableColumnExt) target.getObject();
                            column.setModelIndex(i);
                            break;
                        }
                    }
                }
            }
        }

		/** @todo Refactor the following and TableColumnAttributes.getTable() */
        private JNTreeTable getTreeTable(Realizable target) {
            Node	root = target.getOwnerDocument().getDocumentElement();
            Node	parent = target.getParentNode();
            String	nsURI = ElementTypes.TABLE.getNamespaceURI();
            String	treeTableName = ElementTypes.TREE_TABLE.getLocalName();
            while (parent != root) {
                String	parentName = parent.getLocalName();
                if (parentName.equals(treeTableName) &&
                    parent.getNamespaceURI().equals(nsURI)) {
                    Realizable	tableElement = ElementProxy.getRealizable((Element) parent);
                    if (tableElement != null) {
                        return (JNTreeTable) tableElement.getObject();
                    }
                    return null;
                }
                parent = parent.getParentNode();
            }
            return null;
        }
    };
}
