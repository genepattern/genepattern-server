/*
 * $Id: TableHeaderElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;
import org.jdesktop.jdnc.markup.attr.LabelAttributes;

/**
 *
 * @author Amy Fowler
 */
public class TableHeaderElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();

    public TableHeaderElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.BACKGROUND);
        applyAttribute(Namespace.JDNC, Attributes.FOREGROUND);
        applyAttribute(Namespace.JDNC, Attributes.FONT);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.BACKGROUND,
                           backgroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.FOREGROUND,
                           foregroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.FONT,
                           fontHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler	backgroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.BACKGROUND,
                             ComponentAttributes.backgroundApplier);

    private static final AttributeHandler	foregroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.FOREGROUND,
                             ComponentAttributes.foregroundApplier);

    private static final AttributeHandler	fontHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.FONT,
                             ComponentAttributes.fontApplier);

}
