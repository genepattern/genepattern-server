/*
 * $Id: FilterElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Map;
import java.util.Hashtable;

import java.util.regex.Pattern;

import org.w3c.dom.Element;
import org.jdesktop.swing.decorator.PatternFilter;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.RealizationUtils;
import org.jdesktop.jdnc.markup.attr.*;
import org.jdesktop.jdnc.markup.attr.NullAttribute;

/**
 *
 * @author Ramesh Gupta
 */
public class FilterElement extends ElementProxy {

    private static final Map attrMap = new Hashtable();

    public FilterElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected int getColumnIndex() {
        String colName = getAttributeNSOptional(Namespace.JDNC, Attributes.TEST_COLUMN);
        if (colName.length() > 0) {
            return TableColumnAttributes.getModelIndex(this, colName);
        }
        return -1;
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
	    // Register null appliers. These attributes are handled elsewhere
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TEST_COLUMN,
                           testColumnHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler testColumnHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TEST_COLUMN, NullAttribute.nullApplier);

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }
}
