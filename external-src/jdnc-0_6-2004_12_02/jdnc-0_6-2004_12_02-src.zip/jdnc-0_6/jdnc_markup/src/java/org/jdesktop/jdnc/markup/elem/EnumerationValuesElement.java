/*
 * $Id: EnumerationValuesElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import javax.swing.JLabel;

import org.w3c.dom.Element;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;

/**
 *
 * @author Ramesh Gupta
 */
public class EnumerationValuesElement extends ElementProxy {
    private static final Map    elementMap = new Hashtable();

    public EnumerationValuesElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.ENUMERATION_VALUE.getLocalName(),
                           enumerationElementHandler);
        }
        return handlerMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected void checkAttributes() {
	// Overloaded as an empty implementation 
	// because elements are 
    }

    public static final ElementAssimilator	enumerationAssimilator = new ElementAssimilator() {
        private final static String	enumKey = Namespace.JDNC + ":" + net.openmarkup.Attributes.VALUE;
        public void assimilate(Realizable parent, Realizable child) {
            Map		map = (Map) parent.getObject();
            JLabel	label = (JLabel) child.getObject();
            // lookup key is specified by the "value" attribute
            String	key = child.getAttributeNSOptional(Namespace.JDNC, net.openmarkup.Attributes.VALUE);
			if ((key != null) && (label != null)) {
                label.putClientProperty(enumKey, key);
                map.put(key, label);
            }
        }
    };

    private static final ElementHandler		enumerationElementHandler =
        new ElementHandler(ElementTypes.ENUMERATION_VALUE, enumerationAssimilator);

}
