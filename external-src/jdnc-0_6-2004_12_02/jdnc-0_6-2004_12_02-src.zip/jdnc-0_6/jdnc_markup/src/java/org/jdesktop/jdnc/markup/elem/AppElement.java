/*
 * $Id: AppElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.Application;

import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import org.w3c.dom.Element;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.AppAttributes;

/**
 *
 * @author Amy Fowler
 */
public class AppElement extends ElementProxy {

    private static final Map attrMap = new Hashtable();

    public AppElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Object instantiate() {
        Application app = null;
        String id = this.getAttributeNSOptional(Namespace.JDNC, Attributes.ID);
        if (id.length() > 0) {
            app = Application.getInstance(id);
        } else {
            app = Application.getInstance();
        }
	app.setBaseURL(getObjectRealizer().getDefaultBaseURL());
	// Store the id so that the application instance can be retrieved.
	putORValue("ApplicationID", id);

        return app;
    }

    public AttributeHandler getAttributeHandler(String namespaceURI, String attrName) {
        Map	handlerMap = getAttributeHandlerMap();
        return handlerMap == null ? null : (AttributeHandler) attrMap.get(namespaceURI + ":" + attrName);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.TITLE);
        applyAttribute(Namespace.JDNC, Attributes.VERSION_STRING);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TITLE,
                           titleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.VERSION_STRING,
                           versionStringHandler);
        }
        return handlerMap;
    }

    protected static final AttributeHandler	titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE,
                             AppAttributes.titleApplier);

    protected static final AttributeHandler	versionStringHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.VERSION_STRING,
                             AppAttributes.versionStringApplier);

}
