/*
 * $Id: TreeTableAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import java.net.URL;
import javax.xml.parsers.DocumentBuilderFactory;

import javax.swing.ImageIcon;

import org.w3c.dom.Document;
import org.jdesktop.swing.data.DOMAdapter;
import org.jdesktop.jdnc.JNTreeTable;
import org.jdesktop.jdnc.markup.RealizationUtils;
import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

/**
 * @author Ramesh Gupta
 */
public class TreeTableAttributes {
    public static final AttributeApplier	dataSourceApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {

            // Validate the URL before we do anything else.
            URL url = target.getResolvedURL(attributeValue);
            RealizationUtils.validateURL(url);

            try {
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                dbf.setNamespaceAware(true);
                dbf.setIgnoringComments(true);
                Document dom = dbf.newDocumentBuilder().parse(
                    url.toExternalForm());
                JNTreeTable	table = (JNTreeTable) target.getObject();
            	table.setTreeTableModel(new DOMAdapter(dom));
                table.expandRow(0);
            }
            catch (Exception ex) {
                throw new ApplierException("Couldn't set data source " +
                    attributeName + "=" + attributeValue, ex);
            }
        }
    };

    public static final AttributeApplier	collapsedIconApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            URL url = target.getResolvedURL(attributeValue);
            if (url != null) {
                JNTreeTable	table = (JNTreeTable) target.getObject();
                table.setCollapsedIcon(new ImageIcon(url));
            }
            else {
                System.out.println("Couldn't resolve URL: " + attributeValue);
            }
        }
    };

    public static final AttributeApplier	closedIconApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            URL url = target.getResolvedURL(attributeValue);
            if (url != null) {
                JNTreeTable	table = (JNTreeTable) target.getObject();
                table.setClosedIcon(new ImageIcon(url));
            }
            else {
                System.out.println("Couldn't resolve URL: " + attributeValue);
            }
        }
    };

    public static final AttributeApplier	openIconApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            URL url = target.getResolvedURL(attributeValue);
            if (url != null) {
                JNTreeTable	table = (JNTreeTable) target.getObject();
                table.setOpenIcon(new ImageIcon(url));
            }
            else {
                System.out.println("Couldn't resolve URL: " + attributeValue);
            }
        }
    };

    public static final AttributeApplier	expandsAllApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            JNTreeTable	table = (JNTreeTable) target.getObject();
            boolean		expandsAll = Boolean.valueOf(attributeValue).booleanValue();
            if (expandsAll) {
                table.expandAll();
            }
        }
    };

    public static final AttributeApplier	expandedIconApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            URL url = target.getResolvedURL(attributeValue);
            if (url != null) {
                JNTreeTable	table = (JNTreeTable) target.getObject();
                table.setExpandedIcon(new ImageIcon(url));
            }
            else {
                System.out.println("Couldn't resolve URL: " + attributeValue);
            }
        }
    };

    public static final AttributeApplier	leafIconApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            URL url = target.getResolvedURL(attributeValue);
            if (url != null) {
                JNTreeTable	table = (JNTreeTable) target.getObject();
                table.setLeafIcon(new ImageIcon(url));
            }
            else {
                System.out.println("Couldn't resolve URL: " + attributeValue);
            }
        }
    };
}
