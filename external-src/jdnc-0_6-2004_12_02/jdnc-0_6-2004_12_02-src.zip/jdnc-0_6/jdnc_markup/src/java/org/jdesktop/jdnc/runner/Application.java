/*
 * $Id: Application.java,v 1.3 2004/07/28 00:51:45 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.runner;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Image;
import java.awt.Window;

import java.beans.Expression;

import java.net.URL;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import net.openmarkup.ObjectRealizer;
import net.openmarkup.Scribe;
import net.openmarkup.Vocabulary;

// XXX This class should be renamed to JDNCLoader or something

/**
 * <p>
 * Application class which instantiates its user interface based on the
 * XML configuration file specified as the command line parameter.
 * <p>
 * The configuration file must adhere to the JDNC schema:<br>
 *    TBD
 * </p>
 *
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class Application {

    private static ObjectRealizer realizer;

    private static Vocabulary vocabulary;

    /**
     * Constructs the application to use the object realizer
     * vocabulary.
     */
    public Application(Vocabulary vocabulary) {
	this.vocabulary = vocabulary;
    }

    /**
     * Creates a JDNC application from the url. The logging level is
     * set at the default - which is Level.WARNING.
     *
     * @param url a URL which represents a jdnc application
     */
    public Application(URL url) {
	this(url, null);
    }

    /**
     * Creates a JDNC application from the url.
     * <p>
     * The level parameter must correspond to a string value
     * of <code>java.util.logging.Level</code> constants.
     * May be upper or lower case. If null then the level
     * will be set to Level.WARNING.
     *
     * @param url a URL which represents a jdnc application
     * @param level the default level to set the logger
     */
    public Application(URL url, Level level) {
	setLogLevel(level);
	try {
	    initUI(realizeObject(url));
	} catch (Exception ex) {
	    Scribe.getLogger().log(Level.SEVERE, "Exception loading: " +
				   url, ex);
	}
    }

    /**
     * Creates a JDNC application from the url. The logging level is
     * set at the default - which is Level.WARNING
     */
    public Application(String configuration) {
	this(configuration, null);
    }

    /**
     * Main constructor to use for a stand alone application.
     * <p>
     * The level parameter must correspond to a string value
     * of <code>java.util.logging.Level</code> constants.
     * May be upper or lower case. If null then the level
     * will be set to Level.WARNING.
     *
     * @param configuration A JDNC configuration file.
     * @param level a value to set the default logging level or null
     * @see java.util.logging.Level
     */
    public Application(String configuration, String level) {
	setLogLevel(level);
	try {
	    initUI(realizeObject(configuration));
	} catch (Exception ex) {
	    Scribe.getLogger().log(Level.SEVERE, "Exception loading: " +
				   configuration, ex);
	}
    }

    private void initUI(final JComponent ui) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // App temporarily stashed in client properties if created already
                org.jdesktop.swing.Application app = getApplication(ui);
                JDNCFrame frame = new JDNCFrame(app);
		if (ui instanceof JRootPane) {
                    frame.replaceRootPane((JRootPane)ui);
                } else {
                    frame.getContentPane().add(BorderLayout.CENTER, ui);
                }
                frame.pack();
                frame.setVisible(true);
            }
        });
    }

    static org.jdesktop.swing.Application getApplication(JComponent ui) {
	if (ui == null) {
	    return null;
	}
        // App temporarily stashed in clientproperties if created already
	org.jdesktop.swing.Application app = (org.jdesktop.swing.Application) ui.getClientProperty("Application");
	if (app == null) {
	    app = org.jdesktop.swing.Application.getInstance();
	}
        return app;
    }

    static JComponent realizeObject(URL config) throws Exception {
	Scribe.getLogger().info("Loading: " + config);
	ObjectRealizer realizer = Application.getObjectRealizer();
	Object object = null;
	if (config != null) {
	    object = realizer.getObject(config);
	}
	return validateObject(object, config.toExternalForm());
    }

    static JComponent realizeObject(String configuration) throws Exception {
	Scribe.getLogger().info("Loading: " + configuration);
	ObjectRealizer realizer = Application.getObjectRealizer();
	Object object = null;
	if (configuration != null) {
	    object = realizer.getObject(configuration);
	}
	return validateObject(object, configuration);
    }

    // Set the level of the logger.
    static void setLogLevel(Level level) {
	Scribe.getLogger().setLevel(level == null ? Level.WARNING : level);
    }

    static void setLogLevel(String level) {
	Level lvl = null;
	if (level != null) {
	    try {
		lvl = Level.parse(level.toUpperCase());
	    } catch (Exception ex) {
		// level is invalid, ignore
	    }
	}
	setLogLevel(lvl);
    }

    /**
     * Checks the Object to ensure that it is not null and it must be
     * a JComponent.
     */
    static JComponent validateObject(Object object, String configuration) {
        if (object == null || ! (object instanceof JComponent)) {
	    Scribe.getLogger().severe("Unable to realize the user interface\n" +
				      " from configuration URL:\n" +
				      configuration + "\n" +
				      "Please verify configuration file\n" +
				      "adheres to JDNC schema.");
        }
	return (JComponent)object;
    }


    /**
     * This method looks up the ObjectRealizer implementation from the 
     * system property openmarkup.realizer.impl. 
     * <p>
     * Also, there should be a similar mechanism in which to specify the
     * vocabulary for the object realizer.
     * <p>
     * This method should be consolidated with markup.RealizationUtils.getObjectRealizer
     */
    public static ObjectRealizer getObjectRealizer() {
	if (realizer == null) {
	    // The OR implementation should be looked up in System.properties.
	    String realizerImplName = null;
	    try {
		realizerImplName = System.getProperty("openmarkup.realizer.impl");
		if (realizerImplName == null) {
		    realizerImplName = "org.jdesktop.openmarkup.ri.ObjectRealizerImpl";
		}
	    } catch (SecurityException ex) {
		// Access to properties are not allowed. For example, in sandboxed
		// applications.
		realizerImplName = "org.jdesktop.openmarkup.ri.ObjectRealizerImpl";
	    }
	    
	    Object or = null;
	    try {
		Class clz = Class.forName(realizerImplName);
		or = clz.newInstance();
		
		// First use getInstance (if it exists) to get the actual 
		// object realizer instance.
		realizer = (ObjectRealizer)(new Expression(or, "getInstance",
						       new Object[0])).getValue();
	    } catch (Exception ex) {
		// getInstance doesn't exist.
		if (or != null && or instanceof ObjectRealizer) {
		    realizer = (ObjectRealizer)or;
		} 
		else {
		    throw new RuntimeException("Cannot find ObjectRealizer: " + 
					       realizerImplName, ex);
		}
	    }

	    // XXX - this is also a potential circular dependency
	    if (vocabulary == null) {
		try {
		    Class cls = Class.forName("org.jdesktop.jdnc.markup.ElementTypes");
		    Vocabulary vb = (Vocabulary)cls.newInstance();
		    vocabulary = (Vocabulary)(new Expression(vb,
				     "get", new Object[0])).getValue();
		} catch (Exception ex) {
		    throw new RuntimeException("Error no suitable Vocabulary", ex);

		}
	    }
	    realizer.add(vocabulary);
	}
	return realizer;
    }

    /**
     * XXX this should be replaced by org.jdesktop.swing.JXFrame
     */
    private class JDNCFrame extends JFrame {

	public JDNCFrame(org.jdesktop.swing.Application app) {
	    super(app.getTitle());
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    Image iconImage = app.getTitleBarImage();
	    if (iconImage != null) {
		setIconImage(iconImage);
	    }
	    app.registerWindow(this);
	}

        public void replaceRootPane(JRootPane rootPane) {
            // setRootPane is protected on JFrame
            setRootPane(rootPane);
        }
    }

    public static void main(String[] args) {
        if (args.length <= 0) {
            System.err.println(
                "XML configuration URL must be specified on command line");
            System.exit(-1);
        }
        try {
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e) {
	    e.printStackTrace();
        }

	Application application;
	if (args.length == 2) {
	    application = new Application(args[0], args[1]);
	} else {
	    application = new Application(args[0]);
	}
    }
}
