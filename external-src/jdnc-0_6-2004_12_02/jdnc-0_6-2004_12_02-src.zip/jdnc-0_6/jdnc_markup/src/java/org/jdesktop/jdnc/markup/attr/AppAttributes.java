/*
 * $Id: AppAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.swing.Application;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

/**
 * @author Amy Fowler
 */
public class AppAttributes {
    public static final AttributeApplier titleApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Application app = (Application) target.getObject();
            app.setTitle(attributeValue);
        }
    };

    public static final AttributeApplier	versionStringApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Application app = (Application) target.getObject();
            app.setVersionString(attributeValue);
        }
    };
     // ...
}
