/*
 * $Id: LabelElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Map;

import org.w3c.dom.Element;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.LabelAttributes;
import org.jdesktop.jdnc.markup.attr.NullAttribute;

/**
 *
 * @author Ramesh Gupta
 */
public class LabelElement extends ComponentElement {
    public LabelElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.ICON);
        applyAttribute(Namespace.JDNC, Attributes.TITLE);
        applyAttribute(Namespace.JDNC, Attributes.HORIZONTAL_ALIGNMENT);
        applyAttribute(Namespace.JDNC, Attributes.HORIZONTAL_TEXT_POSITION);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ICON, iconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TITLE, titleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.HORIZONTAL_ALIGNMENT,
                           horizontalAlignmentHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           Attributes.HORIZONTAL_TEXT_POSITION,
                           horizontalTextPositionHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.VALUE,
			   NullAttribute.valueHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler	horizontalAlignmentHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.HORIZONTAL_ALIGNMENT, LabelAttributes.horizontalAlignmentApplier);

    private static final AttributeHandler	horizontalTextPositionHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.HORIZONTAL_TEXT_POSITION, LabelAttributes.horizontalTextPositionApplier);

    private static final AttributeHandler	iconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ICON, LabelAttributes.iconApplier);

    private static final AttributeHandler	titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE, LabelAttributes.titleApplier);

}
