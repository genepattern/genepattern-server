/*
 * $Id: SorterElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.regex.Pattern;

import org.w3c.dom.Element;
import org.jdesktop.swing.decorator.ShuttleSorter;
import net.openmarkup.ElementType;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.Decoder;
import java.util.Hashtable;
import java.util.Map;
import net.openmarkup.AttributeHandler;
import org.jdesktop.jdnc.markup.attr.SorterAttributes;

/**
 *
 * @author Ramesh Gupta
 */
public class SorterElement extends FilterElement {
    private static final Map	attrMap = new Hashtable();

    public SorterElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Object instantiate() {
        return new ShuttleSorter(getColumnIndex(), true);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.DIRECTION);
    }
    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DIRECTION,
                           directionAttrHandler);
        }
        return handlerMap;
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    private static final AttributeHandler	directionAttrHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DIRECTION, SorterAttributes.directionApplier);

}
