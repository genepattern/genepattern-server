/*
 * $Id: TableColumnsElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.table.TableColumnExt;

import java.util.Hashtable;
import java.util.Map;

import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableColumnModel;

import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;

/**
 *
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class TableColumnsElement extends ElementProxy {
    private static final Map    elementMap = new Hashtable();

    public TableColumnsElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    public Object instantiate() {
        return new DefaultTableColumnModel();
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABLE_COLUMN.getLocalName(),
                           tableColumnElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator	tableColumnAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            TableColumnModel columnModel = (TableColumnModel)parent.getObject();
            TableColumnExt column = (TableColumnExt)child.getObject();
            columnModel.addColumn(column);
        }
    };

    private static final ElementHandler		tableColumnElementHandler =
         new ElementHandler(ElementTypes.TABLE_COLUMN, tableColumnAssimilator);

}
