/*
 * $Id: DataColumnAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;


import org.jdesktop.swing.data.Converters;
import org.jdesktop.swing.data.Converter;
import org.jdesktop.swing.table.TabularDataMetaData;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

import java.text.SimpleDateFormat;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.elem.ElementProxy;

/**
 * @author Ramesh Gupta
 */
public class DataColumnAttributes {
    public static final AttributeApplier	dataTypeApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            //System.out.println("dataTypeApplier: column="+
            //                   (column != null? column.toString():"null"));
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData) ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    Class klass = Decoder.decodeType(attributeValue);
                    //System.out.println("column class="+klass.getName());
                    if (klass != null) {
                        metaData.setColumnClass(columnIndex, klass);
                    }
                }
            }
        }
    };

    public static final AttributeApplier	dateFormatApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData) ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    /**@todo aim: this is lossy - need to work this out */
                    Converter converter = new Converters.DateConverter(
                        new SimpleDateFormat(attributeValue),
                        new SimpleDateFormat("MMMMM d yyyy"));
                    metaData.setColumnConverter(columnIndex, converter);
                }
            }
        }
    };

    public static final AttributeApplier	displayLengthApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData)
                        ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    metaData.setColumnDisplaySize(columnIndex, Integer.parseInt(
                        attributeValue));
                }
            }
        }
    };

    public static final AttributeApplier	labelApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData) ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    metaData.setColumnLabel(columnIndex, attributeValue);
                }
            }
        }
    };

    public static final AttributeApplier	maximumApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData) ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    Class klass = metaData.getColumnClass(columnIndex);
                    Converter converter = Converters.get(klass);
                    try {
                        metaData.setColumnMaximum(columnIndex,
                                                  converter.decode(attributeValue, null));
                    } catch (Exception e) {
                        /**@todo aim: need exception handling */
                        System.out.println("maximum applier, couldn't convert value "+attributeValue);
                    }
                }
            }
        }
    };


    public static final AttributeApplier	minimumApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData) ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    Class klass = metaData.getColumnClass(columnIndex);
                    Converter converter = Converters.get(klass);
                    try {
                        metaData.setColumnMinimum(columnIndex,
                                                  converter.decode(attributeValue, null));
                    } catch (Exception e) {
                        /**@todo aim: need exception handling */
                        System.out.println("minimum applier, couldn't convert value "+attributeValue);
                    }
                }
            }
        }
    };

    public static final AttributeApplier	nameApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData) ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    metaData.setColumnName(columnIndex, attributeValue);
                }
            }
        }
    };

    public static final AttributeApplier	isReadOnlyApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            Integer	column = (Integer) target.getObject();
            if (column != null) {
                int columnIndex = column.intValue();
                if (columnIndex > 0) {
                    TabularDataMetaData metaData = (TabularDataMetaData) ElementProxy.getRealizable(
                        (Element) target.getParentNode()).getObject();
                    metaData.setColumnWritable(columnIndex,
                            !Boolean.valueOf(attributeValue).booleanValue());
                }
            }
        }
    };

}
