/*
 * $Id: DataFieldEnumerationElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;

/**
 * @author Amy Fowler
 */
public class DataFieldEnumerationElement extends ElementProxy {
    private static final Map    elementMap = new Hashtable();

    public DataFieldEnumerationElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    public Object instantiate() {
        return new ArrayList();
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.FIELD_META_DATA_ENUMERATION.getLocalName(),
                           enumerationValueElementHandler);
        }
        return handlerMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    public static final ElementAssimilator	dataEnumerationValueAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            List list = (List)parent.getObject();
            list.add(child.getObject());
        }
    };

    private static final ElementHandler	 enumerationValueElementHandler =
         new ElementHandler(ElementTypes.FIELD_META_DATA_ENUMERATION,
                            dataEnumerationValueAssimilator);

}
