/*
 * $Id: FormComponentAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.swing.data.DataModel;
import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.data.TabularDataModelAdapter;

import org.jdesktop.swing.binding.Binding;
import org.jdesktop.swing.binding.BindException;

import org.jdesktop.swing.form.JForm;
import org.jdesktop.swing.form.RowSelector;

import org.jdesktop.jdnc.JNForm;
import org.jdesktop.jdnc.JNTable;

import org.jdesktop.jdnc.markup.elem.FormElement;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;


/**
 * @author Amy Fowler
 */
public class FormComponentAttributes {

    public static final AttributeApplier	dataApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue)
            throws ApplierException {
            Object data = BaseAttribute.getReferencedObject(target,
                attributeValue);
            Object binding[] = (Object[]) target.getObject();
            binding[0] = data;
        }

    };

    public static final AttributeApplier	bindingApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue)
            throws ApplierException {
            Object binding[] = (Object[]) target.getObject();
            binding[1] = attributeValue;
        }
    };

     // ...
}
