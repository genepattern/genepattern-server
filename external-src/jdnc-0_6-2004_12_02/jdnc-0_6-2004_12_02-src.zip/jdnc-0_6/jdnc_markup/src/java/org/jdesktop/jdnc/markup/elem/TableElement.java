/*
 * $Id: TableElement.java,v 1.4 2004/09/02 00:50:35 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.table.*;
import javax.swing.table.TableColumnModel;

import org.jdesktop.swing.LabelProperties;
import org.jdesktop.swing.data.ConversionException;
import org.jdesktop.swing.data.Converter;
import org.jdesktop.swing.data.Converters;
import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.MetaDataProvider;
import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.decorator.Filter;
import org.jdesktop.swing.decorator.FilterPipeline;
import org.jdesktop.swing.decorator.Highlighter;
import org.jdesktop.swing.decorator.HighlighterPipeline;
import org.jdesktop.swing.table.TableColumnExt;
import org.jdesktop.swing.utils.LoadOnShowListener;
import org.jdesktop.jdnc.JNTable;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;
import org.jdesktop.jdnc.markup.attr.TableAttributes;
import org.jdesktop.jdnc.markup.attr.NullAttribute;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class TableElement extends ComponentElement {
    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    public TableElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected void assimilateChildren() {
        applyAttribute(Namespace.JDNC, Attributes.DATA);
        super.assimilateChildren();
    }

    protected void applyAttributesBefore() {
        /** @todo decide precedence of data and source attributes (when both are present) */
        applyAttribute(Namespace.JDNC, Attributes.DATA);
        applyAttribute(Namespace.JDNC, Attributes.DATA_SOURCE);
        applyAttribute(Namespace.JDNC, Attributes.IS_FIRST_ROW_HEADER);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.HAS_COLUMN_CONTROL);
        applyAttribute(Namespace.JDNC, Attributes.COLUMN_MARGIN);
        applyAttribute(Namespace.JDNC, Attributes.GRID_COLOR);
        applyAttribute(Namespace.JDNC, Attributes.PREFERRED_SIZE);
        applyAttribute(Namespace.JDNC, Attributes.ROW_HEIGHT);
        applyAttribute(Namespace.JDNC, Attributes.ROW_MARGIN);
        applyAttribute(Namespace.JDNC, Attributes.SELECTION);
        applyAttribute(Namespace.JDNC, Attributes.SELECTION_MODE);
        applyAttribute(Namespace.JDNC, Attributes.SHOWS_HORIZONTAL_LINES);
        applyAttribute(Namespace.JDNC, Attributes.SHOWS_VERTICAL_LINES);
        applyAttribute(Namespace.JDNC, Attributes.SORTABLE);
        applyAttribute(Namespace.JDNC, Attributes.SIZE); // WIDTH and HEIGHT
        applyAttribute(Namespace.JDNC, Attributes.IS_COLUMN_HEADER_LOCKED);
        applyAttribute(Namespace.JDNC, Attributes.IS_ROW_HEADER_LOCKED);

        // by now the model, columnModel, and columns have all been initialized
        applySpecialProperties(this);
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
        //    handlerMap.put(Namespace.JDNC + ":" + Attributes.SORTABLE,
        //                   sortableHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           Attributes.HAS_COLUMN_CONTROL,
                           hasColumnControlHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.COLUMN_MARGIN,
                           columnMarginHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DATA,
                           dataHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DATA_SOURCE,
                           dataSourceHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_FIRST_ROW_HEADER,
                           firstRowHeaderHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.GRID_COLOR,
                           gridColorHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.PREFERRED_SIZE,
                           preferredSizeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ROW_HEIGHT,
                           rowHeightHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ROW_MARGIN,
                           rowMarginHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SELECTION,
                           selectionHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SELECTION_MODE,
                           selectionModeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SHOWS_HORIZONTAL_LINES,
                           showsHorizontalLinesHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SHOWS_VERTICAL_LINES,
                           showsVerticalLinesHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SIZE,
                           sizeHandler); // WIDTH and HEIGHT
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_COLUMN_HEADER_LOCKED,
                           isColumnHeaderLockedHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_ROW_HEADER_LOCKED,
                           isRowHeaderLockedHandler);

        // Register null appliers. These attributes are handled elsewhere
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ID,
                           NullAttribute.idHandler);

            handlerMap.put(Namespace.JDNC + ":" + Attributes.TITLE,
                           titleHandler);

        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            //elementMap.put(Namespace.JDNC + ":" + ElementTypes.ACTIONS.getLocalName(), actionsElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.FILTERS.getLocalName(),
                           filtersElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABLE_HEADER.getLocalName(),
                           headerElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.HIGHLIGHTERS.getLocalName(),
                           highlightersElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.COMPONENT_TOOLBAR.getLocalName(),
                           toolBarElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABLE_COLUMNS.getLocalName(),
                           tableColumnsElementHandler);
            /** @todo Move all of the above to AbstractTableElement */
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABULAR_DATA.getLocalName(),
                           tabularDataElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.DATA.getLocalName(), dataElementHandler);
        }
        return handlerMap;
    }

    protected static void applySpecialProperties(Realizable target) {
        JNTable table = (JNTable)target.getObject();
        TableColumnModel columnModel = table.getTable().getColumnModel();
        for(int i = 0; i < columnModel.getColumnCount(); i++) {
            TableColumnExt column = (TableColumnExt)columnModel.getColumn(i);
            applyColumnProperties(table, column);
        }
    }

    protected static void applyColumnProperties(final JNTable table, final TableColumnExt column) {
        // These table column properties are special, in that they are not
        // direct properties on TableColumnExt; they can only be set once the
        // table and the tableColumnModel have been initialized.
        LabelProperties props = (LabelProperties) column.getClientProperty(
            "LabelProperties");
        if (props != null) {
            String columnName = (String)column.getIdentifier();
            if (props.isBackgroundSet()) {
                table.setColumnBackground(columnName, props.getBackground());
            }
            if (props.isForegroundSet()) {
                table.setColumnForeground(columnName, props.getForeground());
            }
            if (props.isHorizontalAlignmentSet()) {
                table.setColumnHorizontalAlignment(columnName, props.getHorizontalAlignment());
            }
            column.putClientProperty("LabelProperties", null); //clear temp stash
        }

        String prototypeValueString = (String)column.getClientProperty("prototypeValueString");
        if (prototypeValueString != null) {
            TableModel model = table.getModel();
            Object prototypeValue = prototypeValueString; //fallback
            Converter converter = null;
            Object decodeFormat = null;
            if (model instanceof MetaDataProvider) {
                MetaData metaData[] = ( (MetaDataProvider) model).getMetaData();
                MetaData columnMetaData = metaData[column.getModelIndex()];
                converter = columnMetaData.getConverter();
                decodeFormat = columnMetaData.getDecodeFormat();
            } else { // no metadata
                converter = Converters.get(model.getColumnClass(column.getModelIndex()));
            }
            if (converter != null) {
                try {
                    prototypeValue = converter.decode(prototypeValueString,
                        decodeFormat);
                } catch (ConversionException e) {
                    System.err.println(e.getMessage());
                }
            }
            column.setPrototypeValue(prototypeValue);
        }
    }

    protected static boolean hasColumnsElement(Realizable target) {
        NodeList columnsNode = target.getElementsByTagNameNS(Namespace.JDNC,
                                   ElementTypes.TABLE_COLUMNS.getLocalName());
        return columnsNode.getLength() > 0;

    }

    // data can be set as table attribute OR child element, so factor common code here
    public static void setModel(Realizable target, TableModel model) {
        // Before setting model, check whether or not the columns should
        // be automatically created or not (yes, only if no <columns> element is present)
        JNTable table = (JNTable)target.getObject();
        if (hasColumnsElement(target)) {
            table.getTable().setAutoCreateColumnsFromModel(false);
        }
        table.setModel(model);
    }

    public static final ElementAssimilator	dataAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNTable table = (JNTable)parent.getObject();
            TabularDataModel data = (TabularDataModel)child.getObject();
            setModel(parent, data);
            String actuate = child.getAttributeNSOptional(Namespace.JDNC, Attributes.ACTUATE);
            if (actuate.equals("onRequest")) {
                table.addHierarchyListener(new LoadOnShowListener(data));
            }
        }
    };

    public static final ElementAssimilator	filtersAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNTable table = (JNTable)parent.getObject();
            Vector	filters = (Vector)child.getObject();
            table.setFilters(new FilterPipeline((Filter[])
                filters.toArray(filterType)
                ));
        }
    };

    public static final ElementAssimilator	headerAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNTable table = (JNTable)parent.getObject();
            JTableHeader	header = (JTableHeader)child.getObject();
            table.getTable().setTableHeader(header);
        }
    };

    public static final ElementAssimilator	highlightersAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNTable table = (JNTable)parent.getObject();
            Vector	highlighters = (Vector)child.getObject();
            table.setHighlighters(new HighlighterPipeline((Highlighter[])
                highlighters.toArray(highlighterType)
                ));
        }
    };

    public static final ElementAssimilator tableColumnsAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNTable table = (JNTable) parent.getObject();
            TableColumnModel columnModel = (TableColumnModel) child.getObject();
            table.getTable().setAutoCreateColumnsFromModel(false);
            table.getTable().setColumnModel(columnModel);
            for(int i = 0; i < columnModel.getColumnCount() ; i++) {
                TableColumn column = columnModel.getColumn(i);
                if (column.getModelIndex() == -1) {
                    column.setModelIndex(i);
                }
            }
        }
    };

    public static final ElementAssimilator	toolBarAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNTable table = (JNTable)parent.getObject();
            Vector	toolBarEntries = (Vector)child.getObject();
            int		count = toolBarEntries.size();
            for (int i = 0; i < count; i++) {
                Object		entry = toolBarEntries.get(i);
                if (entry instanceof Action) {
                    table.addAction((Action) entry);
                }
                else if (entry instanceof JComponent) {
                    table.addToolBarComponent((JComponent) entry);
                }
            }
        }
    };

    // For typecasting entries in a Vector when converted to an array
    private static final Filter[]		filterType = new Filter[]{};
    private static final Highlighter[]	highlighterType = new Highlighter[]{};

    protected static final AttributeHandler	dataSourceHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DATA_SOURCE, TableAttributes.dataSourceApplier);

    protected static final AttributeHandler	hasColumnControlHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.HAS_COLUMN_CONTROL, TableAttributes.hasColumnControlApplier);

    protected static final AttributeHandler	columnMarginHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.COLUMN_MARGIN, TableAttributes.columnMarginApplier);

    protected static final AttributeHandler	dataHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DATA, TableAttributes.dataApplier);

    protected static final AttributeHandler	firstRowHeaderHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_FIRST_ROW_HEADER, TableAttributes.firstRowHeaderApplier);

    protected static final AttributeHandler	gridColorHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.GRID_COLOR, TableAttributes.gridColorApplier);

    protected static final AttributeHandler	preferredSizeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.PREFERRED_SIZE, TableAttributes.preferredSizeApplier);

    protected static final AttributeHandler	rowHeightHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ROW_HEIGHT, TableAttributes.rowHeightApplier);

    protected static final AttributeHandler	rowMarginHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ROW_MARGIN, TableAttributes.rowMarginApplier);

    protected static final AttributeHandler	selectionHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SELECTION, TableAttributes.selectionApplier);

    protected static final AttributeHandler	selectionModeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SELECTION_MODE, TableAttributes.selectionModeApplier);

    protected static final AttributeHandler	showsHorizontalLinesHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SHOWS_HORIZONTAL_LINES, TableAttributes.showsHorizontalLinesApplier);

    protected static final AttributeHandler	showsVerticalLinesHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SHOWS_VERTICAL_LINES, TableAttributes.showsVerticalLinesApplier);

    protected static final AttributeHandler	sizeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SIZE, ComponentAttributes.sizeApplier);

    protected static final AttributeHandler	isColumnHeaderLockedHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_COLUMN_HEADER_LOCKED, TableAttributes.isColumnHeaderLockedApplier);

    protected static final AttributeHandler	isRowHeaderLockedHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_ROW_HEADER_LOCKED, TableAttributes.isRowHeaderLockedApplier);

    protected static final AttributeHandler titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE, NullAttribute.nullApplier);

//    protected static final AttributeHandler	sortableHandler =
  //      new AttributeHandler(Namespace.JDNC, Attributes.SORTABLE, TableAttributes.sortableApplier);


    protected static final ElementHandler		filtersElementHandler =
        new ElementHandler(ElementTypes.FILTERS, TableElement.filtersAssimilator);

    protected static final ElementHandler		headerElementHandler =
        new ElementHandler(ElementTypes.TABLE_HEADER, TableElement.headerAssimilator);

    protected static final ElementHandler		highlightersElementHandler =
        new ElementHandler(ElementTypes.HIGHLIGHTERS, TableElement.highlightersAssimilator);

    protected static final ElementHandler		dataElementHandler =
        new ElementHandler(ElementTypes.DATA, TableElement.dataAssimilator);

    protected static final ElementHandler		tabularDataElementHandler =
        new ElementHandler(ElementTypes.TABULAR_DATA, TableElement.dataAssimilator);

    protected static final ElementHandler		tableColumnsElementHandler =
        new ElementHandler(ElementTypes.TABLE_COLUMNS, TableElement.tableColumnsAssimilator);

    protected static final ElementHandler		toolBarElementHandler =
        new ElementHandler(ElementTypes.COMPONENT_TOOLBAR, TableElement.toolBarAssimilator);

}
