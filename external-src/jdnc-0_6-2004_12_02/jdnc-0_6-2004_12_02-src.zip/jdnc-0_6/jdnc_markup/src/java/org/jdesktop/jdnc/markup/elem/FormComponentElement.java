/*
 * $Id: FormComponentElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;

import org.jdesktop.jdnc.markup.attr.FormComponentAttributes;


/**
 *
 * @author Amy Fowler
 */
public class FormComponentElement extends ComponentElement {
    private static final Map	attrMap = new Hashtable();

    public FormComponentElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Object instantiate() {
       Object binding[] = new Object[2];
       binding[0] = null;
       binding[1] = null;
       return binding;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.DATA);
        applyAttribute(Namespace.JDNC, Attributes.BINDING);
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DATA,
                           dataHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.BINDING,
                           bindingHandler);
        }
        return handlerMap;
    }

    protected static final AttributeHandler	dataHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DATA,
                             FormComponentAttributes.dataApplier);

    protected static final AttributeHandler	bindingHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.BINDING,
                             FormComponentAttributes.bindingApplier);



}
