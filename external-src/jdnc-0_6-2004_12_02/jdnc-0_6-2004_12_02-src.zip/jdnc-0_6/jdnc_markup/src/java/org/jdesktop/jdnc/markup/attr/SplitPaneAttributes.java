/*
 * $Id: SplitPaneAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import javax.swing.JSplitPane;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;


/**
 * @author Amy Fowler
 */
public class SplitPaneAttributes {


    public static final AttributeApplier	orientationApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue)
            throws ApplierException {
            JSplitPane splitPane = (JSplitPane) target.getObject();
            if (attributeValue.equals("vertical")) {
                splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
            } else if (attributeValue.equals("horizontal")) {
                splitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
            } else {
                /**@todo aim: real error handling */
                System.out.println("unsupported orientation value="+attributeValue);
            }
        }
    };


     // ...
}
