/*
 * $Id: MenuBarElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import javax.swing.JMenu;
import javax.swing.JMenuBar;

import java.util.Hashtable;
import java.util.Map;

import org.w3c.dom.Element;

import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;

public class MenuBarElement extends ElementProxy {
    private static final Map elementMap = new Hashtable();
    
    public MenuBarElement(Element element, ElementType elementType) {
	super(element, elementType);
    }

    protected Map getElementHandlerMap() {
	return elementMap;
    }

    protected Map registerElementHandlers() {
	Map handlerMap = super.registerElementHandlers();
	if (handlerMap != null) {
	    handlerMap.put(Namespace.JDNC + ":" + ElementTypes.MENU.getLocalName(),
			   menuElementHandler);
	}
	return handlerMap;
    }

    public static final ElementAssimilator menuAssimilator = new ElementAssimilator() {
	    public void assimilate(Realizable parent, Realizable child) {
		JMenuBar menuBar = (JMenuBar)parent.getObject();
		JMenu menu = (JMenu)child.getObject();
		menuBar.add(menu);
	    }
	};

    protected static final ElementHandler menuElementHandler =
	new ElementHandler(ElementTypes.MENU, MenuBarElement.menuAssimilator);
}
