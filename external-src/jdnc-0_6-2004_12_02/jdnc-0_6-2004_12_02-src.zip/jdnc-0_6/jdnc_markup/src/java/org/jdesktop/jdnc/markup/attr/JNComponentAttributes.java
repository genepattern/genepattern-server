/*
 * $Id: JNComponentAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.jdnc.JNComponent;

import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

/**
 * @author Amy Fowler
 * @author ...
 */
public class JNComponentAttributes {

    // ...

    public static final AttributeApplier	backgroundImageApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
          /* REMIND(aim): implement JNComponent backgroundImageApplier
            JNComponent	component = (JNComponent) target.getObject();
            URL imageURL = ...
            component.setBackgroundImage(image);
          */
        }
    };

    // ...
}
