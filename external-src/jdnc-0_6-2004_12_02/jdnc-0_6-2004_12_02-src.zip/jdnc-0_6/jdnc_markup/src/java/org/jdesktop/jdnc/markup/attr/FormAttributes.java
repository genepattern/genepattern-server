/*
 * $Id: FormAttributes.java,v 1.2 2004/06/17 21:02:45 rameshgupta Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.swing.data.DataModel;
import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.data.TabularDataModelAdapter;

import org.jdesktop.swing.binding.Binding;
import org.jdesktop.swing.binding.BindException;

import org.jdesktop.swing.JXTable;
import org.jdesktop.swing.decorator.FilterPipeline;
import org.jdesktop.swing.form.JForm;
import org.jdesktop.swing.form.RowSelector;

import org.jdesktop.jdnc.JNForm;
import org.jdesktop.jdnc.JNTable;

import org.jdesktop.jdnc.markup.elem.FormElement;

import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;


/**
 * @author Amy Fowler
 */
public class FormAttributes {

    public static final AttributeApplier	dataApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue)
            throws ApplierException {
            Object dataModel = BaseAttribute.getReferencedObject(target, attributeValue);
            JNForm form = (JNForm) target.getObject();
            ((FormElement)target).handleBinding(form, dataModel);
        }
    };

    /**@todo aim: this is a total hack until we can work out an elegant way
     * to track selection.
     */
    public static final AttributeApplier	tracksApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue)
            throws ApplierException {
            Object selectionComponent = BaseAttribute.getReferencedObject(target,
                attributeValue);
            JNForm form = (JNForm) target.getObject();
            if (selectionComponent instanceof JNTable) {
                Binding bindings[] = form.getForm().getBindings();
                DataModel model = null;
                if (bindings.length > 0) {
                    model = bindings[0].getDataModel();
                }
                final JTable table = ((JNTable)selectionComponent).getTable();
                new org.jdesktop.swing.form.RowSelector(table, model);
                /*
                if (model.getRecordCount() == 0) {
                    // no data yet, so we watch for data to set initial selection
                    // to ensure that DataModel has a non -1 current index
                    table.getModel().addTableModelListener(new TableModelListener() {
                        public void tableChanged(TableModelEvent e) {
                            if (e.getType() == TableModelEvent.INSERT) {
                                // Hack to patch Amy's hack!
                                if (table instanceof JXTable) {
									FilterPipeline	fp = ((JXTable) table).getFilters();
                                    if (fp != null) {
                                        fp.flush();
                                    }
                                }

                                table.getSelectionModel().setLeadSelectionIndex(0);
                                table.getSelectionModel().setAnchorSelectionIndex(0);
                                table.getModel().removeTableModelListener(this);
                            }
                        }
                    });
                }
                */
            }
        }
    };
    // ...
}
