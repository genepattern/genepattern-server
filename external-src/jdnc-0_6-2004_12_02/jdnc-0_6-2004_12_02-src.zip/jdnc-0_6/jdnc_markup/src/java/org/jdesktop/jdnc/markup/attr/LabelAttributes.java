/*
 * $Id: LabelAttributes.java,v 1.2 2004/09/02 00:50:35 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

import org.jdesktop.jdnc.markup.Namespace;

/**
 * @author Ramesh Gupta
 */
public class LabelAttributes {

    public static void applyHorizontalAlignment(JLabel label, String attributeValue) {
        // Per W3C Internationalization guidelines, we now support "before" as a
        // synonym for "leading", and "after" as a synonym for "trailing"

        int value = Decoder.decodeConstant(attributeValue);
        if (value != -1) {
            label.setHorizontalAlignment(value);
        }
        /**@remind:aim: warning if value not recognized? */

    }

    public static void applyHorizontalTextPosition(JLabel label, String attributeValue) {
        // Per W3C Internationalization guidelines, we now support "before" as a
        // synonym for "leading", and "after" as a synonym for "trailing"

        int value = Decoder.decodeConstant(attributeValue);
        if (value != -1) {
            label.setHorizontalTextPosition(value);
        }
    }

    public static void applyIcon(Realizable target, JLabel label, String attributeValue) {
        try {
            URL url = target.getResolvedURL(attributeValue);
            if (url == null) {
                System.out.println("Could not resolve URL: " + attributeValue);
            }
            else {
                //System.out.println("Get Icon from: " + url);
                Icon icon = new ImageIcon(url);
                label.setIcon(icon);
            }
        }
        catch (Exception ex) {
            System.out.println("LabelAttributes.iconApplier: " + ex);
        }
    }

    public static void applyIconTextGap(JLabel label, String attributeValue) {
        try {
            int value = Integer.parseInt(attributeValue);
            label.setIconTextGap(value);
        }
        catch (Exception ex) {
            System.out.println("LabelAttributes.iconTextGapApplier: " + ex);
        }
    }

    public static void applyVerticalAlignment(JLabel label, String attributeValue) {
        int value = Decoder.decodeConstant(attributeValue);
        if (value != -1) {
            label.setVerticalAlignment(value);
        }
    }

    public static void applyVerticalTextPosition(JLabel label, String attributeValue) {
        int value = Decoder.decodeConstant(attributeValue);
        if (value != -1) {
            label.setVerticalTextPosition(value);
        }
    }

    public static final AttributeApplier	horizontalAlignmentApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            applyHorizontalAlignment((JLabel)target.getObject(), attributeValue);
        }
    };

    public static final AttributeApplier	horizontalTextPositionApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            applyHorizontalTextPosition((JLabel)target.getObject(), attributeValue);
        }
    };

    public static final AttributeApplier	iconApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            applyIcon(target, (JLabel)target.getObject(), attributeValue);
        }
    };

    public static final AttributeApplier	iconTextGapApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            applyIconTextGap((JLabel)target.getObject(), attributeValue);
        }
    };

    public static final AttributeApplier	titleApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            ((JLabel)target.getObject()).setText(attributeValue);
        }
    };

    public static final AttributeApplier	verticalAlignmentApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            applyVerticalAlignment((JLabel)target.getObject(), attributeValue);
        }
    };

    public static final AttributeApplier	verticalTextPositionApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            applyVerticalTextPosition( (JLabel) target.getObject(),
                                      attributeValue);
        }
    };

}
