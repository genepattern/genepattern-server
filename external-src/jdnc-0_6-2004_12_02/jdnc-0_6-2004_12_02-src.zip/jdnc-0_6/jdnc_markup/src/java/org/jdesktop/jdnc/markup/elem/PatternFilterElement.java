/*
 * $Id: PatternFilterElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Map;

import java.util.regex.Pattern;

import org.w3c.dom.Element;
import org.jdesktop.swing.decorator.*;

import net.openmarkup.ElementType;
import net.openmarkup.AttributeHandler;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;

import org.jdesktop.jdnc.markup.attr.Decoder;
import org.jdesktop.jdnc.markup.attr.NullAttribute;

/**
 *
 * @author Ramesh Gupta
 */
public class PatternFilterElement extends FilterElement {

    public PatternFilterElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Object instantiate() {
        return new PatternFilter(null, 0, getColumnIndex());
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyExpressionAttribute();	// combo attribute
    }

    // XXX this is almost identical to PatternHighlighterElement.applyExpressionAttribute.
    // Perhaps there could be some consolidation?
    private void applyExpressionAttribute() {
        // Identical to PatternHighlighterElement.applyExpressionAttribute
        if (object != null) {
            /** @todo deprecate Attributes.MATCH here and in PatternHighlighter */
            // processes both Attributes.EXPRESSION and Attributes.MATCH
            String	expression = getAttributeNSOptional(Namespace.JDNC, Attributes.EXPRESSION);
            if (expression.length() > 0) {
                try {
                    int matchFlags = Decoder.decodePatternMatchFlags(
                        getAttributeNSOptional(Namespace.JDNC, Attributes.MATCH));
                    ( (PatternMatcher) object).setPattern(
                        Pattern.compile(expression, matchFlags));
                }
                catch (Exception ex) {
		    logException("Bad regular expression \"" + expression +
				 "\" or match flags", ex);
                }
            }
        }
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
	    // Register null appliers. These attributes are handled elsewhere
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ID,
                           NullAttribute.idHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.EXPRESSION,
                           exprHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MATCH,
                           matchHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler exprHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.EXPRESSION, NullAttribute.nullApplier);

    private static final AttributeHandler matchHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.EXPRESSION, NullAttribute.nullApplier);

}
