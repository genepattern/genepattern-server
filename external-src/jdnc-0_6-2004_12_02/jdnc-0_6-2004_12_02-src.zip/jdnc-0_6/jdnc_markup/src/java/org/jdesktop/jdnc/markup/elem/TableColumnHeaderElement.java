/*
 * $Id: TableColumnHeaderElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;
import org.jdesktop.jdnc.markup.attr.LabelAttributes;

/**
 *
 * @author Amy Fowler
 */
public class TableColumnHeaderElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();

    public TableColumnHeaderElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        //visual attributes applied to a LabelProperties object
        applyAttribute(Namespace.JDNC, Attributes.BACKGROUND);
        applyAttribute(Namespace.JDNC, Attributes.FOREGROUND);
        applyAttribute(Namespace.JDNC, Attributes.HORIZONTAL_ALIGNMENT);
        applyAttribute(Namespace.JDNC, Attributes.HORIZONTAL_TEXT_POSITION);
        applyAttribute(Namespace.JDNC, Attributes.ICON);
        applyAttribute(Namespace.JDNC, Attributes.ICON_TEXT_GAP);
        applyAttribute(Namespace.JDNC, Attributes.VERTICAL_ALIGNMENT);
        applyAttribute(Namespace.JDNC, Attributes.VERTICAL_TEXT_POSITION);

        // now that column properties have been applied to a LabelProperties
        // object, apply that to the column
        //TableColumnAttributes.applyColumnProperties((TableColumnExt)getObject());

    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.BACKGROUND,
                           backgroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.FOREGROUND,
                           foregroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.HORIZONTAL_ALIGNMENT,
                           horizontalAlignmentHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.HORIZONTAL_TEXT_POSITION,
                           horizontalTextPositionHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ICON,
                           iconHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ICON_TEXT_GAP,
                           iconTextGapHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.VERTICAL_ALIGNMENT,
                           verticalAlignmentHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.VERTICAL_TEXT_POSITION,
                           verticalTextPositionHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler	backgroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.BACKGROUND,
                             ComponentAttributes.backgroundApplier);

    private static final AttributeHandler	foregroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.FOREGROUND,
                             ComponentAttributes.foregroundApplier);

    private static final AttributeHandler horizontalAlignmentHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.HORIZONTAL_ALIGNMENT,
                             LabelAttributes.horizontalAlignmentApplier);

    private static final AttributeHandler horizontalTextPositionHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.HORIZONTAL_TEXT_POSITION,
                             LabelAttributes.horizontalTextPositionApplier);

    private static final AttributeHandler iconHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ICON,
                             LabelAttributes.iconApplier);

    private static final AttributeHandler iconTextGapHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ICON_TEXT_GAP,
                             LabelAttributes.iconTextGapApplier);
/*
    private static final AttributeHandler	titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE,
                             Label.titleApplier);
        */

    private static final AttributeHandler verticalAlignmentHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.VERTICAL_ALIGNMENT,
                             LabelAttributes.verticalAlignmentApplier);

    private static final AttributeHandler verticalTextPositionHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.VERTICAL_TEXT_POSITION,
                             LabelAttributes.verticalTextPositionApplier);



}
