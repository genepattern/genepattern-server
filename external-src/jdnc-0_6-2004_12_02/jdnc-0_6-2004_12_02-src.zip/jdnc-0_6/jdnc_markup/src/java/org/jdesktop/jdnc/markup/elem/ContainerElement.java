/*
 * $Id: ContainerElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.awt.Component;
import java.awt.Container;

import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import javax.swing.JComponent;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;
import org.jdesktop.jdnc.markup.attr.RootPaneAttributes;

/**
 *
 * @author Amy Fowler
 */
public class ContainerElement extends ComponentElement {

    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    public ContainerElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    public ElementHandler getElementHandler(String namespaceURI, String elementName) {
        Map	handlerMap = getElementHandlerMap();
        return handlerMap == null ? null : (ElementHandler) handlerMap.get(namespaceURI + ":" + elementName);
    }

    public AttributeHandler getAttributeHandler(String namespaceURI, String attrName) {
        Map	handlerMap = getAttributeHandlerMap();
        return handlerMap == null ? null : (AttributeHandler) attrMap.get(namespaceURI + ":" + attrName);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }
/*
    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        //applyAttribute(Namespace.JDNC, Attributes.ENABLED);
    }
*/
    protected Map registerAttributeHandlers() {
         Map handlerMap = super.registerAttributeHandlers();
         if (handlerMap != null) {
            //handlerMap.put(Namespace.JDNC + ":" + Attributes.COLUMN_DELIMITER, columnDelimiterHandler);
         }
         return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.EDITOR.getLocalName(),
                           editorElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.FORM.getLocalName(),
                           formElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABLE.getLocalName(),
                           tableElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TREE_TABLE.getLocalName(),
                           treeTableElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator	componentAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            Container container = (Container)parent.getObject();
            Component component = (Component)child.getObject();
            container.add(component);
        }
    };

    // For typecasting entries in a Vector when converted to an array

    protected static final ElementHandler editorElementHandler =
        new ElementHandler(ElementTypes.EDITOR,
                           ContainerElement.componentAssimilator);

    protected static final ElementHandler formElementHandler =
        new ElementHandler(ElementTypes.TABLE,
                           ContainerElement.componentAssimilator);

    protected static final ElementHandler tableElementHandler =
        new ElementHandler(ElementTypes.TABLE,
                           ContainerElement.componentAssimilator);

    protected static final ElementHandler treeTableElementHandler =
        new ElementHandler(ElementTypes.TREE_TABLE,
                           ContainerElement.componentAssimilator);


}
