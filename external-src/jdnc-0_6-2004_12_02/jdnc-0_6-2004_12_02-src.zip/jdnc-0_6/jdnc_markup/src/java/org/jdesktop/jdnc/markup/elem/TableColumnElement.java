/*
 * $Id: TableColumnElement.java,v 1.3 2004/09/02 00:50:35 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import javax.swing.table.TableCellRenderer;

import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.TabularDataModel;

import org.jdesktop.swing.LabelProperties;
import org.jdesktop.swing.table.ColumnHeaderRenderer;
import org.jdesktop.swing.table.TableColumnExt;

import org.jdesktop.jdnc.JNTable;

import java.util.Hashtable;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.TableColumnAttributes;

/**
 *
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class TableColumnElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    public TableColumnElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.BINDING);	// must come first!

        applyAttribute(Namespace.JDNC, Attributes.IS_READ_ONLY);
        applyAttribute(Namespace.JDNC, Attributes.ENUM_VALUES);
        applyAttribute(Namespace.JDNC, Attributes.PROTOTYPE_VALUE);
        //applyAttribute(Namespace.JDNC, Attributes.SORTABLE);
        applyAttribute(Namespace.JDNC, Attributes.TITLE);
        initializeHeaderTitle();

        //visual attributes applied to a LabelProperties object
        applyAttribute(Namespace.JDNC, Attributes.BACKGROUND);
        applyAttribute(Namespace.JDNC, Attributes.FOREGROUND);
        applyAttribute(Namespace.JDNC, Attributes.HORIZONTAL_ALIGNMENT);
        applyAttribute(Namespace.JDNC, Attributes.VERTICAL_ALIGNMENT);
        applyAttribute(Namespace.JDNC, Attributes.PREFERRED_WIDTH);

    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            //handlerMap.put(Namespace.JDNC + ":" + Attributes.EDITABLE, editableHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.BINDING,
                           bindingHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_READ_ONLY,
                           isReadOnlyHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ENUM_VALUES,
                           enumValuesHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.PROTOTYPE_VALUE,
                           prototypeValueHandler);
            //handlerMap.put(Namespace.JDNC + ":" + Attributes.SORTABLE,
            //               sortableHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TITLE,
                           titleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.BACKGROUND,
                           backgroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.FOREGROUND,
                           foregroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.HORIZONTAL_ALIGNMENT,
                           horizontalAlignmentHandler);
            /*
            handlerMap.put(Namespace.JDNC + ":" + Attributes.VERTICAL_ALIGNMENT,
                           verticalAlignmentHandler);
             */
            handlerMap.put(Namespace.JDNC + ":" + Attributes.PREFERRED_WIDTH,
                           preferredWidthHandler);

        }
        return handlerMap;
    }

    protected void initializeHeaderTitle() {
        TableColumnExt column = (TableColumnExt)getObject();
        // initialize header from column metadata if no title was set
        if (column.getHeaderValue() == null) {
            Realizable tableTarget = ElementProxy.getRealizable((Element)
                getParentNode().getParentNode());
            JNTable table = (JNTable) tableTarget.getObject();
            TabularDataModel data = (TabularDataModel)table.getModel();
            int columnIndex = column.getModelIndex();
            String label = "Column" + columnIndex;
            if (data != null) {
                MetaData metaData = data.getColumnMetaData(columnIndex);
                String columnLabel = metaData.getLabel();
                if (columnLabel != null) {
                    label = columnLabel;
                }
            }
            column.setHeaderValue(label);
        }
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABLE_COLUMN_HEADER.getLocalName(),
                           tableColumnHeaderElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator tableColumnHeaderAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            TableColumnExt column = (TableColumnExt) parent.getObject();
            LabelProperties headerProperties = (LabelProperties) child.getObject();
            TableCellRenderer headerRenderer = new ColumnHeaderRenderer();
            headerProperties.applyPropertiesTo(headerRenderer);
            column.setHeaderRenderer(headerRenderer);
        }
    };

    private static final ElementHandler tableColumnHeaderElementHandler =
     new ElementHandler(ElementTypes.TABLE_COLUMN_HEADER, tableColumnHeaderAssimilator);


    private static final AttributeHandler	backgroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.BACKGROUND,
                             TableColumnAttributes.backgroundApplier);

    private static final AttributeHandler	bindingHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.BINDING,
                             TableColumnAttributes.bindingApplier);

    private static final AttributeHandler	foregroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.FOREGROUND,
                             TableColumnAttributes.foregroundApplier);

    private static final AttributeHandler	isReadOnlyHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_READ_ONLY,
                             TableColumnAttributes.isReadOnlyApplier);

    private static final AttributeHandler	enumValuesHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ENUM_VALUES,
                             TableColumnAttributes.enumValuesApplier);

    private static final AttributeHandler horizontalAlignmentHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.HORIZONTAL_ALIGNMENT,
                             TableColumnAttributes.horizontalAlignmentApplier);

    private static final AttributeHandler	prototypeValueHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.PROTOTYPE_VALUE,
                             TableColumnAttributes.prototypeValueApplier);
/*
    private static final AttributeHandler	sortableHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SORTABLE,
                             TableColumnAttributes.sortableApplier);
*/
    private static final AttributeHandler	titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE,
                             TableColumnAttributes.titleApplier);
/*
    private static final AttributeHandler verticalAlignmentHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.VERTICAL_ALIGNMENT,
                             TableColumnAttributes.verticalAlignmentApplier);
        */

    private static final AttributeHandler preferredWidthHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.PREFERRED_WIDTH,
                             TableColumnAttributes.preferredWidthApplier);


}
