/*
 * $Id: Namespace.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

/**
 * Useful namespace constants.
 *
 * <p><b>NOTE: Future versions of this class will be aligned with the type-safe
 * enumeration facility proposed in JSR 201.</b></p>
 *
 * @author Ramesh Gupta
 * @see <a href="http://jcp.org/en/jsr/detail?id=201">JSR 201</a>
 */
public abstract class Namespace {
    /**
     * JDNC namespace
     */
    public static final String JDNC = "http://www.jdesktop.org/2004/05/jdnc";
    public static final String XML = "http://www.w3.org/XML/1998/namespace";

    private Namespace() {
        // can't be instantiated; can't be subclassed.
    }
}
