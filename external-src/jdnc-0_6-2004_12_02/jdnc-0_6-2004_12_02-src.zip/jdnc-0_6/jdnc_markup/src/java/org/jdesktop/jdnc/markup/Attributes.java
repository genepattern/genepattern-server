/*
 * $Id: Attributes.java,v 1.2 2004/06/17 21:02:46 rameshgupta Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

/**
 *
 * @author Ramesh Gupta
 * @author Amy Fowler
 */
public final class Attributes {
    // ...

    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ACTION_REF = "actionRef";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ACTUATE = "actuate";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ACCELERATOR = "accelerator";
    /**
      * Represents the local name of the <b><code>{@value}</code></b> attribute.
      */
     public static final String APP = "app";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String BACKGROUND = "background";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String BINDING = "binding";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String COLLAPSED_ICON = "collapsedIcon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String HAS_COLUMN_CONTROL = "hasColumnControl";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String COLUMN_DELIMITER = "columnDelimiter";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String COLUMN_MARGIN = "columnMargin";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String CONTAINER_ICON = "containerIcon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String CLOSED_ICON = "closedIcon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String OPEN_ICON = "openIcon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DATA = "data";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DATA_SOURCE = "source";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DATA_TYPE = "type";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DECODE_FORMAT = "decodeFormat";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DIRECTION = "direction";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ENCODE_FORMAT = "encodeFormat";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DELEGATE = "delegate";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DESCRIPTION = "description";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String DISPLAY_SIZE = "displaySize";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String EDITABLE = "editable";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_ENABLED = "isEnabled";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_FIRST_ROW_HEADER = "isFirstRowHeader";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_VISIBLE = "isVisible";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ENUM_VALUES = "enumValues";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String EVEN_ROW_BACKGROUND = "evenRowBackground";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String EXPANDED_ICON = "expandedIcon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String EXPANDS_ALL = "expandsAll";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String EXPRESSION = "expression";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String FONT = "font";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String FOREGROUND = "foreground";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String GRID_COLOR = "gridColor";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String GROUP = "group";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String HIGHLIGHT_COLUMN = "highlightColumn";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    //public static final String HIGHLIGHT_COLUMN_INDEX = "highlightColumnIndex";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String HORIZONTAL_ALIGNMENT = "horizontalAlignment";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String HORIZONTAL_TEXT_POSITION = "horizontalTextPosition";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ICON = "icon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ICON_TEXT_GAP = "iconTextGap";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ID = "id";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String LEAF_ICON = "leafIcon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MASK = "mask";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MATCH = "match";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MAXIMUM = "maximum";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MAXIMUM_FIELD_SIZE = "maximumFieldSize";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MAXIMUM_WIDTH = "maximumWidth";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MEDIA_TYPE = "mediaType";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MINIMUM = "minimum";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MINIMUM_FIELD_SIZE = "minimumFieldSize";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MINIMUM_WIDTH = "minimumWidth";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MNEMONIC = "mnemonic";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String MULTI_LINE = "multiLine";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String NAME = "name";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ODD_ROW_BACKGROUND = "oddRowBackground";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ORIENTATION = "orientation";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String PATTERN_FILTER = "patternFilter";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String PATTERN_HIGHLIGHTER = "patternHighlighter";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String PREFERRED_SIZE = "preferredSize";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String PREFERRED_WIDTH = "preferredWidth";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String PROTOTYPE_VALUE = "prototypeValue";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_COLUMN_HEADER_LOCKED = "isColumnHeaderLocked";
            // table@isColumnHeaderLocked is the same as header@isEnabled


    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_ROW_HEADER_LOCKED = "isRowHeaderLocked";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_READ_ONLY = "isReadOnly";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_REQUIRED = "isRequired";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ROW_HEIGHT = "rowHeight";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String ROW_MARGIN = "rowMargin";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SELECTED_BACKGROUND = "selectedBackground";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SELECTED_FOREGROUND = "selectedForeground";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SELECTION = "selection";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SELECTION_MODE = "selectionMode";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SHOWS_HORIZONTAL_LINES = "showsHorizontalLines";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SHOWS_VERTICAL_LINES = "showsVerticalLines";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SIZE = "size";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SMALL_ICON = "smallIcon";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SORTABLE = "sortable";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String SOURCE = "source";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String STYLE = "style";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String TARGET = "target";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String TEST_COLUMN = "testColumn";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String TEST_COLUMN_INDEX = "testColumnIndex";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String TITLE = "title";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String IS_TOGGLE = "isToggle";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    /**@todo aim: temporary */
    public static final String TRACKS = "tracks";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String VALUE = "value";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String VERSION_STRING = "versionString";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String VERTICAL_ALIGNMENT = "verticalAlignment";
    /**
     * Represents the local name of the <b><code>{@value}</code></b> attribute.
     */
    public static final String VERTICAL_TEXT_POSITION = "verticalTextPosition";




    // ...
}
