/*
 * $Id: ComponentElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Map;

import org.w3c.dom.Element;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;

import org.jdesktop.jdnc.JNComponent;

import javax.swing.JPopupMenu;

/**
 *
 * @author Ramesh Gupta
 */
public class ComponentElement extends ElementProxy {
    private static final Map attrMap =  new Hashtable();
    private static final Map elementMap = new Hashtable();

    public ComponentElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
	return elementMap;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.BACKGROUND);
        applyAttribute(Namespace.JDNC, Attributes.FOREGROUND);
        applyAttribute(Namespace.JDNC, Attributes.FONT);
        applyAttribute(Namespace.JDNC, Attributes.IS_ENABLED);
        applyAttribute(Namespace.JDNC, Attributes.IS_VISIBLE);
        applyAttribute(Namespace.JDNC, Attributes.NAME);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.BACKGROUND, backgroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.FOREGROUND, foregroundHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.FONT, fontHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_ENABLED, isEnabledHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_VISIBLE, isVisibleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.NAME, nameHandler);
        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
	Map handlerMap = super.registerElementHandlers();
	if (handlerMap != null) {
	    handlerMap.put(Namespace.JDNC + ":" + ElementTypes.POPUPMENU.getLocalName(),
			   popupElementHandler);
	}
	return handlerMap;
    }

    public static final ElementAssimilator popupAssimilator = new ElementAssimilator() {
	    public void assimilate(Realizable parent, Realizable child) {
		JNComponent comp = (JNComponent)parent.getObject();
		JPopupMenu popup = (JPopupMenu)child.getObject();
		comp.setPopupMenu(popup);
	    }
	};

    protected static final ElementHandler popupElementHandler =
	new ElementHandler(ElementTypes.POPUPMENU, ComponentElement.popupAssimilator);


    private static final AttributeHandler backgroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.BACKGROUND,
			     ComponentAttributes.backgroundApplier);

    private static final AttributeHandler foregroundHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.FOREGROUND,
			     ComponentAttributes.foregroundApplier);

    private static final AttributeHandler fontHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.FONT,
                 ComponentAttributes.fontApplier);

    private static final AttributeHandler isEnabledHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_ENABLED,
			     ComponentAttributes.isEnabledApplier);

    private static final AttributeHandler isVisibleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_VISIBLE,
                 ComponentAttributes.isVisibleApplier);

    private static final AttributeHandler	nameHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.NAME, ComponentAttributes.nameApplier);
}
