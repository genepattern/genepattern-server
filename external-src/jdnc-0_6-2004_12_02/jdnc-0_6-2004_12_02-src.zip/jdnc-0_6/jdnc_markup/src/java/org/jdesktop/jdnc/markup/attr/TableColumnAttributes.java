/*
 * $Id: TableColumnAttributes.java,v 1.4 2004/09/02 00:50:35 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import java.util.Map;

import java.awt.Component;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.jdesktop.swing.data.Converters;
import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.LabelProperties;
import org.jdesktop.swing.table.TableColumnExt;
import org.jdesktop.swing.treetable.*;
import org.jdesktop.swing.data.*;
import org.jdesktop.swing.*;
import org.jdesktop.jdnc.JNTable;
import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Attributes;
import net.openmarkup.Realizable;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.elem.ElementProxy;

/**
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class TableColumnAttributes {

    /*
         public static final AttributeApplier	editableApplier = new AttributeApplier() {
            public void apply(Realizable target, String namespaceURI,
         String attributeName, String attributeValue) throws ApplierException {
                TableColumnExt column = (TableColumnExt)target.getObject();
         column.setEditable(Boolean.valueOf(attributeValue).booleanValue());
            }
        };
     */

    public static final AttributeApplier backgroundApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            // Cannot set property on JNTable because columnModel has not yet
            // been assimilated into the table.
            // Store property to be applied later in call to applyColumnProperties
            ComponentAttributes.applyBackground(getColumnProperties(column),
                                                attributeValue);
        }
    };

    public static final AttributeApplier bindingApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            int columnIndex = TableColumnAttributes.getModelIndex(target,
                attributeValue);
            if (columnIndex >= 0) {
                TableColumnExt column = (TableColumnExt) target.getObject();
                column.setIdentifier(attributeValue);
                column.setModelIndex(columnIndex);
            }
        }
    };

    public static int getModelIndex(Realizable target, String columnName) {
        JNTable table = TableColumnAttributes.getTable(target);
        if (table != null) {
            Object model = table.getModel();
            if (model != null) {
                if (model instanceof TabularDataModel) {
                    return ( (TabularDataModel) model).getColumnIndex(
                        columnName);
                }
                else if (model instanceof DOMAdapter) {
                    return ( (DOMAdapter) model).getColumnIndex(columnName);
                }
            }
        }
        return -1;
    }

    private static JNTable getTable(Realizable target) {
        Node root = target.getOwnerDocument().getDocumentElement();
        Node parent = target.getParentNode();
        String nsURI = ElementTypes.TABLE.getNamespaceURI();
        String tableName = ElementTypes.TABLE.getLocalName();
        String treeTableName = ElementTypes.TREE_TABLE.getLocalName();
        while (parent != root) {
            String parentName = parent.getLocalName();
            if ( (parentName.equals(tableName) ||
                  parentName.equals(treeTableName)) &&
                parent.getNamespaceURI().equals(nsURI)) {
                Realizable tableElement = ElementProxy.getRealizable( (Element)
                    parent);
                if (tableElement != null) {
                    return (JNTable) tableElement.getObject();
                }
                return null;
            }
            parent = parent.getParentNode();
        }
        return null;
    }

    public static final AttributeApplier enumValuesApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            Map map = (Map) BaseAttribute.getReferencedObject(target,
                attributeValue);
            TableColumnExt column = (TableColumnExt) target.getObject();
            /** @todo RG: Reconcile with LabelProperties */
            TableColumnAttributes.setRenderer(column, map);
            TableColumnAttributes.setEditor(column, map);
        }
    };

    public static final AttributeApplier foregroundApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            // Cannot set column property on JNTable because columnModel has not yet
            // been assimilated into the table.
            // Store property to be applied later in call to applyColumnProperties
            ComponentAttributes.applyForeground(getColumnProperties(column),
                                                attributeValue);
        }
    };

    public static final AttributeApplier horizontalAlignmentApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            // Cannot set column property on JNTable because columnModel has not yet
            // been assimilated into the table.
            // Store property to be applied later in call to applyColumnProperties
            LabelAttributes.applyHorizontalAlignment(getColumnProperties(column),
                attributeValue);
        }
    };

    public static final AttributeApplier prototypeValueApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            // The attribute value must be converted to the type of the column
            // which is not easily accessible at this point, so defer the
            // conversion & property setting for later
            column.putClientProperty("prototypeValueString", attributeValue);
        }
    };

    public static final AttributeApplier isReadOnlyApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            // Note the negation! If readOnly="true", then editable=false;
            column.setEditable(!Boolean.valueOf(attributeValue).booleanValue());
        }
    };

    public static final AttributeApplier resizableApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            column.setResizable(Boolean.valueOf(attributeValue).booleanValue());
        }
    };

    public static final AttributeApplier titleApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            column.setTitle(attributeValue);
        }
    };

/*
 how practical is it to be able to set vertical alignment per column?

    public static final AttributeApplier verticalAlignmentApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            LabelAttributes.applyVerticalAlignment(getColumnProperties(column),
                attributeValue);
        }
    };
 */

    public static final AttributeApplier preferredWidthApplier = new
        AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
            TableColumnExt column = (TableColumnExt) target.getObject();
            /** @todo review attribute name: call it "preferredWidth"? */
            column.setPreferredWidth(Integer.parseInt(attributeValue));
        }
    };

    // convenience method for obtaining the temporarily stashed LabelProperties
    // object for a given column
    private static LabelProperties getColumnProperties(TableColumnExt column) {
        LabelProperties props = (LabelProperties) column.getClientProperty(
            "LabelProperties");
        if (props == null) {
            props = new LabelProperties();
            column.putClientProperty("LabelProperties", props);
        }
        return props;
    }

    private static void setRenderer(final TableColumnExt tableColumn,
                                    final Map map) {
        tableColumn.setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table,
                Object value, boolean isSelected, boolean hasFocus, int row,
                int column) {
                JLabel label = (JLabel)super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);
                // RG: value could be null
                JLabel fromLabel = value == null ? null :
                    (JLabel) map.get(value.toString());
                return decorate(fromLabel, label, value);
            }
        });
    }

    private static void setEditor(final TableColumnExt tableColumn,
                                  final Map map) {
        JComboBox labelComboBox = new JComboBox(map.values().toArray());

        labelComboBox.setRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList list,
                Object value, int index, boolean isSelected, boolean hasFocus) {
                JLabel label = (JLabel)super.getListCellRendererComponent(list,
                    value, index, isSelected, hasFocus);
                return decorate( (JLabel) value, label, value);
            }
        });

        tableColumn.setCellEditor(new DefaultCellEditor(labelComboBox) {
            public Component getTableCellEditorComponent(JTable table,
                Object value, boolean isSelected, int row, int column) {
                if ( (value != null) && tableColumn.isEditable()) {
                    JComboBox comboBox =
                        (JComboBox)super.getTableCellEditorComponent(
                        table, value, isSelected, row, column);
                    comboBox.setSelectedItem(map.get(value.toString()));
                    return comboBox;
                }
                return null;
            }

            public Object getCellEditorValue() {
                JLabel label = (JLabel)super.getCellEditorValue();

                if (label == null) {
                    return null;
                }
                else {
                    Object value = label.getClientProperty(Namespace.JDNC + ":" +
                        Attributes.VALUE);
                    try {
                        /**@todo (aim): temp breakage since we removed table backpointer from
                          * TableColumnExt - need to figure out how to resolve this...
                          */

                        // M4 warning: Does not work with JXTreeTable
                        /*
                        JXTable table = (JXTable) tableColumn.getTable();

                        TabularDataModel model = (TabularDataModel) table.
                            getModel();
                        MetaData columnMetaData = model.getColumnMetaData(
                            tableColumn.getModelIndex());
                        Converter converter = columnMetaData.getConverter();
                        return converter.decode( (String) value, null);
                            */
                           return value;
                    }
                    catch (Exception e) {
                    }
                    return value;
                }
            }
        });
    }

    private static Component decorate(JLabel fromLabel, JLabel toLabel,
                                      Object value) {
        if (fromLabel == null) {
            toLabel.setHorizontalAlignment(JLabel.LEADING);
            toLabel.setHorizontalTextPosition(JLabel.LEADING);
            toLabel.setIcon(null);
            toLabel.setText(value == null ? "" : value.toString()); // fallback value
        }
        else {
            toLabel.setHorizontalAlignment(fromLabel.getHorizontalAlignment());
            toLabel.setHorizontalTextPosition(fromLabel.
                                              getHorizontalTextPosition());
            toLabel.setIcon(fromLabel.getIcon());
            toLabel.setText(fromLabel.getText());
        }
        return toLabel;
    }
}