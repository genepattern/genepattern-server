/*
 * $Id: RealizationUtils.java,v 1.2 2004/07/28 00:51:43 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.beans.Expression;

import java.io.File;
import java.io.IOException;

import java.net.MalformedURLException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.net.URL;
import java.net.URLConnection;

import java.util.logging.Level;

import net.openmarkup.Error;
import net.openmarkup.Glitch;
import net.openmarkup.Warning;
import net.openmarkup.ApplierError;
import net.openmarkup.ApplierException;
import net.openmarkup.ApplierWarning;
import net.openmarkup.ObjectRealizer;
import net.openmarkup.Realizable;
import net.openmarkup.Scribe;

import org.w3c.dom.Element;
import org.w3c.dom.Document;

/**
 * A utility class to handle some redundant chores for object realiztion. Mostly, 
 * this class encapsulates a lot of reflective hacks and discrepancies between
 * object realizer implementations.
 * 
 * @author Mark Davidson
 */
public class RealizationUtils {

    /**
     * This method insulates the ObjectRealizer implementation to get the Realized Object
     * from the Element that has been referenced by the attributeValue.
     */
    public static Object getReferencedObject(Realizable target, String attributeValue) {
        Document doc = target.getOwnerDocument();
        if (doc instanceof net.openmarkup.Document) {
            return ( (net.openmarkup.Document) doc).getElement(attributeValue).
                getObject();
        }

        try {
            // Reflectively try the Sun ObjectRealizer
            ObjectRealizer or = target.getObjectRealizer();
            Expression exp = new Expression(or, "getElementById",
                                            new Object[] {target,
                                            attributeValue});
            Element element = (Element) exp.getValue();
            Realizable realizable = RealizationUtils.getRealizable(element);
            if (realizable == null) {
                return null;
            }
            return realizable.getObject();
        }
        catch (Exception ex) {
            throw new RuntimeException("Error processing " + attributeValue, ex);
        }
    }

    public static Element getReferencedElement(Realizable target,
                                               String attributeValue) {
        Document doc = target.getOwnerDocument();
        if (doc instanceof net.openmarkup.Document) {
            return ( (net.openmarkup.Document) doc).getElement(attributeValue);
        }
        try {
            // Reflectively try the Sun ObjectRealizer
            ObjectRealizer or = target.getObjectRealizer();
            Expression exp = new Expression(or, "getElementById",
                                            new Object[] {target,
                                            attributeValue});
            return (Element) exp.getValue();

        }
        catch (Exception ex) {
            throw new RuntimeException("Error processing " + attributeValue, ex);
        }
    }

    /**
     * Checks the url to determine if it is valid. Will throw an Error if invalid.
     *
     * @param url the URL to be checked in a string form
     */
    public static boolean validateURL(String url) throws ApplierException {
	return validateURL(url, true);
    }

    /**
     * Checks the url to determine if it is valid. Will throw an exception if invalid.
     * The type of exception is determined by the value of the severe flag.
     *
     * @param url the URL to be checked in a string form
     * @param severe if true then an invalid url will be an Error; otherwise 
     *              it will be a Warning.
     * @return true if url is valid
     * @throws ApplierException if the url is not valid
     */
    public static boolean validateURL(String url, boolean severe) throws ApplierException {
	try {
	    return validateURL(new URL(url), severe);
	} catch (MalformedURLException ex) {
	    String message = "Malformed URL: " + url;
	    if (severe) {
		throw new ApplierError(message, ex);
	    } else {
		throw new ApplierWarning(message, ex);
	    }
	}
    }

    /**
     * Checks the url to determine if it is valid. Will throw an exception if invalid.
     * The type of exception is determined by the value of the severe flag.
     *
     * @param url the URL to be checked
     */
    public static boolean validateURL(URL url) throws ApplierException {
	return validateURL(url, true);
    }

    /**
     * Checks the url to determine if it is valid. Will throw an exception if invalid.
     * The type of exception is determined by the value of the severe flag.
     *
     * @param url the URL to be checked
     * @param severe if true then an invalid url will be an Error; otherwise 
     *              it will be a Warning.
     * @return true if url is valid
     * @throws ApplierException if the url is not valid
     */
    public static boolean validateURL(URL url, boolean severe) throws ApplierException {
	if (url != null) {
	    String protocol = url.getProtocol();
	    if ("file".equals(protocol)) {
		return validateFileURL(url, severe);
	    } else if ("http".equals(protocol) || "https".equals(protocol)) {
		return validateHttpURL(url, severe);
	    }
	}
	return false;
    }

    private static boolean validateFileURL(URL url, boolean severe) throws ApplierException {
	try {
	    File file = new File(url.getFile());
	    return file.canRead();
	} catch (Exception ex) {
	    String message = "Cannot read file: " + url.toExternalForm();
	    if (severe) {
		throw new ApplierError(message, ex);
	    } else {
		throw new ApplierWarning(message, ex);
	    }
	}
    }

    private static boolean validateHttpURL(URL url, boolean severe) throws ApplierException {
	Socket connection = null;
	try {
	    int port = url.getPort();
	    if (port == -1) {
		port = url.getDefaultPort();
	    }
	    connection = new Socket(url.getHost(), port);
	} catch (UnknownHostException ex0) {
	    String message = "Cannot find host for: " + url.toExternalForm();
	    if (severe) {
		throw new ApplierError(message, ex0);
	    } else {
		throw new ApplierWarning(message, ex0);
	    }
	} catch (IOException ex) {
	    String message = "Cannot open connection to: " + url.toExternalForm();
	    if (severe) {
		throw new ApplierError(message, ex);
	    } else {
		throw new ApplierWarning(message, ex);
	    }
	} 
	finally {
	    if (connection != null) {
		try {
		    connection.close();
		} catch (IOException ex) {
		    throw new ApplierException("Error closing Socket for URL: " + 
					       url.toExternalForm(), ex);
		}
	    }
	}
	return true;
    }

    public static Realizable getRealizable(Element element) {
        // In XOR, native element implementations and the corresponding Realizable
        // are one and the same, but it stores the Realizable for plug-in element
        // implementations in the dom element's user data (or user object).

        Object userObject = null;

        // For Crimson:
        //userObject = ((org.apache.crimson.tree.ElementNode) element).getUserObject();

        // For Xerces:
	try {
	    Class clz = Class.forName("org.apache.xerces.dom.NodeImpl");
	    if (element.getClass() == clz) {
		userObject = (new Expression(element, "getUserData", new Object[0])).getValue();
	    }
	} catch (ClassNotFoundException ex) {
	    // NodeImpl not found. Ignore.
	} catch (Exception ex) {
	    // Any other exception is worth noting.
	    throw new RuntimeException("Error invoking getUserData for " + element.toString(), ex);
	}

	if (!(userObject instanceof Realizable)) {
	    // For Sun Object Realizer:
	    ObjectRealizer or = getObjectRealizer();

	    try {
		userObject = (Realizable)(new Expression(or, "getRealizable",
						     new Object[] { element })).getValue();
	    } catch (Exception ex) {
		String message = "Error getting Realizable from " + element.toString();
		throw new RuntimeException(message, ex);
	    }
	}
	return (Realizable) (userObject == null ? element : userObject);
    }

    /**
     * Logs the exception. If the exception represents a {@link net.openmarkup.Error }
     * then it will be rethrown. The logging Level will be determined based on the
     * type of exception. For a Glich, an INFO message will be sent, Error -> SEVERE,
     * Warning -> WARNING
     * 
     * @param messgae Message to send to logger
     * @param ex the exception to log
     * @throws RuntimeException if the exception represents an Error
     * @see net.openmarkup.Error
     * @see net.openmarkup.Glich
     * @see net.openmarkup.Warning
     */
    public static void logException(String message, Exception ex) {
	Level level = Level.INFO;

	if (ex instanceof Error) {
	    level = Level.SEVERE;
	} 
	else if (ex instanceof Glitch) {
	    level = Level.INFO;
	}
	else if (ex instanceof Warning) {
	    level = Level.WARNING;
	}
	else {
	    // Any other exception is a severe
	    level = Level.SEVERE;
	}
	Scribe.getLogger().log(level, message, ex);

	if (ex instanceof Error) {
	    // If this represents a serious error then this shudl bubble up
	    throw new RuntimeException(ex);
	}
    }

    /**
     * Serious hack. Use reflection to get the Sun OR singleton.
     * yes. I'm a sick puppy.
     * This should be consolidated with runner.Application.getObjectRealizer
     */
    public static ObjectRealizer getObjectRealizer() {
	String realizerImplName = null;
	try {
	    // The OR implementation should be looked up in System.properties.
	    realizerImplName = System.getProperty("openmarkup.realizer.impl");
	    if (realizerImplName == null) {
		// This should be an Env property.
		realizerImplName = "org.jdesktop.openmarkup.ri.ObjectRealizerImpl";
	    }
	} catch (SecurityException ex) {
	    // Access to properties are not allowed. For example, in sandboxed
	    // applications.
	    realizerImplName = "org.jdesktop.openmarkup.ri.ObjectRealizerImpl";
	}

	ObjectRealizer realizer = null;
	try {
	    Class clz = Class.forName(realizerImplName);
	    Object or = clz.newInstance();

	    // XXX this is a big hack since the Sun ObjectRealizer doesn't
	    // use net.openmarkup.Document. 
	    try {
		realizer = (ObjectRealizer)(new Expression(or, "getInstance",
							   new Object[0])).getValue();
	    } catch (Exception ex) {
		// error
	    }

	    if (realizer == null) {
		realizer = (ObjectRealizer)or;
	    }
	} catch (Exception ex) {
	    throw new RuntimeException("Cannot find ObjectRealizer: " + realizerImplName, ex);
	}
	return realizer;
    }

    /**
     * Returns a url based on which is resolved according to the precedence 
     * rules in
     *     http://www.w3c.org/TR/xmlbase
     *     http://www.ietf.org/rfc/rfc2396.txt section 5.1
     *
     * @see net.openmarkup.Realizable#getResolvedURL
     */
     public static URL getResolvedURL(Realizable realizable, String uri) {
	URL url = null;

	// using the xml:base attribute
	Document doc = realizable.getOwnerDocument();
	Element docElement = doc.getDocumentElement();
	String base = docElement.getAttributeNS("http://www.w3.org/XML/1998/namespace", "base");
	if (base != null && !base.equals("")) {
	    try {
		url = new URL(new URL(base), uri);
	    } catch (MalformedURLException ex) {
		//
	    }
	}
	if (url == null) {
	    try {
		url = new URL(getObjectRealizer().getDefaultBaseURL(), uri);
		// Test the url
	    } catch (MalformedURLException ex) {
		url = realizable.getClass().getResource(uri);
	    }
	    //	    Scribe.getLogger().info("getResolvedURL("+ uri + ") -> " + url);
	}
        return url;

    }
}
