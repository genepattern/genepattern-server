/*
 * $Id: NullAttribute.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.AttributeHandler;
import net.openmarkup.Realizable;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;

/**
 * This class contains the static nullApplier - which does nothing.
 */
public class NullAttribute {
    
    /**
     * The nullApplier should be used with for {@link AttributeHandler}s for attributes
     * which are not handled by AttributeAppliers.
     * <p>
     * For example, many of the "id" attributes  
     */
    public static final AttributeApplier nullApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws
            ApplierException {
	    // Does nothing
        }
    };

    /**
     * Shared AttributeHandler for the "id" attribute.
     */
    public static final AttributeHandler idHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ID,
                             NullAttribute.nullApplier);

    /**
     * Shared AttributeHandler for the "value" attribute.
     */
    public static final AttributeHandler valueHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.VALUE, 
			     NullAttribute.nullApplier);

}
