/*
 * $Id: ActionPanelElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.jdnc.JNForm;

import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JComponent;

import org.w3c.dom.Element;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;

/**
 *
 * @author Amy Fowler
 */
public class ActionPanelElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    public ActionPanelElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            elementMap.put(Namespace.JDNC + ":" + ElementTypes.RESET.getLocalName(),
                           resetActionElementHandler);
            elementMap.put(Namespace.JDNC + ":" + ElementTypes.SUBMIT.getLocalName(),
                           submitActionElementHandler);
            //elementMap.put(Namespace.JDNC + ":" + ElementTypes.ACTION.getLocalName(),
                           //actionElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator actionAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNForm form = (JNForm)ElementProxy.getRealizable(
                (Element)parent.getParentNode()).getObject();
            Action action = (Action) child.getObject();
            form.addAction(action);
        }
    };

    protected static final ElementHandler		resetActionElementHandler =
        new ElementHandler(ElementTypes.RESET, ActionPanelElement.actionAssimilator);

    protected static final ElementHandler		submitActionElementHandler =
        new ElementHandler(ElementTypes.SUBMIT, ActionPanelElement.actionAssimilator);
}
