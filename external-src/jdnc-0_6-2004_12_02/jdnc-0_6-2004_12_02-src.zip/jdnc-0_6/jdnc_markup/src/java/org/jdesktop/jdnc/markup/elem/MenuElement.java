/*
 * $Id: MenuElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JSeparator;

import org.w3c.dom.Element;
import org.jdesktop.swing.Application;
import org.jdesktop.swing.actions.ActionContainerFactory;
import org.jdesktop.swing.actions.ActionManager;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.RealizationUtils;
import org.jdesktop.jdnc.markup.attr.MenuAttributes;
import org.jdesktop.jdnc.markup.attr.NullAttribute;
import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

public class MenuElement extends ElementProxy {
    private static final Map attrMap = new Hashtable();
    private static final Map elementMap = new Hashtable();

    public MenuElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Object instantiate() {
        Action action = null;
        String id = this.getAttributeNSOptional(Namespace.JDNC,
                                                Attributes.ACTION_REF);
        if (id.length() > 0) {
            // Get the action
            action = (Action) RealizationUtils.getReferencedObject(this, id);
            if (action == null) {
                throw new RuntimeException(id + " action not found");
            }
        }

        JComponent menu = (JComponent)super.instantiate();
        if (action != null && menu instanceof AbstractButton) {
            // Create a menu item from the action
            ( (AbstractButton) menu).setAction(action);
        }
        return menu;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TITLE,
                           titleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MNEMONIC,
                           mnemonicHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DESCRIPTION,
                           descriptionHandler);

	    // Register null appliers. These attributes are handled elsewhere
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ACTION_REF,
                           actionRefHandler);
        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.MENU.getLocalName(),
                           menuElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.SEPARATOR.getLocalName(),
                           separatorElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.ACTION.getLocalName(),
                           actionElementHandler);
        }
        return handlerMap;
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.TITLE);
        applyAttribute(Namespace.JDNC, Attributes.MNEMONIC);
        applyAttribute(Namespace.JDNC, Attributes.DESCRIPTION);
    }

    public static final ElementAssimilator menuAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JComponent parentMenu = (JComponent) parent.getObject();
            JMenu menu = (JMenu) child.getObject();
            parentMenu.add(menu);
        }
    };

    public static final ElementAssimilator separatorAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JComponent menu = (JComponent) parent.getObject();
            JSeparator separator = (JSeparator) child.getObject();
            menu.add(separator);
        }
    };

    public static final ElementAssimilator actionAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JComponent menu = (JComponent) parent.getObject();

            ActionManager manager = Application.getInstance().getActionManager();
            ActionContainerFactory factory = manager.getFactory();

            menu.add(factory.createMenuItem( (Action) child.getObject(), menu));
        }
    };

    public static final ElementAssimilator groupAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JComponent menu = (JComponent) parent.getObject();
            Vector vector = (Vector) child.getObject();

            ActionManager manager = Application.getInstance().getActionManager();
            ActionContainerFactory factory = manager.getFactory();

            Iterator iter = vector.iterator();
            while (iter.hasNext()) {
                menu.add(factory.createMenuItem( (Action) iter.next(), menu));
            }
        }
    };

    private static final AttributeHandler actionRefHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ACTION_REF,
                             NullAttribute.nullApplier);
    private static final AttributeHandler titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE,
                             MenuAttributes.titleApplier);
    private static final AttributeHandler mnemonicHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.MNEMONIC,
                             MenuAttributes.mnemonicApplier);
    private static final AttributeHandler descriptionHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DESCRIPTION,
                             MenuAttributes.descriptionApplier);

    protected static final ElementHandler menuElementHandler =
        new ElementHandler(ElementTypes.MENU, MenuElement.menuAssimilator);
    protected static final ElementHandler separatorElementHandler =
        new ElementHandler(ElementTypes.SEPARATOR,MenuElement.separatorAssimilator);
    protected static final ElementHandler actionElementHandler =
        new ElementHandler(ElementTypes.ACTION, MenuElement.actionAssimilator);
}
