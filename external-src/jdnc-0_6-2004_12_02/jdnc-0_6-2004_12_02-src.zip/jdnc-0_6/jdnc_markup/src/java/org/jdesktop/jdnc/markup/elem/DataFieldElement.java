/*
 * $Id: DataFieldElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.data.EnumeratedMetaData;
import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.NumberMetaData;
import org.jdesktop.swing.data.StringMetaData;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.DataFieldAttributes;
import org.jdesktop.jdnc.markup.attr.Decoder;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Amy Fowler
 */
public class DataFieldElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    public DataFieldElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Object instantiate() {
        // determine which class of meta-data to instantiate....
        NodeList children = getElementsByTagNameNS(Namespace.JDNC,
            ElementTypes.FIELD_META_DATA_ENUM_VALUES.getLocalName());
        if (children.getLength() > 0) {
            return new EnumeratedMetaData();
        }
        String value = getAttributeNSOptional(Namespace.JDNC, Attributes.DATA_TYPE);
        // if DATA_TYPE not set, then defaults to String
        if (value.length() > 0) {
            Class type = Decoder.decodeType(value);
            if (type != null) {
                if (Number.class.isAssignableFrom(type)) {
                    return new NumberMetaData();
                } else if (type != String.class) {
                    return new MetaData();
                }
            }
        }
        return new StringMetaData();
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected void applyAttributesAfter() {
        MetaData metaData = (MetaData)getObject();
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.DATA_TYPE);
        applyAttribute(Namespace.JDNC, Attributes.TITLE);
        applyAttribute(Namespace.JDNC, Attributes.NAME);
        applyAttribute(Namespace.JDNC, Attributes.DECODE_FORMAT);
        applyAttribute(Namespace.JDNC, Attributes.ENCODE_FORMAT);
        applyAttribute(Namespace.JDNC, Attributes.IS_READ_ONLY);
        applyAttribute(Namespace.JDNC, Attributes.IS_REQUIRED);
        if (metaData instanceof NumberMetaData) {
            applyAttribute(Namespace.JDNC, Attributes.MINIMUM);
            applyAttribute(Namespace.JDNC, Attributes.MAXIMUM);
        } else if (metaData instanceof StringMetaData) {
            applyAttribute(Namespace.JDNC, Attributes.DISPLAY_SIZE);
            applyAttribute(Namespace.JDNC, Attributes.MULTI_LINE);
            applyAttribute(Namespace.JDNC, Attributes.MINIMUM_FIELD_SIZE);
            applyAttribute(Namespace.JDNC, Attributes.MAXIMUM_FIELD_SIZE);
        }
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DATA_TYPE,
                           typeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TITLE,
                           titleHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.NAME, nameHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MAXIMUM,
                           maximumHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MAXIMUM_FIELD_SIZE,
                           maximumFieldSizeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DECODE_FORMAT,
                           decodeFormatHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ENCODE_FORMAT,
                           encodeFormatHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DISPLAY_SIZE,
                           displaySizeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MINIMUM,
                           minimumHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MINIMUM_FIELD_SIZE,
                           maximumFieldSizeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.MULTI_LINE,
                           multiLineHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_READ_ONLY,
                           isReadOnlyHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_REQUIRED,
                           isRequiredHandler);
        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.FIELD_META_DATA_ENUM_VALUES.getLocalName(),
                           dataEnumerationElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator	dataEnumerationAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            EnumeratedMetaData metaData = (EnumeratedMetaData)parent.getObject();
            List enumeration = (List)child.getObject();
            metaData.setEnumeration(enumeration);
        }
    };


    private static final AttributeHandler	typeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DATA_TYPE,
                             DataFieldAttributes.typeApplier);

    private static final AttributeHandler	displaySizeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DISPLAY_SIZE,
                             DataFieldAttributes.displaySizeApplier);

    private static final AttributeHandler	decodeFormatHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DECODE_FORMAT,
                             DataFieldAttributes.decodeFormatApplier);

    private static final AttributeHandler	encodeFormatHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ENCODE_FORMAT,
                             DataFieldAttributes.encodeFormatApplier);

    private static final AttributeHandler	titleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TITLE,
                             DataFieldAttributes.titleApplier);

    private static final AttributeHandler	maximumHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.MAXIMUM,
                             DataFieldAttributes.maximumApplier);

    private static final AttributeHandler	maximumFieldSizeHandler =
    new AttributeHandler(Namespace.JDNC, Attributes.MAXIMUM_FIELD_SIZE,
                         DataFieldAttributes.maximumFieldSizeApplier);

    private static final AttributeHandler	minimumHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.MINIMUM,
                             DataFieldAttributes.minimumApplier);

    private static final AttributeHandler	minimumFieldSizeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.MINIMUM_FIELD_SIZE,
                             DataFieldAttributes.minimumFieldSizeApplier);

    private static final AttributeHandler	multiLineHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.MULTI_LINE,
                             DataFieldAttributes.multiLineApplier);

    private static final AttributeHandler	nameHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.NAME,
                             DataFieldAttributes.nameApplier);

    private static final AttributeHandler	isReadOnlyHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_READ_ONLY,
                             DataFieldAttributes.isReadOnlyApplier);

    private static final AttributeHandler	isRequiredHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_REQUIRED,
                             DataFieldAttributes.isRequiredApplier);

    private static final ElementHandler	 dataEnumerationElementHandler =
         new ElementHandler(ElementTypes.FIELD_META_DATA_ENUM_VALUES,
                            dataEnumerationAssimilator);


}