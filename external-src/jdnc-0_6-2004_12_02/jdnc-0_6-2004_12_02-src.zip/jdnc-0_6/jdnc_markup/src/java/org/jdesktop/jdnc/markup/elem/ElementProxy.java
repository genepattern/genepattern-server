/*
 * $Id: ElementProxy.java,v 1.4 2004/07/28 00:51:44 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

/**
 * Copyright (c) 2001-2003 eNode, Inc.  All rights reserved.
 */

import java.beans.Beans;
import java.beans.Expression;
import java.beans.Statement;

import java.net.URL;
import java.net.MalformedURLException;

import java.util.Map;
import java.util.Date;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3c.dom.*;

import net.openmarkup.AttributeHandler;
import net.openmarkup.Attributes;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Env;
import net.openmarkup.ObjectRealizer;
import net.openmarkup.Realizable;
import net.openmarkup.Scribe;

// Exceptions and error handling stuff
import net.openmarkup.AssimilatorException;
import net.openmarkup.ApplierException;

import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.RealizationUtils;

/**
 * Represents an element node in a DOM without requiring the DOM implementation
 * to be subclassed. This is important for JAXP version 1.2 and earlier, which
 * effectively disables DOM subclassing in sandboxed code by not providing any
 * way for such code to override the default document builder factory.
 *
 * @author Ramesh Gupta
 * @author ???
 */
public abstract class ElementProxy implements Realizable {

    public static Realizable getRealizable(Element element) {
	return RealizationUtils.getRealizable(element);
    }

    public static int getIndexWithinParent(Element element) {
        Element parent = (Element) element.getParentNode();
        NodeList siblings = parent.getChildNodes();
        int elementIndex = -1;
        int count = 0;
        for (int i = 0; i < siblings.getLength(); i++) {
            Node sibling = siblings.item(i);
            if (sibling.getNodeType() == Node.ELEMENT_NODE) {
                if (element == sibling) {
                    elementIndex = count;
                    break;
                }
                count++;
            }
        }
        return elementIndex;
     }

    /**
     * Convenience method for getting a stored value on the ObjectRealizer.
     */
    public Object getORValue(Object key) {
	// For Sun Object Realizer:
	ObjectRealizer or = getObjectRealizer();
	Object value = null;
	try {
	    value = (new Expression(or, "getValue",
				    new Object[] { key })).getValue();
	} catch (Exception ex) {
	    throw new RuntimeException("Error getValue from ObjectRealizer " + key.toString(), ex);
	}
	return value;
    }


    /**
     * Convenience method for setting a stored value on the ObjectRealizer.
     */
    public void putORValue(Object key, Object value) {
	// For Sun Object Realizer:
	ObjectRealizer or = getObjectRealizer();
	try {
	    (new Statement(or, "putValue", new Object[] { key, value })).execute();
	} catch (Exception ex) {
	    throw new RuntimeException("Error putValue from ObjectRealizer " + key.toString(), ex);
	}
    }

    public ElementProxy(Element element, ElementType elementType) {
        // Binding between the DOM element and this ElementRepresentation is
        // immutable. Structural changes to the DOM, if any, must happen at the
        // dom element level, not at the element representation level.
        this.element = element;			// immutable
        this.elementType = elementType;	// immutable

        registerAttributeHandlers();
        registerElementHandlers();
    }

    public ElementType getElementType() {
        return elementType;
    }

    public ElementHandler getElementHandler(String namespaceURI, String elementName) {
        Map	handlerMap = getElementHandlerMap();
        return handlerMap == null ? null : (ElementHandler) handlerMap.get(namespaceURI + ":" + elementName);
    }

    public AttributeHandler getAttributeHandler(String namespaceURI, String attrName) {
        Map	handlerMap = getAttributeHandlerMap();
        return handlerMap == null ? null : (AttributeHandler) handlerMap.get(namespaceURI + ":" + attrName);
    }

    public Object getObject() {
        if (object == null) {
            // instantiate the object for this element
            object = instantiate();
            if (object != null) {
                Scribe.getLogger().fine("Object instantiated: " +
                                        object.getClass().getName());
            }
            checkAttributes();

            applyAttributesBefore();
            assimilateChildren();
            applyAttributesAfter();

            if (object != null) {
                Scribe.getLogger().fine("Object Realized: " +
                                        object.getClass().toString());
            }
        }
        return object;
    }

    public String getObjectClassName() {
        if (objectClassName == null) {
            // Always call getDOMElement() instead of referring to element directly
            Element	domElement = getDOMElement();
            // First try to get object class name from markup attribute
            String	name = domElement.getAttributeNS(Namespace.JDNC, Attributes.CLASS);
            if (name.length() == 0) {
                // Try without namespace prefix
                name = domElement.getAttribute(Attributes.CLASS);
                if (name.length() == 0) {
                    // Couldn't find "class" attribute with or without namespace
                    name = getElementType().getObjectClassName();
                }
            }
            objectClassName = name;
        }
        return objectClassName;
    }

    protected Object instantiate() {
        String	className = elementType.getObjectClassName();
        Object	obj = null;
        if (className != null) {
            try {
                obj = Beans.instantiate(Env.getClassLoader(), className);
            }
            catch (Exception ex) {
		logException("Error instantiatiating: " + className, ex);
            }
        }
        return obj;
    }

    public Realizable getDelegate() {
        return this;	// place to plug-in external helper objects
    }

    public URL getResolvedURL(String uri) {
	Document doc = getOwnerDocument();
	if (doc instanceof net.openmarkup.Document) {
	    return ((net.openmarkup.Document)doc).getResolvedURL(uri);
	}
	return RealizationUtils.getResolvedURL(this, uri);
    }

    public ObjectRealizer getObjectRealizer() {
	Document doc = getOwnerDocument();
	if (doc instanceof net.openmarkup.Document) {
	    return ((net.openmarkup.Document)doc).getObjectRealizer();
	}
	return RealizationUtils.getObjectRealizer();
    }

    public Element getDOMElement() {
        // Always access element through this method, even in this class.
        // That keeps the door open for DOM element to be created lazily.
        return element;
    }

    protected Map registerAttributeHandlers() {
        // Nothing to register in base class; simply return the empty map
        return getAttributeHandlerMap();
    }

    protected Map registerElementHandlers() {
        // Nothing to register in base class; simply return the empty map
        return getElementHandlerMap();
    }

    /**
     * Checks the all the attributes on the current element to see
     * if there are attribute handlers.
     * Send a WARNING to the logger if any are missing.
     */
    protected void checkAttributes() {
        if (hasAttributes() == false || getAttributes() == null) {
            return;
        }
        NamedNodeMap map = getAttributes();
        String localName;
        for (int i = 0, length = map.getLength(); i < length; i++) {
            Node node = map.item(i);
            if (node != null) {
                localName = node.getLocalName();
                // xml:id should never produce a warning
                // currently some documents do not declare usage of XML namespace,
                // so we'll be forgiving for now and not check the namespace
                if (!(localName.equals("id") /*&& /getNamespaceURI().equals(Namespace.XML)*/) &&
                       (getAttributeHandler(getNamespaceURI(), localName) == null)) {
                    StringBuffer details = new StringBuffer("\"");
                    // RG: Fix for J2SE 5.0; Can't cascade append() calls because
                    // return type in StringBuffer and AbstractStringBuilder are different
                    try {
                    details.append(localName);
                    details.append('=');
                    details.append(node.getNodeValue());
                    details.append("\" on \"");
                    details.append(getLocalName());
                    details.append('"');
                    }
                    catch (Exception ex) {  // RG: append(char) throws IOException in J2SE 5.0
                        Scribe.getLogger().warning("Unsupported attribute : " +
                                                   details + "; DETAILS MIGHT BE INCOMPLETE.");
                    }
                    Scribe.getLogger().warning("Unsupported attribute : " +
                                               details);
                }
            }
        }
    }

    /**
     * Overriden in the subclass to apply attributes <i>before</i> the child
     * elements are assimilated.
     */
    protected void applyAttributesBefore() {
    }

    /**
     * Overriden in the subclass to apply attributes <i>after</i> the child
     * elements are assimilated.
     */
    protected void applyAttributesAfter() {
    }

    protected void assimilateChildren() {
        NodeList children = getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                Realizable realizableChild =
                    ElementProxy.getRealizable( (Element) child);

                if (realizableChild != null) {
                    realizableChild.getObject(); // get object before assimilating

                    StringBuffer details = new StringBuffer("\"");
                    // RG: Fix for J2SE 5.0; Can't cascade append() calls because
                    // return type in StringBuffer and AbstractStringBuilder are different
                    details.append(realizableChild.getLocalName());
                    details.append("\" into \"");
                    details.append(getLocalName());
                    details.append("\"");

                    try {
                        // get the appropriate assimilator:
                        String nsURI = child.getNamespaceURI();
                        String localName = child.getLocalName();
                        ElementHandler handler = getElementHandler(nsURI,
                            localName);
                        if (handler != null) {
                            ElementAssimilator assimilator = handler.
                                getElementAssimilator();
                            assimilator.assimilate(this, realizableChild);

                            Scribe.getLogger().fine("Element assimilated: " +
                                details);
                        }
                        else {
                            Scribe.getLogger().warning(
                                "Element assimilator not found: " + details);
                        }
                    }
                    catch (AssimilatorException ex) {
                        logException(
                            "AssimilatorException assimilating element: " +
                            details, ex);
                    }
                    catch (Exception ex2) {
                        logException("Exception assimilating element: " +
                                     details, ex2);
                    }
                }
            }
        }
    }

    protected void applyAttribute(String namespaceURI, String localName) {
        String attrValue = getAttributeNSOptional(namespaceURI, localName);
        if (attrValue.length() == 0) {
            attrValue = getAttribute(localName); // Try without namespace prefix
        }

        if (attrValue.length() != 0) {
            // Use both namespaceURI and localName when looking up handler!
            AttributeHandler handler = getAttributeHandler(namespaceURI,
                localName);

            StringBuffer details = new StringBuffer("\"");
            // RG: Fix for J2SE 5.0; Can't cascade append() calls because
            // return type in StringBuffer and AbstractStringBuilder are different
            try {
            details.append(localName);
            details.append('=');
            details.append(attrValue);
            details.append("\" on \"");
            details.append(getLocalName());
            details.append('"');
        }
        catch (Exception ex) {  // RG: append(char) throws IOException in J2SE 5.0
            Scribe.getLogger().warning("Unsupported attribute : " +
                                       details + "; DETAILS MIGHT BE INCOMPLETE.");
        }

            if (handler != null) {
                try {
                    handler.getApplier().apply(this, namespaceURI, localName,
                                               attrValue);

                    Scribe.getLogger().fine("Attribute applied: " + details);
                }
                catch (ApplierException ex) {
                    RealizationUtils.logException(
                        "ApplierException applying attribute: " + details, ex);
                }
                catch (Exception ex2) {
                    RealizationUtils.logException(
                        "Exception applying attribute: " + details, ex2);
                }
            }
            else {
                Scribe.getLogger().warning("Unsupported attribute : " +
                                           details);
            }
        }
    }

    /**
     * Handles all exception information. This belongs in some sort of Utility class
     * @throws RuntimeException if the exception represents an Error
     */
    protected void logException(String message, Exception ex) {
        RealizationUtils.logException(message, ex);
    }

    /**
     * Returns attribute with lax namespace lookup if attribute is not found in
     * the specified namespace.
     *
     * @param nsURI
     * @param localName
     * @return attribute value if the specified attribute is present in this element
     */
    public String getAttributeNSOptional(String nsURI, String localName) {
        // Always call getDOMElement() instead of referring to element directly
        Element element = getDOMElement();
        String value = null;

        try {
            element.getAttributeNS(nsURI, localName);
        }
        catch (NullPointerException ex) {
            // Yes it's not good to catch an NPE but there seems to be a
            // bug in the crimson parser in 1.4.2. Pehaps this will be
            // fixed when deployed under xerces on 1.5
        }
        if (value == null || value.length() == 0) {
            value = element.getAttribute(localName);
        }
        return value;
    }

    protected Map getAttributeHandlerMap() {
        return null;
    }

    protected Map getElementHandlerMap() {
        return null;
    }

    // ======================================================================
    // W3C DOM Methods
    // ======================================================================

    public String getTagName() {
        return getDOMElement().getTagName();
    }

    public String getAttribute(String name) {
        return getDOMElement().getAttribute(name);
    }

    public void setAttribute(String name, String value) throws DOMException {
        getDOMElement().setAttribute(name, value);
    }

    public void removeAttribute(String name) throws DOMException {
        getDOMElement().removeAttribute(name);
    }

    public Attr getAttributeNode(String name) {
        return getDOMElement().getAttributeNode(name);
    }

    public Attr setAttributeNode(Attr newAttr) throws DOMException {
        return getDOMElement().setAttributeNode(newAttr);
    }

    public Attr removeAttributeNode(Attr oldAttr) throws DOMException {
        return getDOMElement().removeAttributeNode(oldAttr);
    }

    public NodeList getElementsByTagName(String name) {
        return getDOMElement().getElementsByTagName(name);
    }

    public String getAttributeNS(String namespaceURI, String localName) {
        return getDOMElement().getAttributeNS(namespaceURI, localName);
    }

    public void setAttributeNS(String namespaceURI, String qualifiedName,
                               String value) throws DOMException {
        getDOMElement().setAttributeNS(namespaceURI, qualifiedName, value);
    }

    public void removeAttributeNS(String namespaceURI, String localName) throws
        DOMException {
        getDOMElement().removeAttributeNS(namespaceURI, localName);
    }

    public Attr getAttributeNodeNS(String namespaceURI, String localName) {
        return getDOMElement().getAttributeNodeNS(namespaceURI, localName);
    }

    public Attr setAttributeNodeNS(Attr newAttr) throws DOMException {
        return getDOMElement().setAttributeNodeNS(newAttr);
    }

    public NodeList getElementsByTagNameNS(String namespaceURI,
                                           String localName) {
        return getDOMElement().getElementsByTagNameNS(namespaceURI, localName);
    }

    public boolean hasAttribute(String name) {
        return getDOMElement().hasAttribute(name);
    }

    public boolean hasAttributeNS(String namespaceURI, String localName) {
        return getDOMElement().hasAttributeNS(namespaceURI, localName);
    }

    public String getNodeName() {
        return getDOMElement().getNodeName();
    }

    public String getNodeValue() throws DOMException {
        return getDOMElement().getNodeValue();
    }

    public void setNodeValue(String nodeValue) throws DOMException {
        getDOMElement().setNodeValue(nodeValue);
    }

    public short getNodeType() {
        return getDOMElement().getNodeType();
    }

    public Node getParentNode() {
        return getDOMElement().getParentNode();
    }

    public NodeList getChildNodes() {
        return getDOMElement().getChildNodes();
    }

    public Node getFirstChild() {
        return getDOMElement().getFirstChild();
    }

    public Node getLastChild() {
        return getDOMElement().getLastChild();
    }

    public Node getPreviousSibling() {
        return getDOMElement().getPreviousSibling();
    }

    public Node getNextSibling() {
        return getDOMElement().getNextSibling();
    }

    public NamedNodeMap getAttributes() {
        return getDOMElement().getAttributes();
    }

    public Document getOwnerDocument() {
        return getDOMElement().getOwnerDocument();
    }

    public Node insertBefore(Node newChild, Node refChild) throws DOMException {
        return getDOMElement().insertBefore(newChild, refChild);
    }

    public Node replaceChild(Node newChild, Node oldChild) throws DOMException {
        return getDOMElement().replaceChild(newChild, oldChild);
    }

    public Node removeChild(Node oldChild) throws DOMException {
        return getDOMElement().removeChild(oldChild);
    }

    public Node appendChild(Node newChild) throws DOMException {
        return getDOMElement().appendChild(newChild);
    }

    public boolean hasChildNodes() {
        return getDOMElement().hasChildNodes();
    }

    public Node cloneNode(boolean deep) {
        if (deep) {
            /**@todo Implement deep cloneNode() method*/
            throw new UnsupportedOperationException(
                "Method deep cloneNode() not yet implemented.");
        }

        return getDOMElement().cloneNode(false); // shallow clone
    }

    public void normalize() {
        getDOMElement().normalize();
    }

    public boolean isSupported(String feature, String version) {
        return getDOMElement().isSupported(feature, version);
    }

    public String getNamespaceURI() {
        return getDOMElement().getNamespaceURI();
    }

    public String getPrefix() {
        return getDOMElement().getPrefix();
    }

    public void setPrefix(String prefix) throws DOMException {
        getDOMElement().setPrefix(prefix);
    }

    public String getLocalName() {
        return getDOMElement().getLocalName();
    }

    public boolean hasAttributes() {
        return getDOMElement().hasAttributes();
    }

/*  UNCOMMENT FOR J2SE 5.0
    public String getBaseURI() {
        return getDOMElement().getBaseURI();
    }

    public Object getFeature(String feature,
                  String version) {
        return getDOMElement().getFeature(feature, version);
    }

    public TypeInfo getSchemaTypeInfo() {
        return getDOMElement().getSchemaTypeInfo();
    }

    public Object getUserData(String key) {
        return getDOMElement().getUserData(key);
    }

    public Object setUserData(String key, Object data, UserDataHandler handler) {
        return getDOMElement().setUserData(key, data, handler);
    }

    public boolean isDefaultNamespace(String namespaceURI) {
        return getDOMElement().isDefaultNamespace(namespaceURI);
    }

    public boolean isEqualNode(Node arg) {
        // @todo Test this!!!
        try {
            return getDOMElement().isEqualNode(((ElementProxy)arg).getDOMElement());
        }
        catch (Exception ex) {
            return false;
        }
    }

    public boolean isSameNode(Node arg) {
        // @todo Test this!!!
        try {
            // When two Node references are references to the same object,
            // EVEN IF THROUGH A PROXY, the references may be used interchangeably
            // In other words, even if "this" and "arg" are different objects,
            // they would be considerd SAME if their respective DOM elements
            // return true for isSameNode() for each other.
            return getDOMElement().isSameNode(((ElementProxy)arg).getDOMElement());
        }
        catch (Exception ex) {
            return false;
        }
    }

    public short compareDocumentPosition(Node other) throws DOMException {
        // @todo Test this!!!
        try {
            return getDOMElement().compareDocumentPosition(((ElementProxy)other).getDOMElement());
        }
        catch (Exception ex) {
            return 0;
        }
    }

    public String lookupNamespaceURI(String prefix) {
        return getDOMElement().lookupNamespaceURI(prefix);
    }

    public String lookupPrefix(String namespaceURI) {
        return getDOMElement().lookupPrefix(namespaceURI);
    }

    public void setIdAttribute(String name, boolean isId) throws DOMException {
        getDOMElement().setIdAttribute(name, isId);
    }

    public void setIdAttributeNode(Attr idAttr, boolean isId) throws DOMException {
        getDOMElement().setIdAttributeNode(idAttr, isId);
    }

    public void setIdAttributeNS(String namespaceURI, String localName, boolean isId)
        throws DOMException {
        getDOMElement().setIdAttributeNS(namespaceURI, localName, isId);
    }

    public String getTextContent() throws DOMException {
        return getDOMElement().getTextContent();
    }

    public void setTextContent(String textContent) throws DOMException {
        getDOMElement().setTextContent(textContent);
    }
*/
    private final org.w3c.dom.Element element; // immutable
    protected final ElementType elementType; // immutable
    protected Object object = null; // realized object
    protected String objectClassName = null;
}
