/*
 * $Id: HighlighterAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.swing.data.MetaData;

import org.jdesktop.swing.decorator.AlternateRowHighlighter;
import org.jdesktop.swing.decorator.ConditionalHighlighter;
import org.jdesktop.swing.decorator.Highlighter;
import org.jdesktop.jdnc.*;
import org.jdesktop.jdnc.markup.*;
import org.jdesktop.jdnc.markup.elem.ElementProxy;
import org.jdesktop.swing.data.*;
import org.jdesktop.swing.table.*;

import java.awt.Color;

import net.openmarkup.AttributeApplier;
import net.openmarkup.*;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Flyweight implementations for highlighter attribute appliers.
 *
 * @author Ramesh Gupta
 */
public class HighlighterAttributes {
    public static final AttributeApplier	backgroundApplier = new AttributeApplier() {
        /**
         * @tolerant
         */
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Color	color = Decoder.decodeColor(attributeValue);
            ((Highlighter) target.getObject()).setBackground(color);
        }
    };

    public static final AttributeApplier	highlightColumnApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            int columnIndex = TableColumnAttributes.getModelIndex(target, attributeValue);
            if (columnIndex >= 0) {
                ((ConditionalHighlighter) target.getObject()).setHighlightColumnIndex(columnIndex);
            }
        }
    };

/*
    public static final AttributeApplier	highlightColumnIndexApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            ((ConditionalHighlighter) target.getObject()).setHighlightColumnIndex(
                Integer.parseInt(attributeValue));
        }
    };
*/
    public static final AttributeApplier	evenRowBackgroundApplier = new AttributeApplier() {
        /**
         * @tolerant
         */
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Color	color = Decoder.decodeColor(attributeValue);
            ((AlternateRowHighlighter) target.getObject()).setEvenRowBackground(color);
        }
    };

    public static final AttributeApplier	foregroundApplier = new AttributeApplier() {
        /**
         * @tolerant
         */
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Color	color = Decoder.decodeColor(attributeValue);
            ((Highlighter) target.getObject()).setForeground(color);
        }
    };

    public static final AttributeApplier	maskApplier = new AttributeApplier() {
        /**
        * @tolerant
         */
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            if (attributeValue.length() > 0) {
                ((ConditionalHighlighter) target.getObject()).setMask(
                    Integer.parseInt(attributeValue));
            }
        }
    };

    public static final AttributeApplier	oddRowBackgroundApplier = new AttributeApplier() {
        /**
         * @tolerant
         */
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Color	color = Decoder.decodeColor(attributeValue);
            ((AlternateRowHighlighter) target.getObject()).setOddRowBackground(color);
        }
    };

    public static final AttributeApplier	selectedBackgroundApplier = new AttributeApplier() {
        /**
         * @tolerant
         */
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Color	color = Decoder.decodeColor(attributeValue);
            ((Highlighter) target.getObject()).setSelectedBackground(color);
        }
    };

    public static final AttributeApplier	selectedForegroundApplier = new AttributeApplier() {
        /**
         * @tolerant
         */
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            Color	color = Decoder.decodeColor(attributeValue);
            ((Highlighter) target.getObject()).setSelectedBackground(color);
        }
    };

    public static final AttributeApplier	testColumnApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            int columnIndex = TableColumnAttributes.getModelIndex(target, attributeValue);
            if (columnIndex >= 0) {
            	((ConditionalHighlighter) target.getObject()).setTestColumnIndex(columnIndex);
            }
        }
    };

/*
    public static final AttributeApplier	testColumnIndexApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            System.out.println("Attribute \"" + attributeName + "\" in <" +
                               target.getLocalName() + "> is deprecated.");
            ((ConditionalHighlighter) target.getObject()).setTestColumnIndex(
                Integer.parseInt(attributeValue));
        }
    };
*/
}
