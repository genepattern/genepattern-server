/*
 * $Id: ElementTypes.java,v 1.3 2004/07/28 21:21:18 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import net.openmarkup.ElementType;
import net.openmarkup.Vocabulary;

/**
 *
 * @author Ramesh Gupta
 * @author Amy Fowler
 */
public final class ElementTypes extends Vocabulary {
    // Basic element implementation classes are built into the object realizer.

    private static String vectorElement;

    static {
    try {
        // Since we are using the eNode Object Realizer for now, borrow basic element
        // implementations from there. Replace these once we have our own obj realizer.
        Class vectorClass = Class.forName("com.enode.or.dom.VectorElementImpl");
        vectorElement = "com.enode.or.dom.VectorElementImpl";
    } catch (Exception ex) {
        vectorElement = "org.jdesktop.openmarkup.ri.VectorElementImpl";
    }
    }
    // private static final String vectorElement = "org.jdesktop.jdnc.or.VectorElementImpl";

    // See documentation of net.openmarkup.Vocabulary for restrictions on public
    // data members for this class.

    public static final ElementType ACTION = new ElementType(
        Namespace.JDNC, "action", "org.jdesktop.jdnc.markup.elem.ActionElement",
	"org.jdesktop.swing.actions.TargetableAction");

    public static final ElementType ACTION_PANEL = new ElementType(
        Namespace.JDNC, "buttonPanel", "org.jdesktop.jdnc.markup.elem.ActionPanelElement", null);

    public static final ElementType ACTIONS = new ElementType(
        Namespace.JDNC, "actions", vectorElement, "java.util.Vector");

    public static final ElementType ALTERNATE_ROW_HIGHLIGHTER = new ElementType(
        Namespace.JDNC, "alternateRowHighlighter", "org.jdesktop.jdnc.markup.elem.AlternateRowsElement", "org.jdesktop.swing.decorator.AlternateRowHighlighter");

    public static final ElementType APP = new ElementType(
        Namespace.JDNC, "app", "org.jdesktop.jdnc.markup.elem.AppElement", "org.jdesktop.jdnc.JDNCApp");

    public static final ElementType COLLAPSE_ALL = new ElementType(
        Namespace.JDNC, "collapseAll", "org.jdesktop.jdnc.markup.elem.DefaultElement", "org.jdesktop.jdnc.actions.CollapseAction");

    public static final ElementType COMPONENT = new ElementType(
         Namespace.JDNC, "component", "org.jdesktop.jdnc.markup.elem.FormComponentElement", null);

	public static final ElementType COMPONENTS = new ElementType(
         Namespace.JDNC, "components", vectorElement, "java.util.Vector");

    // JNComponent's private toolBar
    public static final ElementType COMPONENT_TOOLBAR = new ElementType(
        Namespace.JDNC, "toolBar", vectorElement, "java.util.Vector");

    public static final ElementType DATA = new ElementType(
		Namespace.JDNC, "tabularData", "org.jdesktop.jdnc.markup.elem.DataElement", "org.jdesktop.swing.data.TabularDataModel");

    public static final ElementType COLUMN_META_DATA = new ElementType(
        Namespace.JDNC, "columnMetaData", "org.jdesktop.jdnc.markup.elem.DataFieldElement", "org.jdesktop.swing.data.MetaData");

//    public static final ElementType DATA_COLUMNS = new ElementType(
//        Namespace.JDNC, "columns", "org.jdesktop.jdnc.markup.elem.DataColumnsElement", null);

    public static final ElementType FIELD_META_DATA = new ElementType(
        Namespace.JDNC, "fieldMetaData", "org.jdesktop.jdnc.markup.elem.DataFieldElement", "org.jdesktop.jdnc.data.MetaData");

    public static final ElementType EDITOR = new ElementType(
        Namespace.JDNC, "editor", "org.jdesktop.jdnc.markup.elem.EditorElement", "org.jdesktop.jdnc.JNEditor");

    public static final ElementType ENUMERATION_VALUES = new ElementType(
        Namespace.JDNC, "enumValues", "org.jdesktop.jdnc.markup.elem.EnumerationValuesElement", "java.util.Hashtable");

    public static final ElementType EXPAND_ALL = new ElementType(
        Namespace.JDNC, "expandAll", "org.jdesktop.jdnc.markup.elem.DefaultElement", "org.jdesktop.jdnc.actions.ExpandAction");

    /** @deprecated */
    public static final ElementType VALUES = new ElementType(
        Namespace.JDNC, "values", "org.jdesktop.jdnc.markup.elem.EnumerationValuesElement", "java.util.Hashtable");

    public static final ElementType ENUMERATION_VALUE = new ElementType(
        Namespace.JDNC, "enumeration", "org.jdesktop.jdnc.markup.elem.LabelElement", "javax.swing.JLabel");

    public static final ElementType FIELD_META_DATA_ENUM_VALUES = new ElementType(
        /** @todo This is temporary */
        Namespace.JDNC, "enumValues", "org.jdesktop.jdnc.markup.elem.DataFieldEnumerationElement", "java.util.ArrayList");

    public static final ElementType FIELD_META_DATA_ENUMERATION = new ElementType(
        /** @todo This is temporary */
        Namespace.JDNC, "enumeration", "org.jdesktop.jdnc.markup.elem.DataFieldEnumerationValueElement", null);

    public static final ElementType FILTERS = new ElementType(
        /** @todo FilterPipeline instead of Vector */
        Namespace.JDNC, "filters", vectorElement, "java.util.Vector");

    public static final ElementType FIND = new ElementType(
        Namespace.JDNC, "find", "org.jdesktop.jdnc.markup.elem.DefaultElement", "org.jdesktop.jdnc.actions.FindAction");

    public static final ElementType FORM = new ElementType(
        Namespace.JDNC, "form", "org.jdesktop.jdnc.markup.elem.FormElement", "org.jdesktop.jdnc.JNForm");

    public static final ElementType FORM_DATA = new ElementType(
        Namespace.JDNC, "formData", "org.jdesktop.jdnc.markup.elem.FormDataElement", "org.jdesktop.swing.data.DefaultDataModel");

    public static final ElementType FORM_COMPONENT = new ElementType(
        Namespace.JDNC, "component", "org.jdesktop.jdnc.markup.elem.FormComponentElement", null);

    public static final ElementType FONT = new ElementType(
        Namespace.JDNC, "font", "org.jdesktop.jdnc.markup.elem.FontElement", "java.awt.Font");

    public static final ElementType HIERARCHICAL_COLUMN_HIGHLIGHTER = new ElementType(
        Namespace.JDNC, "hierarchicalColumnHighlighter", "org.jdesktop.jdnc.markup.elem.HighlighterElement", "org.jdesktop.swing.decorator.HierarchicalColumnHighlighter");

    public static final ElementType HIERARCHICAL_DATA = new ElementType(
        Namespace.JDNC, "hierarchicalData", "org.jdesktop.jdnc.markup.elem.HierarchicalDataElement", "org.jdesktop.swing.data.DOMAdapter");

    public static final ElementType HIGHLIGHTERS = new ElementType(
        /** @todo HighlighterPipeline instead of Vector */
        Namespace.JDNC, "highlighters", vectorElement, "java.util.Vector");

    public static final ElementType META_DATA = new ElementType(
        Namespace.JDNC, "metaData", vectorElement, "java.util.Vector");

    public static final ElementType MENU = new ElementType(
        Namespace.JDNC, "menu", "org.jdesktop.jdnc.markup.elem.MenuElement", "javax.swing.JMenu");

    public static final ElementType MENUBAR = new ElementType(
        Namespace.JDNC, "menuBar", "org.jdesktop.jdnc.markup.elem.MenuBarElement", "javax.swing.JMenuBar");

    public static final ElementType PATTERN_FILTER = new ElementType(
        Namespace.JDNC, "patternFilter", "org.jdesktop.jdnc.markup.elem.PatternFilterElement", "org.jdesktop.swing.decorator.PatternFilter");

    public static final ElementType PATTERN_HIGHLIGHTER = new ElementType(
        Namespace.JDNC, "patternHighlighter", "org.jdesktop.jdnc.markup.elem.PatternHighlighterElement", "org.jdesktop.swing.decorator.PatternHighlighter");

    public static final ElementType POPUPMENU = new ElementType(
        Namespace.JDNC, "popupMenu", "org.jdesktop.jdnc.markup.elem.MenuElement", "javax.swing.JPopupMenu");

    public static final ElementType PRINT = new ElementType(
        Namespace.JDNC, "print", "org.jdesktop.jdnc.markup.elem.DefaultElement", "org.jdesktop.jdnc.actions.PrintAction");

    public static final ElementType RESET = new ElementType(
        Namespace.JDNC, "reset", "org.jdesktop.jdnc.markup.elem.DefaultElement", "org.jdesktop.jdnc.actions.ResetAction");

    public static final ElementType ROOT_PANE = new ElementType(
        Namespace.JDNC, "rootPane", "org.jdesktop.jdnc.markup.elem.RootPaneElement", "org.jdesktop.swing.JXRootPane");

    public static final ElementType SEARCH_PANEL = new ElementType(
        Namespace.JDNC, "searchPanel", "org.jdesktop.jdnc.markup.elem.SearchPanelElement", "org.jdesktop.swing.JXSearchPanel");

    public static final ElementType SEPARATOR = new ElementType(
        Namespace.JDNC, "separator", "org.jdesktop.jdnc.markup.elem.DefaultElement", "javax.swing.JSeparator");

    public static final ElementType SORTER = new ElementType(
        Namespace.JDNC, "sorter", "org.jdesktop.jdnc.markup.elem.SorterElement", "org.jdesktop.swing.decorator.Sorter");

    public static final ElementType SPLIT_PANE = new ElementType(
        Namespace.JDNC, "splitPane", "org.jdesktop.jdnc.markup.elem.SplitPaneElement", "javax.swing.JSplitPane");

    public static final ElementType STATUSBAR = new ElementType(
        Namespace.JDNC, "statusBar", "org.jdesktop.jdnc.markup.elem.DefaultElement", "org.jdesktop.swing.JXStatusBar");

    public static final ElementType SUBMIT = new ElementType(
        Namespace.JDNC, "submit", "org.jdesktop.jdnc.markup.elem.DefaultElement", "org.jdesktop.jdnc.actions.SubmitAction");

    public static final ElementType TABBED_PANE = new ElementType(
        Namespace.JDNC, "tabbedPane", "org.jdesktop.jdnc.markup.elem.TabbedPaneElement", "javax.swing.JTabbedPane");

    public static final ElementType TABLE = new ElementType(
        Namespace.JDNC, "table", "org.jdesktop.jdnc.markup.elem.TableElement", "org.jdesktop.jdnc.JNTable");

    public static final ElementType TABLE_COLUMN = new ElementType(
        Namespace.JDNC, "column", "org.jdesktop.jdnc.markup.elem.TableColumnElement", "org.jdesktop.swing.table.TableColumnExt");

    public static final ElementType TABLE_COLUMN_HEADER = new ElementType(
        Namespace.JDNC, "header", "org.jdesktop.jdnc.markup.elem.TableColumnHeaderElement", "org.jdesktop.swing.LabelProperties");

    public static final ElementType TABLE_COLUMNS = new ElementType(
        Namespace.JDNC, "columns", "org.jdesktop.jdnc.markup.elem.TableColumnsElement", "javax.swing.table.DefaultTableColumnModel");

    public static final ElementType TABLE_HEADER = new ElementType(
        Namespace.JDNC, "header", "org.jdesktop.jdnc.markup.elem.TableHeaderElement", "javax.swing.table.JTableHeader");

    public static final ElementType TABULAR_DATA = new ElementType(
        Namespace.JDNC, "tabularData", "org.jdesktop.jdnc.markup.elem.DataElement", "org.jdesktop.swing.data.TabularDataModel");

    public static final ElementType TREE_TABLE = new ElementType(
        Namespace.JDNC, "treeTable", "org.jdesktop.jdnc.markup.elem.TreeTableElement", "org.jdesktop.jdnc.JNTreeTable");

    public static final ElementType TREE_TABLE_COLUMN = new ElementType(
        Namespace.JDNC, "column", "org.jdesktop.jdnc.markup.elem.TreeTableColumnElement", "org.jdesktop.swing.table.TableColumnExt");

    public static final ElementType TREE_TABLE_COLUMNS = new ElementType(
        Namespace.JDNC, "columns", "org.jdesktop.jdnc.markup.elem.TreeTableColumnsElement", "javax.swing.table.DefaultTableColumnModel");

    private static Vocabulary	instance = null;
    public static Vocabulary get() {
        if (instance == null) {
            instance = new ElementTypes();
        }
        return instance;
    }
}
