/*
 * $Id: TableAttributes.java,v 1.3 2004/09/02 00:50:35 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import java.net.URL;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableModel;

import org.jdesktop.swing.data.DataLoader;
import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.data.TabularDataTextLoader;
import org.jdesktop.swing.utils.LoadOnShowListener;
import org.jdesktop.jdnc.JNTable;
import org.jdesktop.jdnc.markup.RealizationUtils;
import org.jdesktop.jdnc.markup.elem.TableElement;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

/**
 * @author Ramesh Gupta
 * @author Amy Fowler
 */
public class TableAttributes {
    public static final AttributeApplier hasColumnControlApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            JNTable table = (JNTable) target.getObject();
            boolean enabled = Boolean.valueOf(attributeValue).booleanValue();
            table.setHasColumnControl(enabled);
        }
    };

    public static final AttributeApplier	columnMarginApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            JNTable table = (JNTable) target.getObject();
            try {
                int columnMargin = Integer.parseInt(attributeValue);
                table.setColumnMargin(columnMargin);
            }
            catch (NumberFormatException ex) {
                throw new ApplierException("Bad format: " + attributeName + "=" + attributeValue, ex);
            }
        }
    };

    public static final AttributeApplier	dataApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue)
            throws ApplierException {
            TabularDataModel data = (TabularDataModel)BaseAttribute.getReferencedObject(target,
                attributeValue);
            TableElement.setModel(target, data);
        }
    };

    public static final AttributeApplier	dataSourceApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {

            // Validate the URL before we do anything else.
            URL url = target.getResolvedURL(attributeValue);
            RealizationUtils.validateURL(url);

            try {
                TabularDataModel	model = new TabularDataModel();
                model.setSource(url);
                JNTable	table = (JNTable) target.getObject();
                table.setModel(model);
                table.addHierarchyListener(new LoadOnShowListener(model));
            }
            catch (Exception ex) {
                throw new ApplierException("Couldn't set data source " +
                    attributeName + "=" + attributeValue, ex);
            }
        }
    };

    public static final AttributeApplier	firstRowHeaderApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            try {
                JNTable	table = (JNTable) target.getObject();
                TableModel model = table.getModel();
                if (model instanceof TabularDataModel) {
                    TabularDataTextLoader loader = (TabularDataTextLoader)((TabularDataModel)model).getLoader();
                    loader.setFirstRowHeader(Boolean.valueOf(attributeValue).booleanValue());
                }
            }
            catch (Exception ex) {
                throw new ApplierException("Couldn't set firstRowHeader " +
                    attributeName + "=" + attributeValue, ex);
            }
        }
    };

    public static final AttributeApplier	gridColorApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            JNTable		table = (JNTable) target.getObject();
            Color	color = Decoder.decodeColor(attributeValue);
            table.setGridColor(color);
        }
    };

    public static final AttributeApplier	isColumnHeaderLockedApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            JNTable		table = (JNTable) target.getObject();
            boolean		isLocked = Boolean.valueOf(attributeValue).booleanValue();
            table.getTable().getTableHeader().setEnabled(!isLocked);
            /** @todo add error checking: getTable() or getTableHeader() could return null? */
        }
    };

    public static final AttributeApplier	isRowHeaderLockedApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            JNTable		table = (JNTable) target.getObject();
            boolean		isLocked = Boolean.valueOf(attributeValue).booleanValue();
            table.setRowHeaderLocked(isLocked);
        }
    };

    public static final AttributeApplier	preferredSizeApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            String[]		args = attributeValue.split("\\s");
            if (args.length == 2) {
                Dimension	size = new Dimension(
                    Integer.parseInt(args[0]), Integer.parseInt(args[1]));
                JNTable		table = (JNTable) target.getObject();
                table.setPreferredSize(size);
            }
        }
    };

    public static final AttributeApplier	rowHeightApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) {
            JNTable table = (JNTable) target.getObject();
            int rowHeight = Integer.parseInt(attributeValue);
            table.setRowHeight(rowHeight);
        }
    };

    public static final AttributeApplier	rowMarginApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            JNTable table = (JNTable) target.getObject();
            try {
                int rowMargin = Integer.parseInt(attributeValue);
                table.setRowMargin(rowMargin);
            }
            catch (NumberFormatException ex) {
                throw new ApplierException("Bad format: " + attributeName + "=" + attributeValue, ex);
            }
        }
    };

    public static final AttributeApplier selectionApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            int	index = Integer.parseInt(attributeValue);
            final JTable table = ((JNTable) target.getObject()).getTable();

            // no data yet, so we watch for data to set initial selection
            // to ensure that DataModel has a non -1 current index
            table.getModel().addTableModelListener(new TableModelListener() {
                public void tableChanged(TableModelEvent e) {
                    if (e.getType() == TableModelEvent.INSERT) {
                        table.getSelectionModel().setLeadSelectionIndex(0);
                        table.getSelectionModel().setAnchorSelectionIndex(0);
                        table.getModel().removeTableModelListener(this);
                    }
                }
            });
        }
    };

    public static final AttributeApplier	selectionModeApplier = new AttributeApplier() {
         public void apply(Realizable target, String namespaceURI,
                           String attributeName, String attributeValue) throws ApplierException {
             JNTable table = (JNTable) target.getObject();
             if (attributeValue.equals("single")) {
                 table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
             } else if (attributeValue.equals("contiguous")) {
                 table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
             } else if (attributeValue.equals("discontiguous")) {
                 table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
             } else {
                 /**@todo aim: log warning? */
             }
         }
     };

     public static final AttributeApplier showsHorizontalLinesApplier = new AttributeApplier() {
         public void apply(Realizable target, String namespaceURI,
                           String attributeName, String attributeValue) throws ApplierException {
             JNTable table = (JNTable) target.getObject();
             boolean show = Boolean.valueOf(attributeValue).booleanValue();
             table.setShowHorizontalLines(show);
         }
     };

     public static final AttributeApplier showsVerticalLinesApplier = new AttributeApplier() {
         public void apply(Realizable target, String namespaceURI,
                           String attributeName, String attributeValue) throws ApplierException {
             JNTable table = (JNTable) target.getObject();
             boolean show = Boolean.valueOf(attributeValue).booleanValue();
             table.setShowVerticalLines(show);
         }
     };
/*
     public static final AttributeApplier sortableApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            JNTable table = (JNTable) target.getObject();
            boolean sortable = Boolean.valueOf(attributeValue).booleanValue();
            table.setSortable(sortable);
        }
    };
*/

     // ...
}
