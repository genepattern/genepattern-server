/*
 * $Id: SearchPanelAttributes.java,v 1.2 2004/07/28 21:21:18 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import javax.swing.JComponent;

import org.jdesktop.swing.JXSearchPanel;
import org.jdesktop.swing.decorator.PatternFilter;
import org.jdesktop.swing.decorator.PatternHighlighter;
import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

/**
 * @author Ramesh Gupta
 */
public class SearchPanelAttributes {
    public static final AttributeApplier	patternFilterApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            PatternFilter filter = (PatternFilter)BaseAttribute.getReferencedObject(target, attributeValue);
            ((JXSearchPanel)target.getObject()).setPatternFilter(filter);
        }
    };

    public static final AttributeApplier	patternHighlighterApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            PatternHighlighter highlighter = (PatternHighlighter)BaseAttribute.getReferencedObject(target, attributeValue);
            ((JXSearchPanel)target.getObject()).setPatternHighlighter(highlighter);
        }
    };

    public static final AttributeApplier	targetApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            JComponent	component = (JComponent)BaseAttribute.getReferencedObject(target, attributeValue);
            ((JXSearchPanel)target.getObject()).setTargetComponent(component);
        }
    };
}
