/*
 * $Id: FontElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.awt.Font;

import java.util.Hashtable;
import java.util.Map;

import org.w3c.dom.Element;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Scribe;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.*;

/**
 *
 * @author Amy Fowler
 */
public class FontElement extends ElementProxy {

    private static final Map attrMap = new Hashtable();

    public FontElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    public Object instantiate() {
        String fontName = null; // default is "Default"
        int fontSize = 12;
        int fontStyle = Font.PLAIN;

        // no zero arg constructor - need all attributes to instantiate

        String attrValue = getAttributeNSOptional(Namespace.JDNC, Attributes.NAME);
        if (attrValue.length() == 0) {
	    Scribe.getLogger().warning("Font has no name attribute defined, default to \"Default\"");
        } else {
            fontName = attrValue;
        }
        attrValue = getAttributeNSOptional(Namespace.JDNC, Attributes.SIZE);
        if (attrValue.length() == 0) {
	    Scribe.getLogger().warning("Font has no size attribute defined, default to 12");
        } else {
            fontSize = Integer.parseInt(attrValue);
        }
        attrValue = getAttributeNSOptional(Namespace.JDNC, Attributes.STYLE);
        if (attrValue.length() > 0) {
            fontStyle = Decoder.decodeFontStyle(attrValue);
        }

        return new Font(fontName, fontStyle, fontSize);
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
	    // Register null appliers. These attributes are handled elsewhere
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ID,
                           NullAttribute.idHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.NAME,
                           nameHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SIZE,
                           sizeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.STYLE,
                           styleHandler);
        }
        return handlerMap;
    }

    private static final AttributeHandler nameHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.NAME, NullAttribute.nullApplier);

    private static final AttributeHandler sizeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SIZE, NullAttribute.nullApplier);

    private static final AttributeHandler styleHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.STYLE, NullAttribute.nullApplier);

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

}
