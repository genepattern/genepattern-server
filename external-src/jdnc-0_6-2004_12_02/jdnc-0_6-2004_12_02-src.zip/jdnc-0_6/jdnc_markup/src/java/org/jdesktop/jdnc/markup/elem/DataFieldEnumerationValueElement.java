/*
 * $Id: DataFieldEnumerationValueElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.data.ConversionException;
import org.jdesktop.swing.data.Converter;
import org.jdesktop.swing.data.MetaData;

import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.Namespace;

import org.jdesktop.jdnc.markup.attr.NullAttribute;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author Amy Fowler
 */
public class DataFieldEnumerationValueElement extends ElementProxy {

    private static final Map attrMap = new Hashtable();

    public DataFieldEnumerationValueElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    public Object instantiate() {

        Realizable metaDataElement = ElementProxy.getRealizable(
                                  (Element)(getParentNode().getParentNode()));
        MetaData metaData = (MetaData)metaDataElement.getObject();
        String elementValue = getAttributeNSOptional(Namespace.JDNC,
                                                Attributes.VALUE);
/*
        NodeList children = getChildNodes();
        for(int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.TEXT_NODE) {
                elementValue = child.getNodeValue();
                break;
            }
        }
            */

        Object value = null;
        Converter converter = metaData.getConverter();
        try {
            value = converter.decode(elementValue,
                                             metaData.getDecodeFormat());
        } catch (ConversionException e) {
            System.out.println(e);
        }
        return value;
    }

    protected Map registerAttributeHandlers() {
        Map handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
	    // Register null appliers. These attributes are handled elsewhere
            handlerMap.put(Namespace.JDNC + ":" + Attributes.VALUE,
                           NullAttribute.valueHandler);
	}
	return handlerMap;
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

}
