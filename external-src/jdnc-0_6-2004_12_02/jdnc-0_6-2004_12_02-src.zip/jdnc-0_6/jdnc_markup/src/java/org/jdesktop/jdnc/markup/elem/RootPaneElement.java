/*
 * $Id: RootPaneElement.java,v 1.2 2004/07/28 21:21:17 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JMenuBar;
import javax.swing.JRootPane;
import javax.swing.JSeparator;
import javax.swing.JToolBar;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;

import org.w3c.dom.Element;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;
import org.jdesktop.jdnc.markup.attr.RootPaneAttributes;

import org.jdesktop.swing.JXStatusBar;
import org.jdesktop.swing.JXRootPane;

import org.jdesktop.swing.Application;
import org.jdesktop.swing.actions.ActionContainerFactory;
import org.jdesktop.swing.actions.ActionManager;

/**
 *
 * @author Amy Fowler
 */
public class RootPaneElement extends ComponentElement {

    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    public RootPaneElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    public ElementHandler getElementHandler(String namespaceURI, String elementName) {
        Map	handlerMap = getElementHandlerMap();
        return handlerMap == null ? null : (ElementHandler) handlerMap.get(namespaceURI + ":" + elementName);
    }

    public AttributeHandler getAttributeHandler(String namespaceURI, String attrName) {
        Map	handlerMap = getAttributeHandlerMap();
        return handlerMap == null ? null : (AttributeHandler) attrMap.get(namespaceURI + ":" + attrName);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected void applyAttributesBefore() {
        super.applyAttributesBefore();
        applyAttribute(Namespace.JDNC, Attributes.APP);
        applyAttribute(Namespace.JDNC, Attributes.SIZE); // WIDTH and HEIGHT
    }

    protected Map registerAttributeHandlers() {
         Map handlerMap = super.registerAttributeHandlers();
         if (handlerMap != null) {
             handlerMap.put(Namespace.JDNC + ":" + Attributes.APP,
                            appHandler);
             handlerMap.put(Namespace.JDNC + ":" + Attributes.SIZE,
                            sizeHandler); // WIDTH and HEIGHT
         }
         return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.EDITOR.getLocalName(),
                           editorElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.FORM.getLocalName(),
                           formElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.SPLIT_PANE.getLocalName(),
                           splitPaneElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABBED_PANE.getLocalName(),
                           tabbedPaneElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TABLE.getLocalName(),
                           tableElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.TREE_TABLE.getLocalName(),
                           treeTableElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.COMPONENT_TOOLBAR.getLocalName(),
                           toolBarElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.EDITOR.getLocalName(),
                           editorElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.MENUBAR.getLocalName(),
                           menuBarElementHandler);
            handlerMap.put(Namespace.JDNC + ":" +
                           ElementTypes.STATUSBAR.getLocalName(),
                           statusBarElementHandler);
        }
        return handlerMap;
    }

    public static final ElementAssimilator contentComponentAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JXRootPane rootPane = (JXRootPane)parent.getObject();
            Component contentComponent = (Component)child.getObject();
            rootPane.addComponent(contentComponent);
        }
    };

    public static final ElementAssimilator menuBarAssimilator = new ElementAssimilator() {
	    public void assimilate(Realizable parent, Realizable child) {
		JRootPane rootPane = (JRootPane)parent.getObject();
		JMenuBar menuBar = (JMenuBar)child.getObject();
		rootPane.setJMenuBar(menuBar);
	    }
	};


    /**
     * Handle the toolbar element which is represented as a Vector.
     * <p>
     * XXX Note: this is pretty hacked. It appears that the toolbar should
     *     be broken out into a toolbar element. Like the MenuElement.
     */
    public static final ElementAssimilator toolBarAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JXRootPane rootPane = (JXRootPane)parent.getObject();

	    // Should convert the Action and Separator entries into id tags
	    // and null.
            Vector entries = (Vector)child.getObject();
	    Iterator iter = entries.iterator();
	    List actionlist = new ArrayList();
	    while (iter.hasNext()) {
		Object obj = iter.next();
		if (obj instanceof Action) {
		    actionlist.add(((Action)obj).getValue(Action.ACTION_COMMAND_KEY));
		} else if (obj instanceof JSeparator) {
		    actionlist.add(null);
		} else if (obj instanceof Vector) {
		    // This is a group element which is also represented as a vector.
		    Vector group = (Vector)obj;
		    Iterator i2 = group.iterator();
		    while (i2.hasNext()) {
			Action action = (Action)i2.next();
			Object value = action.getValue(Action.ACTION_COMMAND_KEY);
			actionlist.add(value);
		    }
		}
            }

	    ActionManager manager = Application.getInstance().getActionManager();
	    ActionContainerFactory factory = manager.getFactory();

            JToolBar toolBar = factory.createToolBar(actionlist);
            rootPane.setToolBar(toolBar);
        }
    };

    public static final ElementAssimilator statusBarAssimilator = new ElementAssimilator() {
	    public void assimilate(Realizable parent, Realizable child) {
		JXRootPane rootPane = (JXRootPane)parent.getObject();
		JXStatusBar status = (JXStatusBar)child.getObject();
		rootPane.setStatusBar(status);
	    }
	};


    // For typecasting entries in a Vector when converted to an array

    protected static final AttributeHandler	appHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.APP,
                             RootPaneAttributes.appApplier);

    protected static final AttributeHandler	sizeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SIZE,
                             ComponentAttributes.sizeApplier);

    protected static final ElementHandler editorElementHandler =
        new ElementHandler(ElementTypes.EDITOR,
                           RootPaneElement.contentComponentAssimilator);

    protected static final ElementHandler formElementHandler =
        new ElementHandler(ElementTypes.FORM,
                           RootPaneElement.contentComponentAssimilator);

    protected static final ElementHandler splitPaneElementHandler =
        new ElementHandler(ElementTypes.SPLIT_PANE,
                           RootPaneElement.contentComponentAssimilator);

    protected static final ElementHandler tabbedPaneElementHandler =
        new ElementHandler(ElementTypes.TABBED_PANE,
                           RootPaneElement.contentComponentAssimilator);

    protected static final ElementHandler tableElementHandler =
        new ElementHandler(ElementTypes.TABLE,
                           RootPaneElement.contentComponentAssimilator);

    protected static final ElementHandler treeTableElementHandler =
        new ElementHandler(ElementTypes.TREE_TABLE,
                           RootPaneElement.contentComponentAssimilator);

    protected static final ElementHandler toolBarElementHandler =
        new ElementHandler(ElementTypes.COMPONENT_TOOLBAR,
                           RootPaneElement.toolBarAssimilator);

    protected static final ElementHandler statusBarElementHandler =
        new ElementHandler(ElementTypes.STATUSBAR,
                           RootPaneElement.statusBarAssimilator);

    protected static final ElementHandler menuBarElementHandler =
        new ElementHandler(ElementTypes.MENUBAR,
                           RootPaneElement.menuBarAssimilator);
}
