/*
 * $Id: FormElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.data.DataModel;
import org.jdesktop.swing.data.DefaultDataModel;
import org.jdesktop.swing.data.TabularDataModel;

import org.jdesktop.swing.binding.BindException;

import org.jdesktop.jdnc.JNForm;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JComponent;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;
import net.openmarkup.AssimilatorException;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.BaseAttribute;
import org.jdesktop.jdnc.markup.attr.ComponentAttributes;
import org.jdesktop.jdnc.markup.attr.FormAttributes;

/**
 *
 * @author Amy Fowler
 */
public class FormElement extends ComponentElement {
    private static final Map	attrMap = new Hashtable();
    private static final Map    elementMap = new Hashtable();

    // utility method for executing a bind operation
    public static void bindToForm(JNForm form, Object dataModel, String fieldName) throws BindException{

    }

    public FormElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    protected Object instantiate() {
        return new JNForm();
    }

    protected void applyAttributesBefore() {
        // must be applied before any components/bindings are assimilated
        applyAttribute(Namespace.JDNC, Attributes.DATA);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.PREFERRED_SIZE);
        applyAttribute(Namespace.JDNC, Attributes.TRACKS);
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.PREFERRED_SIZE,
                           preferredSizeHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.DATA,
                           dataHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.TRACKS,
                           tracksHandler);
        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            elementMap.put(Namespace.JDNC + ":" + ElementTypes.FORM_DATA.getLocalName(),
                           formDataElementHandler);
            elementMap.put(Namespace.JDNC + ":" + ElementTypes.DATA.getLocalName(),
                           dataElementHandler);
            elementMap.put(Namespace.JDNC + ":" + ElementTypes.COMPONENTS.getLocalName(),
                           componentsElementHandler);
        }
        return handlerMap;
    }

    public void handleBinding(JNForm form, Object dataModel) {
        if (!hasComponentElements()) {
            try {
                if (dataModel instanceof TabularDataModel) {
                    form.bind((TabularDataModel)dataModel);
                }
                else if (dataModel instanceof DataModel) {
                    form.bind((DataModel)dataModel);
                }
                else {
                    form.bind(dataModel);
                }
            }
            catch (BindException e) {
                throw new RuntimeException("could not bind form to datamodel", e);
            }
        }
        else {
            form.putClientProperty("formData", dataModel);
        }
    }


    public boolean hasComponentElements() {
        NodeList children = getChildNodes();
        String formComponentName = ElementTypes.COMPONENTS.getLocalName();
        for(int i = 0;i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Realizable child = ElementProxy.getRealizable((Element)node);
                if (child.getLocalName().equals(formComponentName)) {
                    return true;
                }
            }
        }
        return false;
   }

    public static final ElementAssimilator formDataAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNForm form = (JNForm)parent.getObject();
            Object dataModel = child.getObject();
            ((FormElement)parent).handleBinding(form, dataModel);
        }
    };

    public static final ElementAssimilator componentsAssimilator = new
        ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            JNForm form = (JNForm)parent.getObject();
            List	list = (List) child.getObject();
            for (int i = 0; i < list.size(); i++) {
                Object binding[] = (Object[]) list.get(i);
                createComponentBinding(form, binding);
            }
        }

        private void createComponentBinding(JNForm form, Object binding[])  {
            Object dataModel = binding[0];
            String fieldName = (String)binding[1];
            if (dataModel == null) {
                // try to get data model stored on JNForm
                dataModel = form.getClientProperty("formData");
            }
            if (dataModel == null) {
                throw new RuntimeException("either component or form must specify data attribute");
            }
            try {
                if (dataModel instanceof TabularDataModel) {
                    form.bind( (TabularDataModel) dataModel, fieldName);
                }
                else if (dataModel instanceof DataModel) {
                    form.bind( (DataModel) dataModel, fieldName);
                }
                else {
                    form.bind(dataModel, fieldName); // JavaBean
                }
            }
            catch (BindException e) {
                throw new RuntimeException("unable to create binding for \""+ fieldName +
                                           "\"", e);
            }
        }
    };


    protected static final AttributeHandler	dataHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.DATA, FormAttributes.dataApplier);

    protected static final AttributeHandler	preferredSizeHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.PREFERRED_SIZE, ComponentAttributes.preferredSizeApplier);

    protected static final AttributeHandler	tracksHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.TRACKS, FormAttributes.tracksApplier);

    protected static final ElementHandler		formDataElementHandler =
        new ElementHandler(ElementTypes.FORM_DATA, FormElement.formDataAssimilator);

    protected static final ElementHandler		dataElementHandler =
        new ElementHandler(ElementTypes.DATA, FormElement.formDataAssimilator);

    protected static final ElementHandler		componentsElementHandler =
        new ElementHandler(ElementTypes.COMPONENTS, FormElement.componentsAssimilator);

}
