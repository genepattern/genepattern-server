/*
 * $Id: Decoder.java,v 1.2 2004/09/02 00:50:35 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import java.awt.Color;
import java.awt.Font;
import java.util.HashMap;
import java.util.regex.Pattern;

import javax.swing.SwingConstants;

/**
 * @author Ramesh Gupta
 */

public class Decoder {
    private static HashMap constantsMap;
    private static HashMap typesMap;
    private static HashMap svgColorsMap;

    static {
        constantsMap = new HashMap();
        constantsMap.put("left", new Integer(SwingConstants.LEFT));
        constantsMap.put("right", new Integer(SwingConstants.RIGHT));
        constantsMap.put("center", new Integer(SwingConstants.CENTER));
        constantsMap.put("leading", new Integer(SwingConstants.LEADING));
        constantsMap.put("before", new Integer(SwingConstants.LEADING));
        constantsMap.put("trailing", new Integer(SwingConstants.TRAILING));
        constantsMap.put("after", new Integer(SwingConstants.TRAILING));
        constantsMap.put("top", new Integer(SwingConstants.TOP));
        constantsMap.put("bottom", new Integer(SwingConstants.BOTTOM));
        // ...


        typesMap = new HashMap();
        typesMap.put("boolean", java.lang.Boolean.class);
        typesMap.put("date", java.util.Date.class);
        typesMap.put("double", java.lang.Double.class);
        typesMap.put("float", java.lang.Float.class);
        typesMap.put("integer", java.lang.Integer.class);
        typesMap.put("string", java.lang.String.class);
        typesMap.put("href", org.jdesktop.swing.data.Link.class);
        // ...

        svgColorsMap = new HashMap(255);
        svgColorsMap.put("aliceblue", new Color(240, 248, 255));
        svgColorsMap.put("antiquewhite", new Color(250, 235, 215));
        svgColorsMap.put("aqua", new Color( 0, 255, 255));
        svgColorsMap.put("aquamarine", new Color(127, 255, 212));
        svgColorsMap.put("azure", new Color(240, 255, 255));
        svgColorsMap.put("beige", new Color(245, 245, 220));
        svgColorsMap.put("bisque", new Color(255, 228, 196));
        svgColorsMap.put("black", new Color( 0, 0, 0));
        svgColorsMap.put("blanchedalmond", new Color(255, 235, 205));
        svgColorsMap.put("blue", new Color( 0, 0, 255));
        svgColorsMap.put("blueviolet", new Color(138, 43, 226));
        svgColorsMap.put("brown", new Color(165, 42, 42));
        svgColorsMap.put("burlywood", new Color(222, 184, 135));
        svgColorsMap.put("cadetblue", new Color( 95, 158, 160));
        svgColorsMap.put("chartreuse", new Color(127, 255, 0));
        svgColorsMap.put("chocolate", new Color(210, 105, 30));
        svgColorsMap.put("coral", new Color(255, 127, 80));
        svgColorsMap.put("cornflowerblue", new Color(100, 149, 237));
        svgColorsMap.put("cornsilk", new Color(255, 248, 220));
        svgColorsMap.put("crimson", new Color(220, 20, 60));
        svgColorsMap.put("cyan", new Color( 0, 255, 255));
        svgColorsMap.put("darkblue", new Color( 0, 0, 139));
        svgColorsMap.put("darkcyan", new Color( 0, 139, 139));
        svgColorsMap.put("darkgoldenrod", new Color(184, 134, 11));
        svgColorsMap.put("darkgray", new Color(169, 169, 169));
        svgColorsMap.put("darkgreen", new Color( 0, 100, 0));
        svgColorsMap.put("darkgrey", new Color(169, 169, 169));
        svgColorsMap.put("darkkhaki", new Color(189, 183, 107));
        svgColorsMap.put("darkmagenta", new Color(139, 0, 139));
        svgColorsMap.put("darkolivegreen", new Color( 85, 107, 47));
        svgColorsMap.put("darkorange", new Color(255, 140, 0));
        svgColorsMap.put("darkorchid", new Color(153, 50, 204));
        svgColorsMap.put("darkred", new Color(139, 0, 0));
        svgColorsMap.put("darksalmon", new Color(233, 150, 122));
        svgColorsMap.put("darkseagreen", new Color(143, 188, 143));
        svgColorsMap.put("darkslateblue", new Color( 72, 61, 139));
        svgColorsMap.put("darkslategray", new Color( 47, 79, 79));
        svgColorsMap.put("darkslategrey", new Color( 47, 79, 79));
        svgColorsMap.put("darkturquoise", new Color( 0, 206, 209));
        svgColorsMap.put("darkviolet", new Color(148, 0, 211));
        svgColorsMap.put("deeppink", new Color(255, 20, 147));
        svgColorsMap.put("deepskyblue", new Color( 0, 191, 255));
        svgColorsMap.put("dimgray", new Color(105, 105, 105));
        svgColorsMap.put("dimgrey", new Color(105, 105, 105));
        svgColorsMap.put("dodgerblue", new Color( 30, 144, 255));
        svgColorsMap.put("firebrick", new Color(178, 34, 34));
        svgColorsMap.put("floralwhite", new Color(255, 250, 240));
        svgColorsMap.put("forestgreen", new Color( 34, 139, 34));
        svgColorsMap.put("fuchsia", new Color(255, 0, 255));
        svgColorsMap.put("gainsboro", new Color(220, 220, 220));
        svgColorsMap.put("ghostwhite", new Color(248, 248, 255));
        svgColorsMap.put("gold", new Color(255, 215, 0));
        svgColorsMap.put("goldenrod", new Color(218, 165, 32));
        svgColorsMap.put("gray", new Color(128, 128, 128));
        svgColorsMap.put("green", new Color( 0, 128, 0));
        svgColorsMap.put("greenyellow", new Color(173, 255, 47));
        svgColorsMap.put("grey", new Color(128, 128, 128));
        svgColorsMap.put("honeydew", new Color(240, 255, 240));
        svgColorsMap.put("hotpink", new Color(255, 105, 180));
        svgColorsMap.put("indianred", new Color(205, 92, 92));
        svgColorsMap.put("indigo", new Color( 75, 0, 130));
        svgColorsMap.put("ivory", new Color(255, 255, 240));
        svgColorsMap.put("khaki", new Color(240, 230, 140));
        svgColorsMap.put("lavender", new Color(230, 230, 250));
        svgColorsMap.put("lavenderblush", new Color(255, 240, 245));
        svgColorsMap.put("lawngreen", new Color(124, 252, 0));
        svgColorsMap.put("lemonchiffon", new Color(255, 250, 205));
        svgColorsMap.put("lightblue", new Color(173, 216, 230));
        svgColorsMap.put("lightcoral", new Color(240, 128, 128));
        svgColorsMap.put("lightcyan", new Color(224, 255, 255));
        svgColorsMap.put("lightgoldenrodyellow", new Color(250, 250, 210));
        svgColorsMap.put("lightgray", new Color(211, 211, 211));
        svgColorsMap.put("lightgreen", new Color(144, 238, 144));
        svgColorsMap.put("lightgrey", new Color(211, 211, 211));
        svgColorsMap.put("lightpink", new Color(255, 182, 193));
        svgColorsMap.put("lightsalmon", new Color(255, 160, 122));
        svgColorsMap.put("lightseagreen", new Color( 32, 178, 170));
        svgColorsMap.put("lightskyblue", new Color(135, 206, 250));
        svgColorsMap.put("lightslategray", new Color(119, 136, 153));
        svgColorsMap.put("lightslategrey", new Color(119, 136, 153));
        svgColorsMap.put("lightsteelblue", new Color(176, 196, 222));
        svgColorsMap.put("lightyellow", new Color(255, 255, 224));
        svgColorsMap.put("lime", new Color( 0, 255, 0));
        svgColorsMap.put("limegreen", new Color( 50, 205, 50));
        svgColorsMap.put("linen", new Color(250, 240, 230));
        svgColorsMap.put("magenta", new Color(255, 0, 255));
        svgColorsMap.put("maroon", new Color(128, 0, 0));
        svgColorsMap.put("mediumaquamarine", new Color(102, 205, 170));
        svgColorsMap.put("mediumblue", new Color( 0, 0, 205));
        svgColorsMap.put("mediumorchid", new Color(186, 85, 211));
        svgColorsMap.put("mediumpurple", new Color(147, 112, 219));
        svgColorsMap.put("mediumseagreen", new Color( 60, 179, 113));
        svgColorsMap.put("mediumslateblue", new Color(123, 104, 238));
        svgColorsMap.put("mediumspringgreen", new Color( 0, 250, 154));
        svgColorsMap.put("mediumturquoise", new Color( 72, 209, 204));
        svgColorsMap.put("mediumvioletred", new Color(199, 21, 133));
        svgColorsMap.put("midnightblue", new Color( 25, 25, 112));
        svgColorsMap.put("mintcream", new Color(245, 255, 250));
        svgColorsMap.put("mistyrose", new Color(255, 228, 225));
        svgColorsMap.put("moccasin", new Color(255, 228, 181));
        svgColorsMap.put("navajowhite", new Color(255, 222, 173));
        svgColorsMap.put("navy", new Color( 0, 0, 128));
        svgColorsMap.put("oldlace", new Color(253, 245, 230));
        svgColorsMap.put("olive", new Color(128, 128, 0));
        svgColorsMap.put("olivedrab", new Color(107, 142, 35));
        svgColorsMap.put("orange", new Color(255, 165, 0));
        svgColorsMap.put("orangered", new Color(255, 69, 0));
        svgColorsMap.put("orchid", new Color(218, 112, 214));
        svgColorsMap.put("palegoldenrod", new Color(238, 232, 170));
        svgColorsMap.put("palegreen", new Color(152, 251, 152));
        svgColorsMap.put("paleturquoise", new Color(175, 238, 238));
        svgColorsMap.put("palevioletred", new Color(219, 112, 147));
        svgColorsMap.put("papayawhip", new Color(255, 239, 213));
        svgColorsMap.put("peachpuff", new Color(255, 218, 185));
        svgColorsMap.put("peru", new Color(205, 133, 63));
        svgColorsMap.put("pink", new Color(255, 192, 203));
        svgColorsMap.put("plum", new Color(221, 160, 221));
        svgColorsMap.put("powderblue", new Color(176, 224, 230));
        svgColorsMap.put("purple", new Color(128, 0, 128));
        svgColorsMap.put("red", new Color(255, 0, 0));
        svgColorsMap.put("rosybrown", new Color(188, 143, 143));
        svgColorsMap.put("royalblue", new Color( 65, 105, 225));
        svgColorsMap.put("saddlebrown", new Color(139, 69, 19));
        svgColorsMap.put("salmon", new Color(250, 128, 114));
        svgColorsMap.put("sandybrown", new Color(244, 164, 96));
        svgColorsMap.put("seagreen", new Color( 46, 139, 87));
        svgColorsMap.put("seashell", new Color(255, 245, 238));
        svgColorsMap.put("sienna", new Color(160, 82, 45));
        svgColorsMap.put("silver", new Color(192, 192, 192));
        svgColorsMap.put("skyblue", new Color(135, 206, 235));
        svgColorsMap.put("slateblue", new Color(106, 90, 205));
        svgColorsMap.put("slategray", new Color(112, 128, 144));
        svgColorsMap.put("slategrey", new Color(112, 128, 144));
        svgColorsMap.put("snow", new Color(255, 250, 250));
        svgColorsMap.put("springgreen", new Color( 0, 255, 127));
        svgColorsMap.put("steelblue", new Color( 70, 130, 180));
        svgColorsMap.put("tan", new Color(210, 180, 140));
        svgColorsMap.put("teal", new Color( 0, 128, 128));
        svgColorsMap.put("thistle", new Color(216, 191, 216));
        svgColorsMap.put("tomato", new Color(255, 99, 71));
        svgColorsMap.put("turquoise", new Color( 64, 224, 208));
        svgColorsMap.put("violet", new Color(238, 130, 238));
        svgColorsMap.put("wheat", new Color(245, 222, 179));
        svgColorsMap.put("white", new Color(255, 255, 255));
        svgColorsMap.put("whitesmoke", new Color(245, 245, 245));
        svgColorsMap.put("yellow", new Color(255, 255, 0));
        svgColorsMap.put("yellowgreen", new Color(154, 205, 50));
    }

    public static Color decodeColor(String value) {
        if (value.length() > 0) {
            try {
                if (value.startsWith("#")) {
                    if (value.length() == 9) {
                        return new Color((
                            Integer.parseInt(value.substring(1, 3), 16) << 24) +
                            Integer.parseInt(value.substring(3), 16), true);
                    }
                    else {
                        return new Color(
                            Integer.parseInt(value.substring(1), 16));
                    }
                }
                else {
                    Color color = (Color) svgColorsMap.get(value);
                    // We do not yet support system color names like
                    // activeBorder, activeCaption, ...
                    if (color == null) {
                        color = new Color(127, 127, 127);
                        // log the problem
                    }
                    return color;
                }
            }
            catch (Exception ex) {
                System.out.println("Bad color: " + ex);
            }
        }
        return null;
    }

    public static int decodeFontStyle(String value) {
        if (value.equals("plain")) {
            return Font.PLAIN;
        }
        if (value.equals("bold")) {
            return Font.BOLD;
        }
        if (value.equals("italic")) {
            return Font.ITALIC;
        }
        if (value.equals("bold-italic") || value.equals("italic-bold")) {
            return Font.ITALIC | Font.BOLD;
        }
        return -1;
    }

    public static int decodeConstant(String value) {
         Integer intObject = (Integer)constantsMap.get(value);
         if (intObject == null) {
             //remind(aim): should be replaced with suppressable warning
             System.out.println("Illegal constant identifier: " + value);
             return -1;
         }
         return intObject.intValue();
    }

    public static Class decodeType(String value) {
        Class klass = (Class)typesMap.get(value);
        if (klass == null) {
            try {
                klass = Class.forName(value);
            } catch (ClassNotFoundException e) {
                System.out.println("Could not convert \"" + value + "\" to a java type or class");
            }
        }
        return klass;
    }

    public static int decodePatternMatchFlags(String value) {
        int matchFlags = 0;
        if (value.length() > 0) {
            String[]	flags = value.split("\\s");
            for (int i = 0; i < flags.length; i++) {
                String	flag = flags[i];
                if (flag.equals(CASE_INSENSITIVE)) {
                    matchFlags |= Pattern.CASE_INSENSITIVE;
                }
                else if (flag.equals(MULTILINE)) {
                    matchFlags |= Pattern.MULTILINE;
                }
                else if (flag.equals(DOT_ALL)) {
                    matchFlags |= Pattern.DOTALL;
                }
                else if (flag.equals(UNICODE_CASE)) {
                    matchFlags |= Pattern.UNICODE_CASE;
                }
                else if (flag.equals(CANON_EQ)) {
                    matchFlags |= Pattern.CANON_EQ;
                }
            }
        }
        return matchFlags;
    }

    private final static String	CASE_INSENSITIVE ="caseInsensitive";
    private final static String	MULTILINE ="multiline";
    private final static String	DOT_ALL ="dotAll";
    private final static String	UNICODE_CASE ="unicodeCase";
    private final static String	CANON_EQ ="canonEq";
}
