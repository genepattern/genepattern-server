/*
 * $Id: DataElement.java,v 1.2 2004/07/23 04:20:38 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.TabularDataModel;

import org.jdesktop.swing.data.DOMAdapter;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;
import org.jdesktop.jdnc.markup.attr.DataAttributes;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import net.openmarkup.AttributeHandler;
import net.openmarkup.ElementAssimilator;
import net.openmarkup.ElementHandler;
import net.openmarkup.ElementType;
import net.openmarkup.Realizable;
import net.openmarkup.Scribe;

import org.w3c.dom.Element;

/**
 *
 * @author Amy Fowler
 * @author Ramesh Gupta
 */
public class DataElement extends ElementProxy {
    private static final Map	attrMap = new Hashtable();
    private static final Map	elementMap = new Hashtable();
    private static final Map	mediaTypeRepresentation = new Hashtable();

    public DataElement(Element element, ElementType elementType) {
        super(element, elementType);
    }

    protected void applyAttributesAfter() {
        super.applyAttributesAfter();
        applyAttribute(Namespace.JDNC, Attributes.IS_FIRST_ROW_HEADER);
        applyAttribute(Namespace.JDNC, Attributes.COLUMN_DELIMITER);
        applyAttribute(Namespace.JDNC, Attributes.SOURCE);
        // ACTUATE must be applied LAST since it needs all attributes
        // to be configured before loading the data
        applyAttribute(Namespace.JDNC, Attributes.ACTUATE);
        // if actuate attribute wasn't specified, then default is onLoad....
        String actuateValue = this.getAttributeNSOptional(Namespace.JDNC, Attributes.ACTUATE);
        if (actuateValue.length() == 0) {
	    try {
		DataAttributes.actuateData((TabularDataModel)getObject(), actuateValue);
	    } catch (Exception ex) {
		Scribe.getLogger().warning("DataElement Error actuating data: " + ex.getMessage());
	    }
        }
    }

    protected Map registerAttributeHandlers() {
        Map	handlerMap = super.registerAttributeHandlers();
        if (handlerMap != null) {
            handlerMap.put(Namespace.JDNC + ":" + Attributes.ACTUATE, actuateHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.IS_FIRST_ROW_HEADER, firstRowHeaderHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.COLUMN_DELIMITER, columnDelimiterHandler);
            handlerMap.put(Namespace.JDNC + ":" + Attributes.SOURCE, sourceHandler);
        }
        return handlerMap;
    }

    protected Map registerElementHandlers() {
        Map	handlerMap = super.registerElementHandlers();
        if (handlerMap != null) {
            // metaData doesn't allocate an object
            handlerMap.put(Namespace.JDNC + ":" +ElementTypes.META_DATA.getLocalName(),
                            metaDataElementHandler);
        }
        return handlerMap;
    }

    protected Map getAttributeHandlerMap() {
        return attrMap;
    }

    protected Map getElementHandlerMap() {
        return elementMap;
    }

    public static final ElementAssimilator	metaDataAssimilator = new ElementAssimilator() {
        public void assimilate(Realizable parent, Realizable child) {
            TabularDataModel data = (TabularDataModel)parent.getObject();
            List list = (List)child.getObject();
            int columnCount = list.size();
            data.setColumnCount(columnCount);
            for(int i = 0; i < columnCount; i++) {
                data.setColumnMetaData(i, (MetaData)list.get(i));
            }
        }
    };

    private static final AttributeHandler	actuateHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.ACTUATE, DataAttributes.actuateApplier);

    private static final AttributeHandler	columnDelimiterHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.COLUMN_DELIMITER, DataAttributes.columnDelimiterApplier);

    private static final AttributeHandler	firstRowHeaderHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.IS_FIRST_ROW_HEADER, DataAttributes.firstRowHeaderApplier);

    private static final AttributeHandler	sourceHandler =
        new AttributeHandler(Namespace.JDNC, Attributes.SOURCE, DataAttributes.sourceApplier);

	private static final ElementHandler	 metaDataElementHandler =
          new ElementHandler(ElementTypes.META_DATA, metaDataAssimilator);


}
