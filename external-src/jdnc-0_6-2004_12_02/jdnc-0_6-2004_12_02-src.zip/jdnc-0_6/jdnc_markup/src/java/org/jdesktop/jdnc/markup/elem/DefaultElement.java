/*
 * $Id: DefaultElement.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.elem;

import org.w3c.dom.Element;
import net.openmarkup.ElementType;

/**
 * Element implememtation to use if the elements doesn't contain any sub-elements
 * or attributes. This implementation will return an instance of the 
 * object class.
 */
public class DefaultElement extends ElementProxy {
    
    public DefaultElement(Element element, ElementType elementType) {
	super(element, elementType);
    }
}

