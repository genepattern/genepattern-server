/*
 * $Id: HierarchicalDataAttributes.java,v 1.1.1.1 2004/06/16 01:43:40 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup.attr;

import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.data.DOMAdapter;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import net.openmarkup.ApplierException;
import net.openmarkup.AttributeApplier;
import net.openmarkup.Realizable;

import org.w3c.dom.Document;

import org.jdesktop.jdnc.markup.Attributes;
import org.jdesktop.jdnc.markup.ElementTypes;
import org.jdesktop.jdnc.markup.Namespace;

/**
 * @author Ramesh Gupta
 */
public class HierarchicalDataAttributes {
    public static final AttributeApplier	sourceApplier = new AttributeApplier() {
        public void apply(Realizable target, String namespaceURI,
                          String attributeName, String attributeValue) throws ApplierException {
            try {
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                dbf.setNamespaceAware(true);
                dbf.setIgnoringComments(true);
                URL	url = target.getResolvedURL(attributeValue);
                Document dom = dbf.newDocumentBuilder().parse(url.toExternalForm());
                ((DOMAdapter) target.getObject()).bind(dom);
            }
            catch (Exception ex) {
                throw new ApplierException("Couldn't set data source " +
                    attributeName + "=" + attributeValue, ex);
            }
        }
    };
}
