/*
 * $Id: RealizationUtilsTest.java,v 1.3 2004/10/29 15:34:58 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.net.URL;
import java.net.MalformedURLException;

import junit.framework.TestCase;

import net.openmarkup.ApplierException;

import org.jdesktop.jdnc.markup.RealizationUtils;

/**
 * A set of tests to ensure that the url validataion methods are
 * working correctly.
 *
 * @author Mark Davidson
 */
public class RealizationUtilsTest extends TestCase {

    private static String VALID_URL = "http://www.sun.com";
    private static String INVALID_URL = "http://wwww.thisisnotavalidurl.com";
    private static String MALFORMED_URL = "htp:\\invalid.com";

    private static String VALID_FILE_URL = "resources/bike.html";
    private static String INVALID_FILE_URL = "resources/steves-not-here.html";


    public void testData() {
        try {
            URL url = new URL(MALFORMED_URL);
        } catch (MalformedURLException ex) {
            return;
        }
        fail("Malformed URL: " + MALFORMED_URL);
    }

    /*
      Exclude these tests for now since we have to determine what constitutes
      a valid url inside and outside the Sun firewall.

      On the one hand, a Sun internal url like http://cerebus.sfbay is valid
      in the firewall but not on the public internet.

      On the other hand, a public url like http://www.sun.com is valid on
      the internet but must use an http proxy to gain access from within the
      firewall.

      May have to set a proxy when invoking the test from behind the firewall

      <arg value="-DproxyHost=scaweb1.sfbay"/>
      <arg value="-DproxyPort=8080"/>
      <arg value="-Dhttp.proxyHost=scaweb1.sfbay"/>
      <arg value="-Dhttp.proxyPort=8080"/>

    public void testValidURL() {
        try {
            assertTrue(RealizationUtils.validateURL(VALID_URL));
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    public void testValidURL2() {
        try {
            URL url = new URL(VALID_URL);
            assertTrue(RealizationUtils.validateURL(url));
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }
    */

    public void testInvalidURL() {
        try {
            assertFalse(RealizationUtils.validateURL(INVALID_URL));
        } catch (ApplierException ex) {
            return;
        }
        fail("Invalid URL: " + INVALID_URL);
    }

    public void testInvalidURL2() {
        try {
            URL url = new URL(INVALID_URL);

            assertFalse(RealizationUtils.validateURL(url));
        } catch (ApplierException ex) {
            return;
        } catch (MalformedURLException ex2) {
            fail(ex2.getMessage());
        }
        fail("Invalid URL: " + INVALID_URL);
    }

    public void testMalformedURL() {
        try {
            assertFalse(RealizationUtils.validateURL(MALFORMED_URL));
        } catch (ApplierException ex) {
            return;
        }
        fail("Malformed URL: " + MALFORMED_URL);
    }

    public void testInvalidFileURL() {
        try {
            URL url = RealizationUtilsTest.class.getResource(INVALID_FILE_URL);
            // url should be null;
            assertFalse(RealizationUtils.validateURL(url));

            assertFalse(RealizationUtils.validateURL(INVALID_FILE_URL));

        } catch (ApplierException ex) {
            return;
        }
        fail("Invalid file URL: " + INVALID_FILE_URL);
    }

    public void testValidFileURL() {
        try {
            URL url = RealizationUtilsTest.class.getResource(VALID_FILE_URL);

            assertTrue(RealizationUtils.validateURL(url));
        } catch (ApplierException ex) {
            fail(ex.getMessage());
        }
    }
}
