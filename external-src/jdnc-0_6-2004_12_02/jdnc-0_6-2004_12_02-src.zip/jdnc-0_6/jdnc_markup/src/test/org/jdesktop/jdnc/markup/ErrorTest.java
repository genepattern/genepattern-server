/*
 * $Id: ErrorTest.java,v 1.1 2004/07/31 00:26:12 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.net.URL;
import java.net.MalformedURLException;

import java.util.logging.Level;
import java.util.logging.Logger;

import junit.framework.TestCase;

import org.jdesktop.jdnc.markup.ElementTypes;

import net.openmarkup.ObjectRealizer;
import net.openmarkup.Scribe;

public class ErrorTest extends TestCase {
    
    private ObjectRealizer realizer;

    public ErrorTest() {
	super("Error Test");
    }

    protected void setUp() {
	realizer = RealizerUnitTest.createObjectRealizer();
        realizer.add(ElementTypes.get());
    }

    protected void tearDown() {
	realizer = null;
    }

    public void testIntroduction() {
	Scribe.getLogger().info("This test exercise the logging/error handling system");
	Scribe.getLogger().info("Messages printed to System.err is normal");
    }

    public void testNullURL() throws Exception {
	Object obj = null;
	try {
	    URL url = null;
	    obj = realizer.getObject(url);
	    fail("getObject should fail parsing a null url");
	} catch (Exception ex) {
	}
	assertNull(obj);
    }

    // Schema validation could probably resolve this one.
    public void testNonXML() {
	URL url = ErrorTest.class.getResource("resources/error0.xml");
	assertNotNull(url);

	Object obj = null;
	try {
	    obj = realizer.getObject(url);
	    fail("getObject should fail parsing non-xml");
	} catch (Exception ex) {
	}
	assertNull(obj);
    }

    // Schema validation could probably resolve this one.
    public void testMalformedXML() {
	URL url = ErrorTest.class.getResource("resources/error1.xml");
	assertNotNull(url);

	Object obj = null;
	try {
	    obj = realizer.getObject(url);
	    fail("getObject should fail parsing malformed xml");
	} catch (Exception ex) {
	}
	assertNull(obj);
    }

    
    public void testMissingElement() throws Exception {
	URL url = ErrorTest.class.getResource("resources/error2.xml");
	assertNotNull(url);
	assertNotNull(realizer.getObject(url));

	// error2-1.xml looks like a valid xml file but the data element is
	// closed and the table element can't handle metadata.
	url = ErrorTest.class.getResource("resources/error2-1.xml");
	assertNotNull(url);
	assertNotNull(realizer.getObject(url));
	
    }

    public void testMissingAttribute() throws Exception {
	URL url = ErrorTest.class.getResource("resources/error3.xml");
	assertNotNull(url);
	assertNotNull(realizer.getObject(url));

	// table and data contain a valid attribute and an invalid one.
	url = ErrorTest.class.getResource("resources/error3-1.xml");
	assertNotNull(url);
	assertNotNull(realizer.getObject(url));
    }

    /**
     * Tests the behaviour of invalid urls. These are serious problems.
     * The execption should be propagated to the getObject method.
     */
    public void testInvalidURL() throws Exception  {
	// Table, data source
	URL url = ErrorTest.class.getResource("resources/error4-0.xml");
	assertNotNull(url);

	Object obj = null;
	try {
	    obj = realizer.getObject(url);
	    fail("getObject should fail parsing invalid url");
	} catch (Exception ex) {
	}
	assertNull(obj);

	// editor, url is not valid. But the edtitor should still be
	// valid.
	url = ErrorTest.class.getResource("resources/error4-1.xml");
	assertNotNull(url);
	assertNotNull(realizer.getObject(url));

	// treeTable, dataSource
	url = ErrorTest.class.getResource("resources/error4-2.xml");
	assertNotNull(url);
	try {
	    obj = realizer.getObject(url);
	    fail("getObject should fail parsing invalid url");
	} catch (Exception ex) {
	}
	assertNull(obj);
    }
}
