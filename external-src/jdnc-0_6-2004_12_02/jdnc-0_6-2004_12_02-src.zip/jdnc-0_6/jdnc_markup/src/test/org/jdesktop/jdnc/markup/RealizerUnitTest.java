/*
 * $Id: RealizerUnitTest.java,v 1.1 2004/07/31 00:26:12 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.awt.Component;
import java.awt.BorderLayout;

import java.beans.Expression;

import java.io.File;

import java.lang.reflect.Constructor;

import java.util.Date;

import java.util.logging.Level;

import java.net.URL;
import java.net.MalformedURLException;

import java.text.SimpleDateFormat;

import javax.swing.*;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jdesktop.jdnc.markup.ElementTypes;

import org.jdesktop.jdnc.runner.Application;

import net.openmarkup.ObjectRealizer;
import net.openmarkup.Scribe;

import org.jdesktop.swing.JXRootPane;

import org.jdesktop.jdnc.JNEditor;
import org.jdesktop.jdnc.JNForm;

public class RealizerUnitTest extends TestCase {

    private ObjectRealizer realizer;

    private URL baseURL;

    public RealizerUnitTest(String name) {
        super(name);
        try {
            baseURL = new File(".").toURL();
        }
        catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * This method creates an implementation of the object realizer.
     * It uses the System property: openmarkup.realizer.impl
     */
    public static ObjectRealizer createObjectRealizer() {
	// This system property contains the object realizer implementation.
	String realizerImplName = System.getProperty("openmarkup.realizer.impl");
	assertNotNull(realizerImplName + " is null", realizerImplName);

	ObjectRealizer realizer = null;
	try {
	    Class cls = Class.forName(realizerImplName);
	    Object or = cls.newInstance();
	    
	    // XXX this is a big hack since the Sun ObjectRealizer doesn't
	    // use net.openmarkup.Document. This is similar to RealizationUtils.
	    try {
		realizer = (ObjectRealizer)(new Expression(or, "getInstance",
							   new Object[0])).getValue();
	    } catch (Exception ex) {
		// error
	    }

	    if (realizer == null) {
		realizer = (ObjectRealizer)or;
	    }

	} catch (Exception ex) {
	    fail(ex.toString());
	}
	assertNotNull(realizer);
	
	// Set the log level to the value of the system property
	String level = System.getProperty("openmarkup.logging.level");
	if (level != null) {
	    setLogLevel(level);
	}

	return realizer;
    }

    // Set the level of the logger.
    static void setLogLevel(Level level) {
	Scribe.getLogger().setLevel(level == null ? Level.WARNING : level);
    }

    static void setLogLevel(String level) {
	Level lvl = null;
	if (level != null) {
	    try {
		lvl = Level.parse(level.toUpperCase());
	    } catch (Exception ex) {
		// level is invalid, ignore
	    }
	}
	setLogLevel(lvl);
    }



    protected void setUp() {
        realizer = createObjectRealizer();
        realizer.add(ElementTypes.get());
    }

    protected void tearDown() {
        realizer = null;
    }

    /* XXX - this doesn't seem to work since the enode vocabulary is the only
       one presented.
         public void testRealizedObjects() {
      for (int i = 1; i <= 11; i++) {
     Object obj = realizer.getObject(baseURL, "test/test" + i + ".xml");
     System.out.println("Realized " + obj + ".");
      }
         }
     */

    /**
     * Test to see if the toolbar, menu and status bar elements are created.
     */
    public void testRootPane() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/rootpane1.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj.getClass().toString() + " is not a JRootPane",
                   obj instanceof JRootPane);
        JXRootPane root = (JXRootPane) obj;

        assertNotNull(root.getToolBar());
        assertNotNull(root.getJMenuBar());
        assertNotNull(root.getStatusBar());
    }

    public void testEditor() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/editor1.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj.getClass().toString() + " is not a JNEditor",
                   obj instanceof JNEditor);
        JNEditor editor = (JNEditor) obj;
        URL bike = RealizerUnitTest.class.getResource("resources/bike.html");
        assertEquals(bike.toString(), editor.getInputURL());
        assertEquals(bike, editor.getEditor().getPage());
    }

    public void testForm() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/form1.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj.getClass().toString() + " is not a JNForm",
                   obj instanceof JNForm);
        JNForm editor = (JNForm) obj;
    }

    /*
        public void testTabularDataMetaData() {
            URL url = RealizerUnitTest.class.getResource("./resources/tabulardatametadata.xml");
            assertNotNull(url);
            Object obj = realizer.getObject(url);
            assertNotNull(obj);
         assertTrue(obj.getClass().toString() + " is not a TabularDataModel",
                       obj instanceof TabularDataModel);
            TabularDataModel data = (TabularDataModel)obj;
            assertEquals(8, data.getColumnCount());
            MetaData metaData = data.getColumnMetaData(0);
            assertNotNull(metaData);
            MetaDataUnitTest.verifyMetaDataProperties(metaData, "bugid",
                                                      String.class, "BugID",
                                                      true, true,
         Converters.get(String.class),
                                                      null, null);
         NumberMetaData numberMetaData = (NumberMetaData)data.getColumnMetaData(1);
            assertNotNull(numberMetaData);
         MetaDataUnitTest.verifyMetaDataProperties(numberMetaData, "priority",
                                                      String.class, "Priority",
                                                      true, false,
         Converters.get(Integer.class),
                                                      null, null);
            MetaDataUnitTest.verifyNumberMetaDataProperties(numberMetaData,
                new Integer(1),
                new Integer(5), false);
            numberMetaData = (NumberMetaData) data.getColumnMetaData(2);
            assertNotNull(numberMetaData);
         MetaDataUnitTest.verifyMetaDataProperties(numberMetaData, "severity",
                                                      String.class, "Severity",
                                                      true, true,
         Converters.get(Integer.class),
                                                      null, null);
            MetaDataUnitTest.verifyNumberMetaDataProperties(numberMetaData,
                                                      null, null, false);
            metaData = data.getColumnMetaData(3);
            assertNotNull(metaData);
            MetaDataUnitTest.verifyMetaDataProperties(metaData, "engineer",
                                                      String.class, "Engineer",
                                                      false, false,
         Converters.get(String.class),
                                                      null, null);
            metaData = data.getColumnMetaData(4);
            assertNotNull(metaData);
            MetaDataUnitTest.verifyMetaDataProperties(metaData, "dispatchdate",
         String.class, "Dispatched",
                                                      true, false,
         Converters.get(Date.class),
         new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy"),
         new SimpleDateFormat("MMM dd yyyy"));
            metaData = data.getColumnMetaData(5);
            assertNotNull(metaData);
            MetaDataUnitTest.verifyMetaDataProperties(metaData, "jdcvotes",
         String.class, "JDC Votes",
                                                              true, true,
         Converters.get(String.class),
                                                              null, null);
            metaData = data.getColumnMetaData(6);
            assertNotNull(metaData);
            MetaDataUnitTest.verifyMetaDataProperties(metaData, "synopsis",
                                                      String.class, "Synopsis",
                                                      false, true,
         Converters.get(String.class),
                                                      null, null);
         EnumeratedMetaData enumMetaData = (EnumeratedMetaData)data.getColumnMetaData(7);
            assertNotNull(enumMetaData);
            MetaDataUnitTest.verifyMetaDataProperties(metaData, "state",
                                                      String.class, "State",
                                                      false, true,
         Converters.get(String.class),
                                                      null, null);
            String stateValues[] = {"dispatched", "accepted", "evaluated",
         "fixed", "integrated", "verified", "closed"};
            MetaDataUnitTest.verifyEnumeratedMetaDataProperties(enumMetaData,
                                                      stateValues);
        }
     */

    /**
     * Displays the jdnc application in a frame.
     * @param demo a string which represents the relative path to a jdnc file.
     */
    public static void showFrame(String demo) {
        URL url = RealizerUnitTest.class.getResource(demo);
        if (url == null) {
            throw new RuntimeException("url \"" + demo + "\" resource is null");
        }
        showFrame(url);
    }

    /**
     * Displays the jdnc application in a frame.
     * @param url a url which represents a jdnc file
     */
    public static void showFrame(URL url) {
        if (url == null) {
            throw new NullPointerException("url is null");
        }
	Application app = new Application(url, Level.FINE);
    }

    /**
     * Original unit tests.
     */
    public static void runTests() throws Exception  {
        ObjectRealizer realizer = RealizerUnitTest.createObjectRealizer();
        realizer.add(ElementTypes.get());

        final Date start = new Date();

        for (int i = 1; i <= 11; i++) {
            Object obj = realizer.getObject("test/test" + i + ".xml");
            System.out.println("Realized " + obj + ".");
        }

        final Date end = new Date();
        System.out.println( (end.getTime() - start.getTime()) + " ms");
    }

    public static void main(String[] args) {
        //	String app = "resources/form2.xml";
        //	showFrame("resources/action3.xml");
        //String app = "resources/action5.xml";
        //showFrame("resources/action5.xml");
	//        showFrame("resources/form1.xml");
        //showFrame("resources/form2.xml");
        //showFrame("resources/form3.xml");
        showFrame("resources/table2.xml");
        //showFrame("resources/error3-1.xml");
        //showFrame("resources/rootpane2.xml");
        //showFrame(app);
    }
}
