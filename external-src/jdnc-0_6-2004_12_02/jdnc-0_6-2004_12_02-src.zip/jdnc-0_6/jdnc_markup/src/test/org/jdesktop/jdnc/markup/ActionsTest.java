/*
 * $Id: ActionsTest.java,v 1.2 2004/09/08 01:37:45 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.awt.Component;

import java.util.logging.Level;

import javax.swing.*;

import java.net.URL;
import java.net.MalformedURLException;

import junit.framework.TestCase;

import org.jdesktop.jdnc.markup.ElementTypes;

import net.openmarkup.ObjectRealizer;
import net.openmarkup.Scribe;

import org.jdesktop.swing.actions.AbstractActionExt;
import org.jdesktop.swing.JXRootPane;

public class ActionsTest extends TestCase {

    private ObjectRealizer realizer;

    protected void setUp() {
        realizer = RealizerUnitTest.createObjectRealizer();
        realizer.add(ElementTypes.get());
    }

    protected void tearDown() {
        realizer = null;
    }

    /**
     * action1.xml is an action with values for all possible attributes.
     */
    public void testActionAttributes() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/action1.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj instanceof Action);

        Action action = (Action)obj;

        assertEquals("find", action.getValue(Action.ACTION_COMMAND_KEY));
        assertEquals("Find", action.getValue(Action.NAME));
        assertEquals("Find an item", action.getValue(Action.SHORT_DESCRIPTION));
        assertEquals("Find an item", action.getValue(Action.LONG_DESCRIPTION));
        assertTrue(((AbstractActionExt)action).isStateAction());
        assertEquals("find-group", action.getValue(AbstractActionExt.GROUP));
        assertEquals(new Integer('F'), action.getValue(Action.MNEMONIC_KEY));

        assertNotNull(action.getValue(Action.SMALL_ICON));
        assertTrue(action.getValue(Action.SMALL_ICON) instanceof Icon);
        assertTrue(action.getValue(AbstractActionExt.LARGE_ICON) instanceof Icon);
        assertTrue(action.getValue(Action.ACCELERATOR_KEY) instanceof KeyStroke);
    }

    /**
     * action0.xml tests to ensure that the action icons are found as a relative
     * url path to the document - like "images/Foo.gif"
     */
    public void testActionIcons() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/action0.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj instanceof Action);

        Action action = (Action)obj;

        Icon icon = (Icon)action.getValue(Action.SMALL_ICON);
        assertNotNull("Icon should not be null: " + icon, icon);
        assertTrue(icon instanceof Icon);

        icon = (Icon)action.getValue(AbstractActionExt.LARGE_ICON);
        assertNotNull("Icon should not be null: " + icon, icon);
        assertTrue(icon instanceof Icon);

    }

    /**
     * action6.xml: Both of the icons are bogus.
     */
    public void testActionIcons2() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/action6.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj instanceof Action);

        Action action = (Action)obj;

        Icon icon = (Icon)action.getValue(Action.SMALL_ICON);
        assertNull("Icon should be null: " + icon, icon);
        icon = (Icon)action.getValue(AbstractActionExt.LARGE_ICON);
        assertNull("Icon should be null: " + icon, icon);
    }

    /**
     * Simple test to ensure that a RootPane is created with a toolbar
     * and 3 buttons. The last button should be a toggle button.
     */
    public void testToolBarCreate() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/action2.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj.getClass().toString() + " is not a JRootPane",
                   obj instanceof JRootPane);

        JXRootPane root = (JXRootPane)obj;
        JToolBar toolbar = root.getToolBar();

        assertTrue(toolbar.getComponentCount() == 4);

        Component comp = toolbar.getComponent(3);
        assertNotNull(comp);
        assertTrue(comp.getClass().toString() + " is not a JToggleButton",
                   comp instanceof JToggleButton);
    }

    /**
     * Test to ensure that a rootpane with a menu bar has been created.
     * This also tests that entity includes are working correctly.
     */
    public void testMenuBarCreate() throws Exception {
        URL url = RealizerUnitTest.class.getResource("resources/action4.xml");
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj.getClass().toString() + " is not a JRootPane",
                   obj instanceof JRootPane);

        JXRootPane root = (JXRootPane)obj;
        JMenuBar menubar = root.getJMenuBar();
        assertNotNull(menubar);
        assertTrue(menubar.getComponentCount() == 3);

    }
}
