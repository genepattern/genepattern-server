/*
 * $Id: VocabularyUnitTest.java,v 1.1 2004/07/31 00:26:12 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.util.List;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jdesktop.jdnc.markup.ElementTypes;
import net.openmarkup.ElementType;

public class VocabularyUnitTest extends TestCase {

    public VocabularyUnitTest() {
	super("Vocabulary Unit Test");
    }

    // Dummmy test
    public void testDummy() {
    }

    public static void main(String[] args) {
        listVocabulary(ElementTypes.get().family());
    }

    private static void listVocabulary(List types) {
        System.out.println("**** BEGIN VOCABULARY ****");
        for (int i = 0; i < types.size(); i++) {
            ElementType	elemType = (ElementType) types.get(i);
            System.out.println(elemType.getFullName());
            System.out.println("\timplemented by: " + elemType.getImplementationClass());
            System.out.println("\trealized as: " + elemType.getObjectClassName());
        }
        System.out.println("**** END VOCABULARY ****");
    }
}
