/*
 * $Id: TableTest.java,v 1.3 2004/09/02 00:50:36 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.net.URL;
import java.net.MalformedURLException;

import javax.swing.SwingConstants;

import junit.framework.TestCase;

import net.openmarkup.ObjectRealizer;

import org.jdesktop.jdnc.markup.ElementTypes;

import org.jdesktop.jdnc.JNTable;

/**
 * Unit test for table element
 */
public class TableTest extends TestCase {

    private ObjectRealizer realizer;

    protected void setUp() {
        realizer = RealizerUnitTest.createObjectRealizer();
        realizer.add(ElementTypes.get());
    }

    protected void tearDown() {
        realizer = null;
    }

    /**
     * Simple utility to verify the URL and table object.
     */
    private JNTable getTable(String resource) throws Exception {
        URL url = RealizerUnitTest.class.getResource(resource);
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj.getClass().toString() + " is not a JNTable",
                   obj instanceof JNTable);

        return (JNTable) obj;
    }

    /**
     * Verify that the basic test data will create tables. All new table test cases
     * should be placed here.
     */
    public void testTable() throws Exception {
        getTable("resources/table1.xml");
        getTable("resources/table2.xml");
        getTable("resources/table2-1.xml");
        getTable("resources/table2-2.xml");
        getTable("resources/table2.xml");
        getTable("resources/table3.xml");
        getTable("resources/table4.xml");
        getTable("resources/table4-1.xml");
        getTable("resources/table5.xml");
    }

    public void testTableData() throws Exception {
        JNTable table = getTable("resources/table2.xml");

        // how do we verify that the table model has been initialized with
        // the data in bugs.txt
    }

    /**
     * Use a non-default delimiter.
     */
    public void testDataDelimeter() throws Exception {
        JNTable table = getTable("resources/table2-1.xml");

        /* The rows are loaded on the EDT. How do we get the row count?
             assertTrue("Row count should not be zero: " + table.getModel().getRowCount(),
               0 != table.getModel().getRowCount());
         */
    }

    public void testTableDataMetaData() throws Exception {
        JNTable table = getTable("resources/table2-2.xml");
    }

    /**
     * The following test verifies that the table column alignments
     * are corectly set.
     */
    public void testTableColumnAlignment() throws Exception {
        JNTable table = getTable("resources/table4-1.xml");
        assertEquals(SwingConstants.RIGHT, table.getColumnHorizontalAlignment("synopsis"));
        assertEquals(SwingConstants.TRAILING, table.getColumnHorizontalAlignment("state"));
        assertEquals(SwingConstants.TRAILING, table.getColumnHorizontalAlignment("bugid"));
        assertEquals(SwingConstants.CENTER, table.getColumnHorizontalAlignment("priority"));
        assertEquals(SwingConstants.LEFT, table.getColumnHorizontalAlignment("severity"));
        //LEADING is currently broken because JLabel doesn't fire a propertyChangeEvent when
        // horizontalAlignment is set to it since its teh default value; need to re-think
        // the way LabelProperties tracks changes.
        //assertEquals(SwingConstants.LEADING, table.getColumnHorizontalAlignment("engineer"));
        //assertEquals(SwingConstants.LEADING, table.getColumnHorizontalAlignment("dispatchdate"));
        assertEquals(-1, table.getColumnHorizontalAlignment("jdcvotes"));
    }
}