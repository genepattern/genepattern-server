/*
 * $Id: TreeTableTest.java,v 1.1 2004/10/13 07:09:41 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc.markup;

import java.net.URL;
import java.net.MalformedURLException;

import javax.swing.SwingConstants;

import junit.framework.TestCase;

import net.openmarkup.ObjectRealizer;

import org.jdesktop.jdnc.markup.ElementTypes;

import org.jdesktop.jdnc.JNTreeTable;

/**
 * Unit test for treeTable element
 */
public class TreeTableTest extends TestCase {

    private ObjectRealizer realizer;

    protected void setUp() {
        realizer = RealizerUnitTest.createObjectRealizer();
        realizer.add(ElementTypes.get());
    }

    protected void tearDown() {
        realizer = null;
    }

    /**
     * Simple utility to verify the URL and table object.
     */
    private JNTreeTable getTreeTable(String resource) throws Exception {
        URL url = RealizerUnitTest.class.getResource(resource);
        assertNotNull(url);

        Object obj = realizer.getObject(url);
        assertNotNull(obj);
        assertTrue(obj.getClass().toString() + " is not a JNTreeTable",
                   obj instanceof JNTreeTable);

        return (JNTreeTable) obj;
    }


    /**
     * Verify that the basic test data will create tables. All new table test cases
     * should be placed here.
     */
    public void testTreeTable() throws Exception {
        getTreeTable("resources/treetable00.xml");
    }
}


