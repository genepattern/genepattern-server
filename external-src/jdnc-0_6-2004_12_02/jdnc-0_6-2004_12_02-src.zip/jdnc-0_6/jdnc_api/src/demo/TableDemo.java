import java.net.URL;

import org.jdesktop.swing.JXFrame;

import org.jdesktop.swing.data.TabularDataModel;

import org.jdesktop.jdnc.JNTable;

/**
 * Simple table demo for testing.
 */
public class TableDemo {

    public static void main(String[] args) {
        JXFrame frame = new JXFrame();

        URL url = TableDemo.class.getResource("resources/bugs.tsv");
        JNTable table = new JNTable(url);
        table.setHasColumnControl(true);

        frame.addComponent(table);
        frame.setVisible(true);
    }
}
