/*
 * $Id: TableFormDemo.java,v 1.2 2004/09/03 21:20:19 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

/**
 * JavaOne 2004 JDNC demo which loads bug records into a TabularDataModel
 * from a .tsv file, displays a summary view of those records in a JNTable
 * and enables the selected bug record to be edited in a JNForm.
 *
 * @author Amy Fowler
 * @version 1.0
 */

import java.net.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

import org.jdesktop.jdnc.*;
import org.jdesktop.swing.*;
import org.jdesktop.swing.binding.BindException;
import org.jdesktop.swing.data.*;
import org.jdesktop.swing.decorator.*;
import org.jdesktop.swing.form.*;
import org.jdesktop.swing.table.*;

public class TableFormDemo {
    public static final Color BACKGROUND = new Color(238, 238, 238);
    public static final Color BACKGROUND2 = new Color(236, 236, 237);
    public static final Color BACKGROUND3 = new Color(254, 254, 254);

    protected Application app = Application.getInstance();
    protected TabularDataModel bugData = null;

    public TableFormDemo() {
        this(null);
    }

    public TableFormDemo(String urlString) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception e) {
        }

        try {
            bugData = initializeData(urlString);
        }
        catch (MalformedURLException e) {
            JOptionPane.showMessageDialog( (Window) app.getWindows().next(),
                                          e.getMessage(),
                                          "Data Initialization Error",
                                          JOptionPane.ERROR_MESSAGE);
        }
        initializeGUI(bugData);
    }

    protected TabularDataModel initializeData(String urlString) throws
        MalformedURLException {

        TabularDataModel data = new TabularDataModel(getDataURL(urlString));

        /******************************************************
         * Explicitly initialize metadata *before* loading data
         ******************************************************/
        data.setColumnCount(8);

        // column0:"bugid"
        MetaData metaData = new MetaData("bugid", String.class, "Bug ID");
        metaData.setReadOnly(true);
        data.setColumnMetaData(0, metaData);

        // column1:"priority"
        NumberMetaData numberMetaData = new NumberMetaData("priority",
            Integer.class, "Priority");
        numberMetaData.setMinimum(new Integer(1));
        numberMetaData.setMaximum(new Integer(5));
        numberMetaData.setRequired(true);
        data.setColumnMetaData(1, numberMetaData);

        // column2:"severity"
        numberMetaData = new NumberMetaData("severity", Integer.class,
                                            "Severity");
        numberMetaData.setReadOnly(true);
        data.setColumnMetaData(2, numberMetaData);

        // column3:"engineer"
        StringMetaData stringMetaData = new StringMetaData("engineer",
            "Engineer");
        stringMetaData.setMaxLength(36);
        data.setColumnMetaData(3, stringMetaData);

        // column4:"dispatchdate"
        metaData = new MetaData("dispatchdate", Date.class, "Dispatched");
        metaData.setReadOnly(true);
        metaData.setDecodeFormat(new SimpleDateFormat(
            "EEE MMM dd HH:mm:ss z yyyy"));
        metaData.setEncodeFormat(new SimpleDateFormat("MMM dd, yyyy"));
        data.setColumnMetaData(4, metaData);

        // column5:"jdcvotes"
        numberMetaData = new NumberMetaData("jdcvotes", Integer.class,
                                            "JDC Votes");
        numberMetaData.setReadOnly(true);
        data.setColumnMetaData(5, numberMetaData);

        // column6:"synopsis"
        stringMetaData = new StringMetaData("synopsis", "Synopsis");
        stringMetaData.setRequired(true);
        stringMetaData.setMaxLength(64);
        stringMetaData.setDisplayWidth(64);
        data.setColumnMetaData(6, stringMetaData);

        // column7:"state"
        EnumeratedMetaData enumMetaData = new EnumeratedMetaData("state",
            String.class, "State");
        enumMetaData.setRequired(true);
        String states[] = {
            "dispatched", "accepted", "evaluated", "fixed", "integrated",
            "verified", "closed"};
        enumMetaData.setEnumeration(states);
        data.setColumnMetaData(7, enumMetaData);

        /******************************
         * Kickoff asynchronous loading
         ******************************/
        startLoadingData(data);

        return data;
    }

    protected URL getDataURL(String urlString) throws MalformedURLException {
        if (urlString != null) {
            return new URL(urlString);
        }
        // fallback to hardcoded url values
        URL baseURL = app.getBaseURL(); // will be non-null if deployed from applet or webstart
        URL dataURL = dataURL = baseURL != null ?
            new URL(baseURL, "resources/bugs.tsv") :
            new URL("file:" + System.getProperty("user.dir") +
                    "/src/demo/resources/bugs.tsv");
        return dataURL;
    }

    protected void startLoadingData(TabularDataModel data) {
        try {
            data.startLoading();
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog( (Window) app.getWindows().next(),
                                          e.getMessage(),
                                          "Data Loading Error",
                                          JOptionPane.ERROR_MESSAGE);
        }
    }

    protected void initializeGUI(TabularDataModel data) {

        JXFrame frame = new JXFrame("Bug Editor");
        app.registerWindow(frame);

        JXRootPane rootPane = frame.getRootPaneExt();
        // note: JXFrame should have a setToolBar() method
        JToolBar toolbar = new JToolBar();
        rootPane.setToolBar(toolbar);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setBackground(BACKGROUND);
        frame.getContentPane().add(BorderLayout.CENTER, splitPane);

        JNTable table = initializeTable(data);
        splitPane.setTopComponent(table);
        setupFiltering(table, toolbar);

        JNForm form = initializeForm(table, data);
        splitPane.setBottomComponent(form);

        frame.pack();
        frame.show();
    }

    protected JNTable initializeTable(TabularDataModel data) {

        JNTable table = new JNTable();
        table.setBackground(BACKGROUND);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setEvenRowBackground(BACKGROUND3);
        table.setShowHorizontalLines(false);
        table.setHasColumnControl(true);
        table.setPreferredVisibleRowCount(12);

        table.setHeaderBackground(BACKGROUND2);

        // need to create our own column objects because we want a *re-ordered subset*
        // of those in the model; this is cumbersome -- we need something cleaner
        // to avoid forcing the jtable access and direct TableColumn creation.
        JTable jtable = table.getTable();
        jtable.setAutoCreateColumnsFromModel(false);
        table.setModel(data);

        // "BugID"
        TableColumnExt column = new TableColumnExt(0);
        column.setIdentifier("bugid");
        table.addColumn(column);
        table.setColumnHorizontalAlignment("bugid", JLabel.CENTER);

        // "State"
        column = new TableColumnExt(7);
        column.setIdentifier("state");
        table.addColumn(column);
        table.setColumnHorizontalAlignment("state", JLabel.CENTER);
        table.setColumnPrototypeValue("state", "evaluated");

        // "Priority"
        column = new TableColumnExt(1);
        column.setIdentifier("priority");
        table.addColumn(column);
        table.setColumnPrototypeValue("priority", new Integer(1));

        HashMap enumMap = new HashMap(); // map priority values to rendering properties
        enumMap.put("1", createLabelProperties(" ", "resources/p1.gif",
                                               JLabel.CENTER, JLabel.LEADING));
        enumMap.put("2", createLabelProperties(" ", "resources/p2.gif",
                                               JLabel.CENTER, JLabel.LEADING));
        enumMap.put("3", createLabelProperties(" ", "resources/p3.gif",
                                               JLabel.CENTER, JLabel.LEADING));
        enumMap.put("4", createLabelProperties(" ", "resources/p4.gif",
                                               JLabel.CENTER, JLabel.LEADING));
        enumMap.put("5", createLabelProperties(" ", "resources/p5.gif",
                                               JLabel.CENTER, JLabel.LEADING));
        setupEnumRenderer(column, enumMap);

        // "Severity"
        column = new TableColumnExt(2);
        column.setIdentifier("severity");
        table.addColumn(column);
        table.setColumnHorizontalAlignment("severity", JLabel.CENTER);
        table.setColumnPrototypeValue("severity", new Integer(5));

        enumMap = new HashMap(); // map severity values to rendering properties
        enumMap.put("1", createLabelProperties("severe", "resources/s1.gif",
                                               JLabel.TRAILING, JLabel.LEADING));
        enumMap.put("2", createLabelProperties("serious", "resources/s2.gif",
                                               JLabel.TRAILING, JLabel.LEADING));
        enumMap.put("3", createLabelProperties("significant", "resources/s3.gif",
                                               JLabel.TRAILING, JLabel.LEADING));
        enumMap.put("4", createLabelProperties("normal", "resources/s4.gif",
                                               JLabel.TRAILING, JLabel.LEADING));
        enumMap.put("5", createLabelProperties("insignificant", "resources/s5.gif",
                                               JLabel.TRAILING, JLabel.LEADING));
        setupEnumRenderer(column, enumMap);

        // "Synopsis"
        column = new TableColumnExt(6);
        column.setIdentifier("synopsis");
        table.addColumn(column);
        table.setColumnPrototypeValue("synopsis",
            "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

        // "Engineer"
        column = new TableColumnExt(3);
        column.setIdentifier("engineer");
        table.addColumn(column);
        table.setColumnPrototypeValue("engineer",
                                      "xxxxxxxxxxxxxxxxx");

        return table;
    }

    protected LabelProperties createLabelProperties(String text, String iconPath,
                                                 int alignment, int textPosition) {
        LabelProperties props = new LabelProperties();
        props.setHorizontalAlignment(alignment);
        props.setText(text);
        props.setHorizontalTextPosition(textPosition);
        props.setIcon(new ImageIcon(TableFormDemo.class.getResource(iconPath)));
        return props;
    }

    protected void setupEnumRenderer(TableColumnExt column,
                                     final HashMap enumMap) {
        // need to make this easier in either JNTable and possibly JXTable
        column.setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table,
                Object value, boolean isSelected, boolean hasFocus, int row,
                int column) {
                JLabel label = (JLabel)super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);
                // RG: value could be null
                LabelProperties props = value == null ? null :
                    (LabelProperties) enumMap.get(value.toString());
                if (props != null) {
                    props.applyPropertiesTo(label);
                }
                return label;
            }
        });
    }

    protected void setupFiltering(JNTable table, JToolBar toolbar) {

        Filter filters[] = new Filter[1];
        filters[0] = new PatternFilter("", Pattern.CASE_INSENSITIVE, 6);
        table.setFilters(new FilterPipeline(filters));

        JXSearchPanel searchPanel = new JXSearchPanel();
        searchPanel.setPatternFilter( (PatternFilter) filters[0]);
        searchPanel.setTargetComponent(table.getTable());
        toolbar.add(searchPanel);
    }

    protected JNForm initializeForm(JNTable table, TabularDataModel data) {

        JNForm form = new JNForm();
        form.setBackground(BACKGROUND3);

        // ensure table selection will automatically load selected record into form
        TabularDataModelAdapter adapter = new TabularDataModelAdapter(data);
        new RowSelector(table.getTable(), adapter);

        try {
            form.bind(adapter);
        }
        catch (BindException e) {
            e.printStackTrace();
        }
        return form;
    }

    public static void main(String args[]) {
        TableFormDemo demo = new TableFormDemo();
    }

}