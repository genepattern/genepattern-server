/*
 * $Id: JNActionsTest.java,v 1.1 2004/07/31 00:17:19 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc;

import org.jdesktop.swing.actions.AbstractActionExt;
import org.jdesktop.swing.actions.BoundAction;
import org.jdesktop.swing.actions.TargetableAction;

import org.jdesktop.jdnc.actions.CollapseAction;
import org.jdesktop.jdnc.actions.ExpandAction;
import org.jdesktop.jdnc.actions.FindAction;
import org.jdesktop.jdnc.actions.PrintAction;
import org.jdesktop.jdnc.actions.SubmitAction;
import org.jdesktop.jdnc.actions.ResetAction;

import junit.framework.TestCase;

/**
 * Tests the concrete implementations of actions.
 */
public class JNActionsTest extends TestCase {
    
    private AbstractActionExt[] actions;

    private static final int NUM_ACTIONS = 6;

    protected void setUp() {
	actions = new AbstractActionExt[NUM_ACTIONS];
	actions[0] = new CollapseAction();
	actions[1] = new ExpandAction();
	actions[2] = new FindAction();
	actions[3] = new PrintAction();
	actions[4] = new SubmitAction();
	actions[5] = new ResetAction();
    }

    public void testProperties() {

	assertEquals("Submit", actions[4].getName());
	assertEquals("submit", actions[4].getActionCommand());

	assertEquals("Reset", actions[5].getName());
	assertEquals("reset", actions[5].getActionCommand());

    }
}

