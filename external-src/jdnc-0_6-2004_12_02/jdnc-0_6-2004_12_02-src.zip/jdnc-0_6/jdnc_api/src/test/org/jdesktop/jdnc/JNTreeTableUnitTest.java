/*
 * $Id: JNTreeTableUnitTest.java,v 1.3 2004/10/18 19:57:27 bino_george Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.ImageIcon;

import org.jdesktop.swing.JXSearchPanel;

import org.jdesktop.swing.decorator.AlternateRowHighlighter;
import org.jdesktop.swing.decorator.HierarchicalColumnHighlighter;
import org.jdesktop.swing.decorator.Highlighter;
import org.jdesktop.swing.decorator.HighlighterPipeline;
import org.jdesktop.swing.decorator.PatternHighlighter;
import org.jdesktop.swing.decorator.PatternFilter;
import org.jdesktop.swing.decorator.FilterPipeline;
import org.jdesktop.swing.decorator.Filter;
import org.jdesktop.swing.treetable.FileSystemModel;
import org.jdesktop.swing.treetable.TreeTableModel;

import org.jdesktop.jdnc.actions.CollapseAction;
import org.jdesktop.jdnc.actions.ExpandAction;

/**
 * JNTreeTableUnitTest
 *
 * @author Ramesh Gupta
 */
public class JNTreeTableUnitTest extends junit.framework.TestCase {

    public JNTreeTableUnitTest(String name) {
        super(name);
    }

    /**
     * Basic instantiation test. Make sure that no exceptions are thrown
     */
    public void testInstantiate() {
        JNTreeTable tt = new JNTreeTable();
    }


    /**
     * Basic instantiation test. Make sure that no exceptions are thrown
     */
    public void testInstantiateWithFileSystemModel() {
        TreeTableModel treeTableModel = new FileSystemModel();
        JNTreeTable tt = new JNTreeTable(treeTableModel);
    }

    /*
     * Test getModel
     */
    public void testGetTreeTableModel() {
        JNTreeTable tt = new JNTreeTable();
        assertNotNull(tt.getTreeTableModel());
    }
    /*
     * Test setModel
     */
    public void testSetTreeTableModel() {
        JNTreeTable tt = new JNTreeTable();
        tt.setTreeTableModel(new FileSystemModel());
    }


    /*
     * Test getTreeTable
     */
    public void testGetTreeTable() {
        JNTreeTable ttable = new JNTreeTable();
        assertNotNull(ttable.getTreeTableModel());
    }


    /*
     * Test Highlighter
     */
    public void testPatternHighlighter() {
        JNTreeTable tt = new JNTreeTable();
        PatternHighlighter  patternHighlighter =
                       new PatternHighlighter(null, Color.red, null, 0, 0);

        tt.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        AlternateRowHighlighter.quickSilver,
                        new HierarchicalColumnHighlighter(),
                        patternHighlighter,
                    }));

    }


    /*
     * Test Filter
     */
    public void testPatternFilter() {
        JNTreeTable tt = new JNTreeTable();
        PatternFilter  patternFilter = new PatternFilter("", 0, 0);
        tt.setFilters(new FilterPipeline(new Filter[] {
                        patternFilter,
                        }));

    }
   
    /*
     * Test setCollapsedIcon
     *
     */
    public void testSetCollapsedIcon() {
       JNTreeTable tt = new JNTreeTable();
       tt.setCollapsedIcon(new ImageIcon(
            JNTreeTableUnitTest.class.getResource("resources/down.png")));
    } 
 
    /*
     * Test setClosedIcon
     *
     */
    public void testSetClosedIcon() {
       JNTreeTable tt = new JNTreeTable();
       tt.setClosedIcon(new ImageIcon(
            JNTreeTableUnitTest.class.getResource("resources/down.png")));
    } 
    /*
     * Test setExpandedIcon
     *
     */
    public void testSetExpandedIcon() {
       JNTreeTable tt = new JNTreeTable();
       tt.setExpandedIcon(new ImageIcon(
            JNTreeTableUnitTest.class.getResource("resources/down.png")));
    } 
    /*
     * Test setLeafIcon
     *
     */
    public void testSetLeafIcon() {
       JNTreeTable tt = new JNTreeTable();
       tt.setLeafIcon(new ImageIcon(
            JNTreeTableUnitTest.class.getResource("resources/down.png")));
    } 
    /*
     * Test setOpenIcon
     *
     */
    public void testSetOpenIcon() {
       JNTreeTable tt = new JNTreeTable();
       tt.setOpenIcon(new ImageIcon(
            JNTreeTableUnitTest.class.getResource("resources/down.png")));
    } 




  
    public static void main(String[] args) {
        try {
            //      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception ex) {

        }

        final TestCase[] testCases = createTestCases();
        if (testCases.length > 0) {
            // Automatically exit after last window is closed.
            testCases[testCases.length - 1].frame.setDefaultCloseOperation(
                                                                           JFrame.EXIT_ON_CLOSE);

            Point   location = testCases[0].frame.getLocation();

            for (int i = testCases.length - 1; i >= 0; i--) {
                location.translate(30,30);      // stagger frames
                testCases[i].frame.setTitle("JNTreeTable Unit Test " + (i+1));
                testCases[i].frame.setLocation(location);
                testCases[i].frame.setVisible(true);
            }
        }
    }

    /**
     * For unit testing only
     * @return
     */
    private static TestCase[] createTestCases() {

        final TreeTableModel treeTableModel = new FileSystemModel();    // shared

        final TestCase[] testCases = new TestCase[] {
            new TestCase(treeTableModel) {
                public JComponent define() {
                    //PatternFilter             patternFilter = new PatternFilter(0, null, 0);
                    PatternHighlighter  patternHighlighter =
                        new PatternHighlighter(null, Color.red, null, 0, 0);

                    JNTreeTable treeTable = new JNTreeTable(model);

                    JXSearchPanel       searchPanel = new JXSearchPanel();
                    //searchPanel.setPatternFilter(patternFilter);
                    searchPanel.setPatternHighlighter(patternHighlighter);
                    searchPanel.setTargetComponent(treeTable);

                    treeTable.setRowHeight(22);
                    treeTable.setRowMargin(1);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        AlternateRowHighlighter.quickSilver,
                        new HierarchicalColumnHighlighter(),
                        patternHighlighter,
                    }));

                    //treeTable.setFilters(new FilterPipeline(new Filter[] {
                    //    patternFilter,
                    //    }));
                    ExpandAction        expand = new ExpandAction();
                    expand.putValue("delegate", treeTable);
                    treeTable.addAction(expand);
                    CollapseAction      collapse = new CollapseAction();
                    collapse.putValue("delegate", treeTable);
                    treeTable.addAction(collapse);
                    treeTable.addToolBarComponent(searchPanel);
                    return treeTable;
                }
            },

        };
        return testCases;
    }

    private static abstract class TestCase {

        public TestCase(TreeTableModel model) {
            this.model = model;
            this.frame = wrap(define());
        }

        public abstract JComponent define();

        public JFrame wrap(JComponent component) {
            final JFrame frame = new JFrame();
            component.setPreferredSize(new Dimension(600, 304));
            frame.getContentPane().add(component);
            frame.pack();
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            return frame;
        }

        public final TreeTableModel  model;
        public final JFrame          frame;
    }

    private JNTreeTableUnitTest() {
    }
}
