/*
 * $Id: JNTableUnitTest.java,v 1.5 2004/10/14 01:28:21 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;

import java.io.IOException;

import java.net.MalformedURLException;
import java.net.URL;

import java.text.SimpleDateFormat;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jdesktop.swing.InteractiveTestCase;
import org.jdesktop.swing.JXSearchPanel;

import org.jdesktop.swing.data.Converters;
import org.jdesktop.swing.data.EnumeratedMetaData;
import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.NumberMetaData;
import org.jdesktop.swing.data.TabularDataModel;

import org.jdesktop.swing.decorator.AlternateRowHighlighter;
import org.jdesktop.swing.decorator.Filter;
import org.jdesktop.swing.decorator.FilterPipeline;
import org.jdesktop.swing.decorator.Highlighter;
import org.jdesktop.swing.decorator.HighlighterPipeline;
import org.jdesktop.swing.decorator.PatternFilter;
import org.jdesktop.swing.decorator.PatternHighlighter;

import org.jdesktop.swing.table.TableColumnExt;

import org.jdesktop.jdnc.actions.FindAction;
import org.jdesktop.jdnc.actions.PrintAction;

public class JNTableUnitTest extends InteractiveTestCase {

    final static String DATA_URL = "resources/bugdata.txt";

    final static String bugstates[] = {
        "dispatched", "accepted", "evaluated", "committed",
        "fixed", "integrated", "verified", "closed"};

    public static TabularDataModel createRawData(URL dataURL) {
        TabularDataModel rawData = new TabularDataModel(dataURL);
        try {
            rawData.startLoading();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return rawData;
    }

    public static TabularDataModel createRichData(URL dataURL) {
        TabularDataModel richdata = new TabularDataModel(dataURL);
        richdata.setColumnCount(8);

        MetaData metaData = richdata.getColumnMetaData(0);
        metaData.setName("bugid");
        metaData.setLabel("Bug ID");
        metaData.setElementClass(java.lang.Integer.class);

        NumberMetaData numberMetaData = new NumberMetaData("priority");
        numberMetaData.setLabel("Pri");
        numberMetaData.setMinimum(new Integer(1));
        numberMetaData.setMaximum(new Integer(5));
        richdata.setColumnMetaData(1, numberMetaData);

        numberMetaData = new NumberMetaData("severity");
        numberMetaData.setLabel("Sev");
        numberMetaData.setReadOnly(true);
        richdata.setColumnMetaData(2, numberMetaData);

        metaData = richdata.getColumnMetaData(3);
        metaData.setName("engineer");
        metaData.setLabel("Engineer");

        metaData = richdata.getColumnMetaData(4);
        metaData.setName("dispatchdate");
        metaData.setLabel("Dispatched");
        metaData.setElementClass(java.util.Date.class);
        metaData.setDecodeFormat(new SimpleDateFormat(
            "EEE MMM dd HH:mm:ss zzz yyyy"));

        numberMetaData = new NumberMetaData("jdcvotes");
        numberMetaData.setLabel("JDC Votes");
        numberMetaData.setReadOnly(true);
        richdata.setColumnMetaData(5, numberMetaData);

        metaData = richdata.getColumnMetaData(6);
        metaData.setName("synopsis");
        metaData.setLabel("Synopsis");

        EnumeratedMetaData enumMetaData = new EnumeratedMetaData("state");
        enumMetaData.setLabel("State");
        enumMetaData.setEnumeration(bugstates);
        richdata.setColumnMetaData(7, enumMetaData);

        try {
            richdata.startLoading();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return richdata;
    }

    private URL dataURL;
    private TabularDataModel rawdata;
    private TabularDataModel richdata;

    private Point frameLocation = new Point(0,0);

    public JNTableUnitTest() {
        super("JNTable unit test");
    }

    protected void setUp() {
        dataURL = JNTableUnitTest.class.getResource(DATA_URL);

        // Create two flavors of data for test purposes:
        // rawdata: no metadata, all values interpretted as raw strings
        // richdata: with metadata, including type, edit constraints, etc.
        rawdata = createRawData(dataURL);
        richdata = createRichData(dataURL);
    }

    // Dummmy test
    public void testInstantiation() {
        JNTable table = new JNTable();
    }

    /**
     * This will fail because of Issue 102
     */
    public void testHighlighers() {
       Highlighter[]   highlighters = new Highlighter[] {
           new AlternateRowHighlighter(Color.white, new Color(0xF0, 0xF0, 0xE0), null),
           new PatternHighlighter(null, Color.red, "s.*", 0, 0)
       };

       HighlighterPipeline highlighterPipeline = new HighlighterPipeline(highlighters);
       JNTable table = new JNTable();
       table.setHighlighters(highlighterPipeline);
       table.setColumnForeground("bugid", Color.green);
    }

    public void interactiveTestJNTableActions() {
        JNTable table = new JNTable(rawdata);
        PatternFilter patternFilter = new PatternFilter(null, 0, 3);
        JXSearchPanel searchPanel = new JXSearchPanel();
        searchPanel.setPatternFilter(patternFilter);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            patternFilter,
        }));

        PrintAction print = new PrintAction();
        print.putValue("delegate", table);
        table.addAction(print);

        FindAction search = new FindAction();
        search.putValue("delegate", table);
        table.addAction(search);
        table.addToolBarComponent(searchPanel);
        JFrame frame = wrapInFrame(table, "JNTable Actions");
        frame.show();
    }

    public void interactiveTestJNTableAlternatingRowColors() {
        JNTable table = new JNTable(rawdata);
        table.setOddRowBackground(new Color(0xCC, 0xCC, 0xFF));
        table.setEvenRowBackground(Color.white);
        table.setShowHorizontalLines(false);
        JFrame frame = wrapInFrame(table, "JNTable Alternating Row Colors");
        frame.show();
    }

    public void interactiveTestJNTableRowHeaderLocked() {
        JNTable table = new JNTable(rawdata);
        table.setRowHeaderLocked(true);
        JFrame frame = wrapInFrame(table, "JNTable RowHeader Locked");
        frame.show();
    }

    public void interactiveTestJNTableColumnControl() {
        JNTable table = new JNTable(rawdata);
        table.setRowHeaderLocked(false);
        table.setHasColumnControl(true);
        JFrame frame = wrapInFrame(table, "JNTable ColumnControl");
        frame.show();
    }

    public void interactiveTestJNTableColumnProperties() {
        JNTable table = new JNTable(richdata);
        table.setOddRowBackground(Color.cyan);

        table.setHeaderBackground(Color.blue);
        table.setHeaderForeground(Color.white);
        table.setHeaderFont(new Font("sanserif", Font.BOLD, 18));
        table.setHeaderSortDownIcon(new ImageIcon(
            JNTableUnitTest.class.getResource("resources/down.png")));
        table.setHeaderSortUpIcon(new ImageIcon(
            JNTableUnitTest.class.getResource("resources/up.png")));

        table.setColumnHorizontalAlignment("bugid", JLabel.CENTER);
        table.setColumnPrototypeValue("bugid", "888888");
        table.setColumnBackground("dispatchdate", Color.green);
        table.setColumnBackground("priority", Color.red);
        table.setColumnForeground("priority", Color.blue);
        table.setColumnPrototypeValue("priority", new Integer(5));
        table.setColumnFont("priority", new Font("sanserif", Font.ITALIC, 20));
        table.setColumnBackground("severity", Color.black);
        table.setColumnForeground("severity", Color.white);
        table.setColumnPrototypeValue("synopsis", "JTable Horizontal Scrollbar doesn't work");

        JFrame frame = wrapInFrame(table, "JNTable Column Properties");
        frame.show();
    }

    public void interactiveTestJNTableFiltering() {
        final JNTable table = new JNTable(richdata);
        table.setHasColumnControl(true);

        Filter[] filters = new Filter[] {
            new PatternFilter(".*", 0, 0)};

        FilterPipeline fp = new FilterPipeline(filters) {
            public void flush() {
                super.flush();
                // Would be better if these were invisible rather than removed.
                table.removeColumn(table.getColumn("jdcvotes"));
                table.removeColumn(table.getColumn("dispatchdate"));
                table.removeColumn(table.getColumn("state"));
            }
        };

        table.setFilters(fp);
        table.setOddRowBackground(new Color(255, 0, 0));

        JFrame frame = wrapInFrame(table, "JNTable Filtering");
        frame.show();

    }

    public static void main(String args[]) {
        JNTableUnitTest test = new JNTableUnitTest();
        test.setUp();
        try {
            //test.runInteractiveTests();
            test.interactiveTestJNTableColumnProperties();
        } catch (Exception e) {
            System.err.println("exception when executing interactive tests:");
            e.printStackTrace();
        }
    }
}

