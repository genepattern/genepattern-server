/*
 * $Id: JNFormUnitTest.java,v 1.1 2004/07/31 00:17:19 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.jdnc;

import org.jdesktop.swing.data.DefaultDataModel;
import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.EnumeratedMetaData;
import org.jdesktop.swing.data.StringMetaData;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;

import junit.framework.TestCase;



public class JNFormUnitTest extends TestCase {

    public static final String creditCardTypes[] = {
        "VISA", "MasterCard", "American Express"
    };

    // Dummy test. Remove when real tests have been added.
    public void testDummy() {
    }

    public void interactiveTestJNForm1() {
        DefaultDataModel billingModel = new DefaultDataModel();

        StringMetaData metaData = new StringMetaData("name", "Name on Credit Card");
        billingModel.addField(metaData);

        EnumeratedMetaData enumMetaData = new EnumeratedMetaData("type", String.class, "Type");
        enumMetaData.setEnumeration(creditCardTypes);
        enumMetaData.setMinValueCount(1);
        billingModel.addField(enumMetaData);

        metaData = new StringMetaData("number", "Number");
        metaData.setMaxLength(16);
        metaData.setMinValueCount(1);
        billingModel.addField(metaData);

        metaData = new StringMetaData("expiration", "Expiration");
        metaData.setMinValueCount(1);
        billingModel.addField(metaData);

        JNForm form = new JNForm();
        try {
            form.bind(billingModel);
        } catch (Exception e) {
            System.out.println(e);
        }

        JFrame frame = new JFrame("Form Test1");
        frame.getContentPane().add(BorderLayout.CENTER, form);
        frame.pack();
        frame.setVisible(true);

    }

    public static void main(String args[]) {
        JNFormUnitTest test = new JNFormUnitTest();
        test.interactiveTestJNForm1();
    }
}
