import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;
import javax.swing.*;
import org.jdesktop.swing.calendar.*;

public class JXMonthViewDemo {
    public static void main(String args[]) {
        JFrame frame = new JFrame("Month Viewer Test App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        final JXMonthView monthView = new JXMonthView();
        //monthView.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

        Calendar cal1 = Calendar.getInstance();
        cal1.set(2004, 1, 1);
        Calendar cal2 = Calendar.getInstance();
        cal2.set(2004, 1, 5);

        long[] flaggedDates = new long[] {
            cal1.getTimeInMillis(),
            cal2.getTimeInMillis(),
            System.currentTimeMillis()
        };
        java.util.Arrays.sort(flaggedDates);

        monthView.setFlaggedDates(flaggedDates);

        monthView.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println(
                    ((JXMonthView)e.getSource()).getSelectedDateSpan());
            }
        });

        monthView.setFirstDayOfWeek(Calendar.MONDAY);
        //monthView.setAntialiased(true);
        monthView.setPreferredCols(1);
        monthView.setPreferredRows(2);
        monthView.setSelectionMode(JXMonthView.NO_SELECTION);
        monthView.setTodayBackground(Color.BLUE);

        // Create controller panel
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));

        JButton button = new JButton("Toggle orientation");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                monthView.setComponentOrientation(
                    (monthView.getComponentOrientation() ==
                        ComponentOrientation.RIGHT_TO_LEFT) ?
                            ComponentOrientation.LEFT_TO_RIGHT :
                            ComponentOrientation.RIGHT_TO_LEFT);
                monthView.repaint();
            }
        });
        controlPanel.add(button);
        controlPanel.add(Box.createHorizontalStrut(5));

        JLabel label = new JLabel("Selection Mode:");
        controlPanel.add(label);
        JComboBox cBox = new JComboBox(new String[] { "None", "Single",
            "Multiple", "Week" });
        cBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                JComboBox c = (JComboBox)ev.getSource();
                int index = c.getSelectedIndex();
                monthView.setSelectedDateSpan(null);
                monthView.setSelectionMode(index);
            }
        });
        controlPanel.add(cBox);
        controlPanel.add(Box.createHorizontalStrut(5));

        label = new JLabel("Anti-aliased text:");
        controlPanel.add(label);
        JCheckBox checkBox = new JCheckBox();
        checkBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                JCheckBox c = (JCheckBox)ev.getSource();
                monthView.setAntialiased(c.isSelected());
            }
        });
        controlPanel.add(checkBox);

        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(monthView, BorderLayout.CENTER);
        frame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
        frame.pack();
        frame.setVisible(true);
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                monthView.setSelectedDateSpan(new DateSpan(
                        new Date(System.currentTimeMillis()),
                        new Date(System.currentTimeMillis())));
                monthView.setSelectedDateSpan(null);
                //monthView.ensureDateVisible(cal.getTimeInMillis());
            }
        });     
    }               
}
