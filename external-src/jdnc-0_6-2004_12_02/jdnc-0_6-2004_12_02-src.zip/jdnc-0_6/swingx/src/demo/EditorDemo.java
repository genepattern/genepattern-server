/*
 * $Id: EditorDemo.java,v 1.3 2004/10/29 04:39:23 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
import java.util.ArrayList;
import java.util.List;

import javax.swing.JMenuBar;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;

import org.jdesktop.swing.Application;
import org.jdesktop.swing.JXEditorPane;
import org.jdesktop.swing.JXFrame;
import org.jdesktop.swing.JXRootPane;
import org.jdesktop.swing.JXStatusBar;

import org.jdesktop.swing.actions.AbstractActionExt;
import org.jdesktop.swing.actions.ActionFactory;
import org.jdesktop.swing.actions.ActionManager;

/**
 * This is a demo of the editor component and the actions framework. This
 * is the programmatic way of creating the editorDemo.jdnc xml application.
 *
 * @author Mark Davidson
 */
public class EditorDemo {

    private JXFrame frame;

    public EditorDemo() {
        initActions();
        initUI();

        frame.setVisible(true);
    }

    /**
     * Load all the managed actions into the action manager. This is property
     * oriented and kind of tedious. This is the sort of problem that that xml is good for.
     */
    protected void initActions() {
        ActionManager manager = Application.getInstance().getActionManager();

        // Construct all the actions in this application. This is tedious but
        // the xml version is a little less so. Perhaps it would be nice to have
        // a mini action xml parser.

        manager.addAction(ActionFactory.createTargetableAction("file-menu", "File", "F"));
        manager.addAction(ActionFactory.createTargetableAction("edit-menu", "Edit", "E"));
        manager.addAction(ActionFactory.createTargetableAction("format-menu", "Format", "O"));

        AbstractActionExt action;

        action("new-command", "New", "N", "Create a new document",
               "/toolbarButtonGraphics/general/New16.gif",
               "/toolbarButtonGraphics/general/New24.gif", null, false);

        action("open-command", "Open", "O", "Open a new document",
               "/toolbarButtonGraphics/general/Open16.gif",
               "/toolbarButtonGraphics/general/Open24.gif", null, false);

        action("cut-to-clipboard", "Cut", "C", "Cut to clipboard",
               "/toolbarButtonGraphics/general/Cut16.gif",
               "/toolbarButtonGraphics/general/Cut24.gif", null, false);

        action("copy-to-clipboard", "Copy", "P", "Copy to clipboard",
               "/toolbarButtonGraphics/general/Copy16.gif",
               "/toolbarButtonGraphics/general/Copy24.gif", null, false);

        action("paste-from-clipboard", "Paste", "T", "Paste to clipboard",
               "/toolbarButtonGraphics/general/Paste16.gif",
               "/toolbarButtonGraphics/general/Paste24.gif", null, false);

        action("undo", "Undo", "U", "Reverse a transaction",
               "/toolbarButtonGraphics/general/Undo16.gif",
               "/toolbarButtonGraphics/general/Undo24.gif", null, false);

        action("redo", "Redo", "R", "Restore an undone transaction",
               "/toolbarButtonGraphics/general/Redo16.gif",
               "/toolbarButtonGraphics/general/Redo24.gif", null, false);

        action("find", "Find", "F", "Find an item",
               "/toolbarButtonGraphics/general/Find16.gif",
               "/toolbarButtonGraphics/general/Find24.gif", null, false);

        action("print", "Print", "P", "Print the document",
               "/toolbarButtonGraphics/general/Print16.gif",
               "/toolbarButtonGraphics/general/Print24.gif", null, false);

        action("about", "About", "A", "About this application",
               "/toolbarButtonGraphics/general/About16.gif",
               "/toolbarButtonGraphics/general/About24.gif", null, false);

        // Text editing commands.

        action("font-bold", "Bold", "B", "Bold current selection",
               "/toolbarButtonGraphics/text/Bold16.gif",
               "/toolbarButtonGraphics/text/Bold24.gif", null, true);

        action("font-italic", "Italic", "I", "Italicize current selection",
               "/toolbarButtonGraphics/text/Italic16.gif",
               "/toolbarButtonGraphics/text/Italic24.gif", null, true);

        action("font-underline", "Underline", "U", "Underline current selection",
               "/toolbarButtonGraphics/text/Underline16.gif",
               "/toolbarButtonGraphics/text/Underline24.gif", null, true);

        // These justification actions are part of a button group.
        action = action("left-justify", "Left Align", "L", "Left alignment",
                        "/toolbarButtonGraphics/text/AlignLeft16.gif",
                        "/toolbarButtonGraphics/text/AlignLeft24.gif", null, true);
        action.setGroup("paragraph-align");

        action = action("center-justify", "Center", "N", "Center alignment",
               "/toolbarButtonGraphics/text/AlignCenter16.gif",
               "/toolbarButtonGraphics/text/AlignCenter24.gif", null, true);
        action.setGroup("paragraph-align");

        action = action("right-justify", "Right Align", "R", "Right alignment",
               "/toolbarButtonGraphics/text/AlignRight16.gif",
               "/toolbarButtonGraphics/text/AlignRight24.gif", null, true);
        action.setGroup("paragraph-align");

    }

    /**
     * Convenience method to create actions with all the attributes. A factory
     * method for other factory methods.
     */
    private AbstractActionExt action(String id, String name, String mnemonic, String desc,
                          String smicon, String lgicon, String keystroke, boolean toggle) {
        AbstractActionExt action = ActionFactory.createTargetableAction(id,
                                                       name, mnemonic, toggle);

        ActionFactory.decorateAction(action, desc, desc,
                                     Application.getIcon(smicon, this),
                                     Application.getIcon(lgicon, this),
                                     KeyStroke.getKeyStroke(keystroke));

        ActionManager manager = Application.getInstance().getActionManager();
        return (AbstractActionExt)manager.addAction(action);
    }


    protected void initUI() {
        List list = new ArrayList();

        // Create toolbar
        list.add("font-bold");
        list.add("font-italic");
        list.add("font-underline");
        list.add(null);
        list.add("cut-to-clipboard");
        list.add("copy-to-clipboard");
        list.add("paste-from-clipboard");
        list.add(null);
        list.add("undo");
        list.add("redo");
        list.add(null);
        list.add("find");
        list.add("print");
        list.add(null);
        list.add("left-justify");
        list.add("center-justify");
        list.add("right-justify");

        // Use the factory to create the toolbar.
        ActionManager manager = Application.getInstance().getActionManager();
        JToolBar toolbar = manager.getFactory().createToolBar(list);

        // Build the menu bar. Menus are lists of lists of action ids.
        List file = new ArrayList();
        file.add("file-menu");
        file.add("new-command");
        file.add("open-command");

        List edit = new ArrayList();
        edit.add("edit-menu");
        edit.add("cut-to-clipboard");
        edit.add("copy-to-clipboard");
        edit.add("paste-from-clipboard");
        edit.add(null);
        edit.add("undo");
        edit.add("redo");

        List format = new ArrayList();
        format.add("format-menu");
        format.add("font-bold");
        format.add("font-italic");
        format.add("font-underline");
        format.add(null);
        format.add("left-justify");
        format.add("center-justify");
        format.add("right-justify");

        list = new ArrayList();
        list.add(file);
        list.add(edit);
        list.add(format);

        JMenuBar menu = manager.getFactory().createMenuBar(list);

        frame = new JXFrame("Editor Demo Application");

        JXEditorPane editor;
        try {
            editor = new JXEditorPane(EditorDemo.class.getResource("resources/jabberwock.html"));
        } catch (Exception ex) {
            editor = new JXEditorPane();
        }
        JXRootPane root = frame.getRootPaneExt();

        toolbar.add(editor.getParagraphSelector());

        root.addComponent(editor);
        root.setJMenuBar(menu);
        root.setToolBar(toolbar);
        root.setStatusBar(new JXStatusBar());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    EditorDemo demo = new EditorDemo();
                }
            });

    }

}
