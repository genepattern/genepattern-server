/*
 * $Id: TestDataModelFactory.java,v 1.1 2004/11/22 16:05:14 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import java.util.Locale;

/**
 * static factory creating DataModels for test cases.
 * 
 * @author Jeanette Winzenburg
 */
public class TestDataModelFactory {

    /** 
     * returns a one-field dataModel with a Validator.
     * 
     * @param valid the immutable return value of the Validator.
     * @return
     */
    public static DataModel createDataModelWithValidator(boolean valid) {
        DefaultDataModel model = new DefaultDataModel();
        model.addField(new MetaData("simpleton"));
        model.addValidator(createValidator(valid));
        return model;
    }

    /** 
     * returns a Validator with a fixed validation restult.
     *  
     * @param valid the fixed validation result.
     * @return
     */
    public static Validator createValidator(final boolean valid) {
        
        Validator v = new Validator() {

            public boolean validate(Object value, Locale locale, String[] error) {
                return valid;
            }
            
        };
        return v;
    }


}
