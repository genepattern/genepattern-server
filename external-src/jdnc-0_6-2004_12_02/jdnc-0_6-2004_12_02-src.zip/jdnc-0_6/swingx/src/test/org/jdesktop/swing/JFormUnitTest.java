/*
 * $Id: JFormUnitTest.java,v 1.4 2004/11/29 11:32:43 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing;

import java.awt.BorderLayout;
import java.util.Locale;

import javax.swing.*;

import junit.framework.TestCase;

import org.jdesktop.swing.binding.BindException;
import org.jdesktop.swing.binding.Binding;
import org.jdesktop.swing.data.*;
import org.jdesktop.swing.form.*;

/**
 * JUnit test class for JForm.
 * 
 * @author Amy Fowler
 * @author Jeanette Winzenburg
 */
public class JFormUnitTest extends TestCase {

    // public void testJFormConstructors
    // public void testJFormProperties
    // public void testJFormBinding

    public void testJFormCtor() {
        JForm form = new JForm();
        assertNotNull(form);
        assertNotNull(form.getFormFactory());
    }

    public void testFormFactoryCtor() {
        // Just instantiating the form factory should pick up
        // missing icons.
        FormFactory factory = new DefaultFormFactory();
    }

    /**
     * Issue 127: isFormValid() did throw ArrayIndexOutOfBounds
     * if dataModel has validators.
     *
     */
    public void testValidatorLoop() {
        DataModel dataModel = TestDataModelFactory
                .createDataModelWithValidator(false);
        try {
            JForm form = new JForm(dataModel);
            form.isFormValid();
        } catch (BindException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void testFormValiditySynchedOnFields() {
        assertFormValiditySynchedOnFields(false);
        assertFormValiditySynchedOnFields(true);

    }

    /**
     * assert that form detects invalid DataModel,
     * invalid by datamodel validator, invalid data set in model.
     *  
     */
    public void testFormInvalidOnInvalidModel() {
        JForm form = assertFormValiditySynchedOnFields(true);
        DataModel personModel = form.getBindings()[0].getDataModel();
        Validator marriedAgeValidator = createMarriedAgeValidator(personModel);
        personModel.addValidator(marriedAgeValidator);
        personModel.setValue("age", new Integer(10));
        assertFalse("form must be invalid", form.isFormValid());
    }

    protected JForm assertFormValiditySynchedOnFields(boolean valid) {
        DataModel personModel = DataModelUnitTest
                .createFilledPersonModel(valid);
        JForm form = createForm(personModel);
        assertEquals("form's validity ", valid, form.isFormValid());
        return form;
    }
    
    protected Validator createMarriedAgeValidator(DataModel personModel) {

        Validator v = new Validator() {

            public boolean validate(Object value, Locale locale, String[] error) {
                DataModel personModel = (DataModel) value;
                Boolean married = (Boolean) personModel.getValue("married");
                Integer age = (Integer) personModel.getValue("age");
                if (married.booleanValue()) {
                    return age.intValue() >= 16;
                }
                return true;
            }

        };
        return v;
    }

//----------------------- interactive tests
    public void interactiveJFormTest1() {
        DataModel personModel = DataModelUnitTest.createNestedPersonModel();

        JForm form = null;
        try {
            form = new JForm(personModel);

            JFrame frame = new JFrame("JFormUnitTest Interactive Test1");
            frame.getContentPane().add(BorderLayout.CENTER, form);

            JPanel buttonPanel = new JPanel();
            JButton button = new JButton(form.getActionMap().get("submit"));
            buttonPanel.add(button);
            frame.getContentPane().add(BorderLayout.SOUTH, buttonPanel);
            frame.pack();
            frame.setVisible(true);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * Shows a JavaBeanData model with all the types that the FormFactory will
     * support.
     */
    public void interactiveJFormTest2() {
        JForm form = null;
        try {
            form = new JForm(new JavaBeanDataModel(TestBean.class,
                    new TestBean()));
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex);
        }
        JFrame frame = new JFrame("JFormUnitTest Interactive Test2");
        frame.getContentPane().add(BorderLayout.CENTER, form);
        frame.pack();
        frame.setVisible(true);
    }

//--------------------- utility methods
    
    protected void setSpinnerValue(Binding binding, Integer value) {
        JComponent comp = binding.getComponent();
        if (comp instanceof JSpinner) {
            ((JSpinner) comp).setValue(value);
        }

    }

    protected Binding getBinding(JForm form, String fieldname) {
        Binding[] bindings = form.getBindings();
        for (int i = 0; i < bindings.length; i++) {
            if (fieldname.equals(bindings[i].getFieldName())) {
                return bindings[i];
            }
        }
        return null;
    }

    protected JForm createForm(DataModel personModel) {
        JForm form = new JForm();
        try {
            form.bind(personModel);
            form.pull();
        } catch (BindException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return form;
    }


    
    public static void main(String args[]) {
        JFormUnitTest test = new JFormUnitTest();

        test.interactiveJFormTest1();
        test.interactiveJFormTest2();
    }

}