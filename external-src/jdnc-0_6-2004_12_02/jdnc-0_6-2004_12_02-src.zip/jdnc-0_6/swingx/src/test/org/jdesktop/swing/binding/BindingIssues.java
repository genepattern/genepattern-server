/*
 * $Id: BindingIssues.java,v 1.1 2004/11/23 13:49:14 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.binding;

import javax.swing.JCheckBox;

import org.jdesktop.swing.data.DefaultDataModel;
import org.jdesktop.swing.data.MetaData;

import junit.framework.TestCase;

/**
 * Open binding issues exposed as TestCase. <p>
 * 
 * NOTE: this test is expected to fail. Will be 
 * integrated into BindingUnitTest on resolution.
 * 
 * @author Jeanette Winzenburg
 */
public class BindingIssues extends TestCase {
    /** 
     * Issue #115 - BooleanBinding cannot cope with boolean.class. <p>
     * Don't allow primitiv type? DataModel can handle Object only
     * anyway..
     *
     */
    public void testBooleanBindingIsValid() {
        DefaultDataModel model = new DefaultDataModel();
        MetaData booleanMetaData = new MetaData("married", boolean.class);
        model.addField(booleanMetaData);
        JCheckBox checkbox = new JCheckBox(booleanMetaData.getLabel());
        BooleanBinding binding = new BooleanBinding(checkbox, model,
                                   "married");
        binding.pull();
        assertTrue("boolean binding must always be valid ", binding.isValid());
        
      }
    

}
