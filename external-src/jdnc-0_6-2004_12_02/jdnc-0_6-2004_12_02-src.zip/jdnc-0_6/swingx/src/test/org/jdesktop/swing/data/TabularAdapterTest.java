/*
 * $Id: TabularAdapterTest.java,v 1.1 2004/11/29 16:14:43 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import junit.framework.TestCase;

import org.jdesktop.swing.util.*;

/**
 * @author Jeanette Winzenburg
 */
public class TabularAdapterTest extends TestCase {
    //  private static final String PREFIX = "resources/";
    private static final String PREFIX = "/org/jdesktop/swing/resources/";

    private static final String STRINGDATA = PREFIX + "stringdata.csv";

    private URL stringDataURL;
    private PropertyChangeReport propertyReport;
    private ValueChangeReport valueReport;

    //---------------------- TabularDataModel
    
    /**
     * Issue #86: adapter could not cope with rowIndex == -1.
     */
    public void testTabularAdapterEmptySelection() {
        TabularDataModelAdapter adapter = new TabularDataModelAdapter(
                createTabularDataModel());
        assertEquals("recordIndex on start", -1, adapter.getRecordIndex());
        String[] fields = adapter.getFieldNames();
        assertNull("value must be null if empty current", adapter
                .getValue(fields[0]));
        adapter.setValue(fields[0], "nothing");
    }

    public void testTabularAdapterFireValueChangeOnIndexChange() {
        TabularDataModel data = loadTabularData(stringDataURL);
        assertEquals("row count", 10, data.getRowCount());
        TabularDataModelAdapter adapter = new TabularDataModelAdapter(data);
        assertNotification(data, adapter);
    }

//    public void testIllegalFieldName() {
//        TabularDataModel data = loadTabularData(stringDataURL);
//        TabularDataModelAdapter adapter = new TabularDataModelAdapter(data);
//        try {
//            adapter.getValue("fantasy");
//            fail("adapter must throw exception on unknown fieldname");
//        } catch (Exception ex){
//            // we are fine
//        }
//    }
    //---------------------- helper

    private void assertNotification(TabularDataModel data, DataModel adapter) {
        MetaData[] metaData = data.getMetaData();
        List columns = new ArrayList();
        for (int i = 0; i < metaData.length; i++) {
            columns.add(metaData[i].getName());
        }
        adapter.addValueChangeListener(valueReport);
        assertNullValues(adapter);
        adapter.setRecordIndex(0);
        assertValueChangeFired(columns);
        valueReport.clear();
        adapter.setRecordIndex(-1);
        assertNullValues(adapter);
        assertValueChangeFired(columns);
        adapter.setRecordIndex(0);
        valueReport.clear();
        data.setValueAt("newcell", 0, 0);
        assertTrue("must have fired", valueReport.gotEvent(columns.get(0)));
        assertEquals(adapter.getValue((String) columns.get(0)), data
                .getValueAt(0, 0));
        valueReport.clear();
        adapter.setValue((String) columns.get(0), "othervalue");
        assertTrue("must have fired valueChange", valueReport.gotEvent(columns
                .get(0)));
        assertEquals(adapter.getValue((String) columns.get(0)), data
                .getValueAt(0, 0));
    }

    private void assertValueChangeFired(List columns) {
        for (Iterator iter = columns.iterator(); iter.hasNext();) {
            String element = (String) iter.next();
            assertTrue("must have fired value change for " + element,
                    valueReport.gotEvent(element));
        }
    }

    private void assertNullValues(DataModel data) {
        String[] fieldNames = data.getFieldNames();
        for (int i = 0; i < fieldNames.length; i++) {
            assertNull("value must be null", data.getValue(fieldNames[i]));
        }

    }

    private TabularDataModel createTabularDataModel() {
        TabularDataModel tabularData = new TabularDataModel(1);
        tabularData.setColumnMetaData(0, new MetaData("something"));
        tabularData.addRow(new Object[] { "content" });
        return tabularData;
    }

    private TabularDataModel loadTabularData(URL dataURL) {
        TabularDataModel data = new TabularDataModel(dataURL);
        data.getColumnCount();
        TabularDataTextLoader loader = (TabularDataTextLoader) data.getLoader();
        loader.setColumnDelimiter(",");
        loader.setFirstRowHeader(true);
        try {
            data.startLoading();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        int row = 0;
        while (data.isLoading()) {
            //      System.out.println(row++);
        }
        return data;
    }

    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty(DataLoader.READER_PRIORITY_KEY, String
                .valueOf(Thread.NORM_PRIORITY));
        stringDataURL = getClass().getResource(STRINGDATA);
        valueReport = new ValueChangeReport();
        propertyReport = new PropertyChangeReport();
    }

    protected void tearDown() throws Exception {
        System.getProperties().remove(DataLoader.READER_PRIORITY_KEY);
        super.tearDown();
    }
}