/*
 * $Id: TabularDataModelIssues.java,v 1.1 2004/11/29 16:45:45 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import junit.framework.TestCase;

/**
 * JUnit test class for exposing open issues with 
 * tabular data model.
 *
 * @author Jeanette Winzenburg
 */
public class TabularDataModelIssues extends TestCase {

    /**
     * Issue #90: TabularDataModel must not introduce 
     * precondition to setValueAt(..) 
     *
     */
    public void testSetValueContract() {
        TabularDataModel model = new TabularDataModel(1);
        MetaData metaData = new MetaData("one");
        metaData.setReadOnly(true);
        model.setColumnMetaData(0, metaData);
        model.addRow(new Object[] {"non-editable value"});
        assertFalse("cell must be uneditable", model.isCellEditable(0, 0));
        try {
            model.setValueAt("changed", 0, 0);
        } catch (RuntimeException ex) {
            fail("must not introduce precondition");
        }
    }
}
