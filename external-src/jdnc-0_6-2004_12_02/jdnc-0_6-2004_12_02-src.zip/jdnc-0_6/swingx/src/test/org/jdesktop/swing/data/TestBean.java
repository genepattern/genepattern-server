/*
 * $Id: TestBean.java,v 1.1 2004/08/05 01:29:19 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import java.awt.Image;

import java.awt.image.BufferedImage;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * A bean for testing.
 */
public class TestBean {

    private String sValue = "A String";
	
    // Primitives
    private int iValue = 17;
    private float fValue = 0.17f;
    private boolean bValue = false;
    
    // More complex types
    private Date date = new Date();
    private Image image;
    private String[] array = { "Monday", "Tuesday", "Wednesday", "Thursday",
			       "Friday", "Saturday", "Sunday" };

    private List list;
    private Map map;

    // JDNC data types
    private Link link;
    
    public TestBean() {

	// Populate the more complex types.
	list = new ArrayList();
	map = new HashMap();
	for (int i = 0; i < array.length; i++) {
	    list.add(array[i]);
	    map.put(new Integer(i), array[i]);
	}

	URL testURL;
	try {
	    testURL = new URL("http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4488581");
	} catch (MalformedURLException ex) {
	    throw new RuntimeException(ex);
	}

	link = new Link("4488581", "_blank", testURL);
    }
    
    public void setString(String s) { sValue = s; }
    public String getString() { return sValue; }
    
    public void setInteger(int i) { iValue = i; }
    public int getInteger() { return iValue; }
    
    public void setFloat(float f) { fValue = f; }
    public float getFloat() { return fValue; }

    public void setBoolean(boolean b) { bValue = b; }
    public boolean getBoolean() { return bValue; }
    
    public void setDate(Date d) { date = d; }
    public Date getDate() { return date; }
    
    public void setImage(Image i) { image = i; }
    public Image getImage() { return image; }

    public String[] getArray() { return array; }
    public void setArray(String[] array) { this.array = array; }

    public List getList() { return list; }
    public void setList(List list) { this.list = list; }

    public Map getMap() { return map; }
    public void setMap(Map map) { this.map = map; }

    public Link getLink() { return link; }
    public void setLink(Link link) { this.link = link; }
}
