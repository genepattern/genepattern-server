/*
 * $Id: ConvertersUnitTest.java,v 1.1 2004/08/05 01:29:18 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import java.awt.Point;

import java.net.MalformedURLException;
import java.net.URL;

import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test class for data coverters.
 *
 * @author Mark Davidson
 * @author Amy Fowler
 */
public class ConvertersUnitTest extends TestCase {

    /**
     * Simple test to ensure that the correct type converter has been 
     * returned per type.
     */
    public void testgetConverter() {
        // Add supported type/converter mappings here for testing.
	Class[] data = {
	    String.class, Date.class, Long.class, Short.class,   
            Float.class, Integer.class, Boolean.class, Float.class,
            Link.class
        };

        for (int i = 0; i < data.length; i++) {
            assertNotNull(Converters.get(data[i]));
        }

	// These type converters are not supported
	assertNull(Converters.get(Byte.class));
	assertNull(Converters.get(Character.class));
    }

    /**
     * Test to ensure that all supported types are returned.
     */
    public void testGetTypes() {
	Class[] types = Converters.getTypes();
	assertNotNull(types);
	assertTrue(types.length != 0);

	for (int i = 0; i < types.length; i++) {
            assertNotNull(Converters.get(types[i]));
	}
    }

    // Type converter tests here.

    public void testStringConverter() {
        testConverter("Hello");
        testConverter("");

        testConverterFailure(new Integer(10), String.class);
        testConverterFailure((Object)null, String.class);
    }

    public void testIntegerConverter() {
        testConverter(new Integer(47));
        testConverter(new Integer( -10));
        testConverter(new Integer(0));
        testConverter(new Integer(256), new Integer(16)/*radix*/);

        testConverter("1000", Integer.class, new Integer(1000));
        testConverter("-22", Integer.class, new Integer(-22));
        testConverter("0", Integer.class, new Integer(0));
        testConverter("ffffff", Integer.class, new Integer(16777215),
                      new Integer(16)/*radix*/);

        testConverterFailure(new StringBuffer(), Integer.class);
        testConverterFailure("hello there", Integer.class);
        testConverterFailure((Object)null, Integer.class);
        testConverterFailure("", Integer.class);
    }

    public void testBooleanConverter() {
        testConverter(Boolean.TRUE);
        testConverter(Boolean.FALSE);

        testConverter("true", Boolean.class, Boolean.TRUE);
        testConverter("TRUE", Boolean.class, Boolean.TRUE);
        testConverter("True", Boolean.class, Boolean.TRUE);
        testConverter("false", Boolean.class, Boolean.FALSE);
        testConverter("FALSE", Boolean.class, Boolean.FALSE);
        testConverter("False", Boolean.class, Boolean.FALSE);

        testConverterFailure(new Integer(10), Boolean.class);
        testConverterFailure((Object)null, Boolean.class);

    }

    public void testShortConverter() {
        testConverter(new Short((short)55));
        testConverter(new Short((short)-1));
        testConverter(new Short((short)0));

        testConverter("256", Short.class, new Short((short)256));
        testConverter("0", Short.class, new Short((short)0));
        testConverter("-10", Short.class, new Short((short)-10));

        testConverterFailure(new Integer(99), Short.class);
        testConverterFailure("hi", Short.class);
        testConverterFailure((Object)null, Short.class);
        testConverterFailure("", Short.class);
    }

    public void testLongConverter() {
        testConverter(new Long(Long.MAX_VALUE));
        testConverter(new Long(Long.MIN_VALUE));
        testConverter(new Long(0));
        testConverter(new Long(8939), new Integer(16)/*radix*/);

        testConverter("285678883", Long.class, new Long(285678883));
        testConverter("0", Long.class, new Long(0));
        testConverter("-138950399", Long.class, new Long(-138950399));
        testConverter("ABCDEF", Long.class, new Long(11259375),
                      new Integer(16)/*radix*/);

        testConverterFailure(new Integer(33), Long.class);
        testConverterFailure("hi", Long.class);
        testConverterFailure((Object)null, Long.class);
        testConverterFailure("", Long.class);
    }

    public void testFloatConverter() {
        testConverter(new Float(48.2));
        testConverter(new Float( -0000.0001));
        testConverter(new Float(1.00002f));
        testConverter(new Float(1.00002d));

        testConverter("33.2", Float.class, new Float(33.2));
        testConverter("-999.99", Float.class, new Float(-999.99));
        testConverter("1.1001f", Float.class, new Float(1.1001f));
        testConverter("-1.0E-4", Float.class, new Float(-1.0E-4));

        testConverterFailure(new Integer(33), Float.class);
        testConverterFailure("hi", Float.class);
        testConverterFailure( (Object)null, Float.class);
        testConverterFailure("", Float.class);
    }

    public void testDoubleConverter() {
        testConverter(new Double(Double.NaN));
        testConverter(new Double(Double.NEGATIVE_INFINITY));
        testConverter(new Double(Double.POSITIVE_INFINITY));
        testConverter(new Double(Double.MAX_VALUE));

        testConverterFailure(new Integer(33), Double.class);
        testConverterFailure("hi", Double.class);
        testConverterFailure( (Object)null, Double.class);
        testConverterFailure("", Double.class);
    }

    public void testDateConverter() {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(1965, 8, 30, 12, 1, 1);

        testConverter(calendar.getTime());
        testConverter(new Date(0), new SimpleDateFormat("MMM dd yyyy HH:mm"));

        testConverter("30 Sep 65 12:01:01", Date.class,
                      calendar.getTime(),
                      new SimpleDateFormat("dd MMM yy HH:mm:ss"));

        testConverterFailure(new Integer(38), Date.class);
        testConverterFailure("my birthday", Date.class);
        testConverterFailure("September 30, 1965", Date.class, new SimpleDateFormat("mmm dd yy"));

    }

    public void testLinkConverter() {
        try {
            testConverter(new Link("foo", "_blank",
                                             new URL("http://foo.sun.com")));
            testConverter(new Link("foo", "_blank",
                                             new URL("http://foo.sun.com")));
            testConverter(new Link("bar", "new_frame",
                                             new URL("http://bar.sun.com")));
            testConverter(new Link("bar", "new_frame",
                                             new URL("http://bar.sun.com")));
        }
        catch (MalformedURLException ex) {
            throw new RuntimeException("Error constructing URL: ", ex);
        }

        testConverter(new Link("bar", "new_frame",
                               "http://bugz?cat=@{1}&subcat=@{2}",
                               new String[] {"java", "classes_beans"}));
        testConverter(new Link("bar", null /* no target */,
                               "http://bugz?cat=@{1}&subcat=@{2}",
                               new String[] {"java", "classes_beans"}));
        testConverter(new Link(null, null, "http://bugz?cat=@{1}&subcat=@{2}",
                               new String[] {"java", "classes_beans"}));
        testConverter(new Link(null, null, "http://bugz?cat=@{1}&subcat=@{2}",
                               new String[] {"java", "classes_beans"}));

        // Test converting from raw strings to objects and back
        Converter converter = Converters.get(Link.class);

        try {
            String linkString =
                "<a href=\"http://java.sun.com\" target=\"frame1\">java.sun.com</a>";
            Link link = (Link) converter.decode(linkString, null);
            assertEquals(link.getURL().toExternalForm(), "http://java.sun.com");
            assertEquals(link.getText(), "java.sun.com");
            assertEquals(link.getTarget(), "frame1");

            linkString = "<a href=\"http://java.sun.com\">java.sun.com</a>";
            link = (Link) converter.decode(linkString, null);
            assertEquals(link.getURL().toExternalForm(), "http://java.sun.com");
            assertEquals(link.getText(), "java.sun.com");

            linkString = "<a href=\"http://java.sun.com\"></a>";
            link = (Link) converter.decode(linkString, null);
            assertEquals(link.getURL().toExternalForm(), "http://java.sun.com");
            assertEquals(link.getText(), "");

        } catch (ConversionException e) {
            throw new RuntimeException("Error converting string to link", e);
        }

        testConverterFailure(new Integer(1), Link.class);
        testConverterFailure((Object)null, Link.class);
        testConverterFailure("http:\\java.sun.com", Link.class);
    }

    public void testPutConverter() {

        Converter newPointConverter = new Converter() {
            public Object decode(String value, Object format)
                throws ConversionException {
                return null;
            }
            public String encode(Object value, Object format)
                throws ConversionException {
                return null;
            }
        };

        Converter pointConverter = Converters.get(Point.class);
        assertNull(pointConverter);

        Converters.put(Point.class, newPointConverter);
        pointConverter = Converters.get(Point.class);
        assertEquals(pointConverter, newPointConverter);

    }

    public void testConverter(Object objectValue) {
        testConverter(objectValue, null);
    }

    public void testConverter(Object objectValue, Object format) {
        testConverter(objectValue, objectValue.getClass(), format);
    }

    public void testConverter(Object objectValue, Class klass, Object format) {
        Converter converter = Converters.get(klass);
        String outString = null;
        try {
            outString = converter.encode(objectValue, format);
            //System.out.println("testConverter "+klass.getName()+ " string="+outString);
            Object newObject = converter.decode(outString, format);
            assertEquals(objectValue, newObject);
        }
        catch (ConversionException ex) {
            throw new RuntimeException("Error converting to Object: " +
                                       outString, ex);
        }
    }

    public void testConverter(String stringValue, Class klass, Object expected) {
        testConverter(stringValue, klass, expected, null);
    }

    public void testConverter(String stringValue, Class klass, Object expected, Object format) {
        Converter converter = Converters.get(klass);
        Object newValue = null;
        try {
            newValue = converter.decode(stringValue, format);
            assertEquals(expected, newValue);
        }
        catch (ConversionException ex) {
            throw new RuntimeException("Error converting to " + klass.getName() +
                                       " Object: " + stringValue, ex);
        }
    }

    public void testConverterFailure(Object objectValue, Class klass) {
        testConverterFailure(objectValue, klass, null);
    }

    public void testConverterFailure(Object objectValue, Class klass, Object format) {
        Converter converter = Converters.get(klass);
        try {
            String outString = converter.encode(objectValue, format);
            fail("converter for " + klass.getName() + " should not convert "+
                 (objectValue != null? objectValue.getClass().getName() : "null") +
                 " instance");
        } catch (ConversionException e) {
            // success!
        }
    }

    public void testConverterFailure(String stringValue, Class klass) {
        testConverterFailure(stringValue, klass, null);
    }

    public void testConverterFailure(String stringValue, Class klass, Object format) {
        Converter converter = Converters.get(klass);
        try {
            Object value = converter.decode(stringValue, format);
            fail("converter for " + klass.getName() + " should not convert string \""+
                 stringValue + "\"");
        } catch (ConversionException e) {
            // success!
        }
    }

}
