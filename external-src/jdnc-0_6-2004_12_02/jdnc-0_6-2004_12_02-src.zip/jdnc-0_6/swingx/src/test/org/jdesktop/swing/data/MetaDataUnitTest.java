/*
 * $Id: MetaDataUnitTest.java,v 1.5 2004/09/10 21:54:48 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import java.awt.Color;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Locale;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jdesktop.swing.util.TestSupport;

/**
 * JUnit test class for meta data
 *
 * @author Amy Fowler
 */
public class MetaDataUnitTest extends TestCase {

    public static void verifyMetaDataProperties(MetaData metaData,
                                          String name, Class klass,
                                          String label,
                                          int minValueCount, int maxValueCount,
                                          boolean readonly,
                                          Converter converter,
                                          Object decodeFormat, Object encodeFormat) {

        assertEquals(klass, metaData.getElementClass());
        assertEquals(name, metaData.getName());
        assertEquals(label, metaData.getLabel());
        assertEquals(minValueCount, metaData.getMinValueCount());
        assertEquals(maxValueCount, metaData.getMaxValueCount());
        assertEquals(readonly, metaData.isReadOnly());
        assertEquals(converter, metaData.getConverter());
        assertEquals(decodeFormat, metaData.getDecodeFormat());
        assertEquals(encodeFormat, metaData.getEncodeFormat());
    }

    public static void verifyStringMetaDataProperties(StringMetaData metaData,
                                                int minLength, int maxLength,
                                                boolean multiLine) {

        assertEquals(minLength, metaData.getMinLength());
        assertEquals(maxLength, metaData.getMaxLength());
        assertEquals(multiLine, metaData.isMultiLine());
    }

    public static void verifyNumberMetaDataProperties(NumberMetaData metaData,
                                                Number theMinimum, Number theMaximum,
                                                boolean theCurrency) {
        Number minimum = metaData.getMinimum();
        Number maximum = metaData.getMaximum();
        boolean currency = metaData.isCurrency();

        assertEquals(theMinimum, minimum);
        assertEquals(theMaximum, maximum);
        assertEquals(theCurrency, currency);
    }

    public static void verifyEnumeratedMetaDataProperties(EnumeratedMetaData metaData,
                                                    Object[] theEnumeration) {
        Object enumeration[] = metaData.getEnumeration();
        assertEquals(theEnumeration.length, enumeration.length);

        for(int i = 0; i < enumeration.length; i++) {
            assertEquals(theEnumeration[i], enumeration[i]);
        }

    }

    private static void verifyNumberValidation(NumberMetaData metaData,
                                        Number min, Number mid, Number max,
                                        Number tooSmall, Number tooBig) {

         Validator validators[] = metaData.getValidators();
         String error[] = new String[1];
         for(int i = 0; i < validators.length; i++) {
             // these should pass
             boolean valid = validators[i].validate(min, null, error);
             assertTrue(valid);
             valid = validators[i].validate(mid, null, error);
             assertTrue(valid);
             valid = validators[i].validate(max, null, error);
             assertTrue(valid);

             // these should fail
             valid = validators[i].validate(tooSmall, null, error);
             assertFalse(valid);
             valid = validators[i].validate(tooBig, null, error);
             assertFalse(valid);
         }
    }

    public void testMetaDataConstructors() {

        MetaData metaData = new MetaData();
        verifyMetaDataProperties(metaData, "value", String.class,
                                 "value", 0, 1, false,
                                 Converters.get(String.class), null, null);

        metaData = new MetaData("firstname");
        verifyMetaDataProperties(metaData, "firstname", String.class,
                                 "firstname", 0, 1, false,
                                 Converters.get(String.class), null, null);

        metaData = new MetaData("zipcode", Integer.class);
        verifyMetaDataProperties(metaData, "zipcode", Integer.class,
                                 "zipcode", 0, 1, false,
                                 Converters.get(Integer.class), null, null);
        metaData.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent e) {

            }
        });


        metaData = new MetaData("phonenumber", String.class, "Phone Number");
        verifyMetaDataProperties(metaData, "phonenumber", String.class, "Phone Number",
                                 0, 1, false,
                                 Converters.get(String.class), null, null);

        Validator validators[] = metaData.getValidators();
        assertEquals(0, validators.length);

    }

    public void testMetaDataProperties() {
        MetaData metaData = new MetaData("zipcode");
        metaData.setElementClass(Integer.class);
        metaData.setName("zip-code");
        metaData.setLabel("Zipcode");
        metaData.setMinValueCount(1);
        metaData.setMaxValueCount(2);
        metaData.setReadOnly(true);
        Converter dummy = new DummyConverter();
        metaData.setConverter(dummy);
        DateFormat format = new SimpleDateFormat();
        metaData.setDecodeFormat(format);
        metaData.setEncodeFormat(format);
        verifyMetaDataProperties(metaData, "zip-code", Integer.class, "Zipcode",
                                 1, 2, true,
                                 dummy, format, format);

        metaData.setRequired(false);
        assertEquals(0, metaData.getMinValueCount());

        metaData.setRequired(true);
        assertEquals(1, metaData.getMinValueCount());

    }

    public void testMetaDataValidator() {
        MetaData metaData = new MetaData("lastname");

        Validator dummyV = new DummyValidator();
        metaData.addValidator(dummyV);
        Validator validators[] = metaData.getValidators();
        assertEquals(validators[0], dummyV);

        metaData.removeValidator(dummyV);
        validators = metaData.getValidators();
        assertEquals(0, validators.length);

    }

    public void testStringMetaDataConstructors() {
        StringMetaData metaData = new StringMetaData();
        verifyMetaDataProperties(metaData, "stringvalue", String.class,
                                 "stringvalue", 0, 1, false,
                                 Converters.get(String.class), null, null);
        verifyStringMetaDataProperties(metaData, 0, Integer.MAX_VALUE, false);

        metaData = new StringMetaData("lastname");
        verifyMetaDataProperties(metaData, "lastname", String.class,
                                 "lastname", 0, 1, false,
                                 Converters.get(String.class), null, null);
        verifyStringMetaDataProperties(metaData, 0, Integer.MAX_VALUE, false);

        metaData = new StringMetaData("firstname", "First Name");
        verifyMetaDataProperties(metaData, "firstname", String.class,
                                 "First Name", 0, 1, false,
                                 Converters.get(String.class), null, null);
        verifyStringMetaDataProperties(metaData, 0, Integer.MAX_VALUE, false);

    }

    public void testStringMetaDataProperties() {
        StringMetaData metaData = new StringMetaData();
        metaData.setName("comments");
        metaData.setDisplayWidth(18);
        metaData.setMinLength(1);
        metaData.setMaxLength(100);
        metaData.setMultiLine(true);
        verifyStringMetaDataProperties(metaData, 1, 100, true);
        assertEquals(18, metaData.getDisplayWidth());
    }

    public void testNumberMetaDataConstructors() {
        NumberMetaData metaData = new NumberMetaData();
        verifyMetaDataProperties(metaData, "numbervalue", Integer.class,
                                 "numbervalue", 0, 1, false,
                                 Converters.get(Integer.class), null, null);

        metaData = new NumberMetaData("age");
        verifyMetaDataProperties(metaData, "age", Integer.class,
                                 "age", 0, 1, false,
                                 Converters.get(Integer.class), null, null);
        verifyNumberMetaDataProperties(metaData, null, null, false);

        metaData = new NumberMetaData("interestrate", Float.class);
        verifyMetaDataProperties(metaData, "interestrate", Float.class,
                                 "interestrate", 0, 1, false,
                                 Converters.get(Float.class), null, null);
        verifyNumberMetaDataProperties(metaData, null, null, false);

        metaData = new NumberMetaData("partnumber", Long.class, "Part Number");
        verifyMetaDataProperties(metaData, "partnumber", Long.class, "Part Number",
                                 0, 1, false,
                                 Converters.get(Long.class), null, null);

        Validator validators[] = metaData.getValidators();
        assertEquals(0, validators.length);

    }

    public void testNumberMetaDataProperties() {
        NumberMetaData metaData = new NumberMetaData("price");
        metaData.setElementClass(Float.class);
        metaData.setMinimum(new Float(0.99));
        metaData.setMaximum(new Float(99.99));
        metaData.setCurrency(true);
        verifyNumberMetaDataProperties(metaData, new Float(0.99), new Float(99.99),
                                       true);

        Validator validators[] = metaData.getValidators();
        assertEquals(1, validators.length);
    }

    public void testNumberMetaDataValidation() {
        NumberMetaData metaData = new NumberMetaData("quantity");
        metaData.setMinimum(new Integer(0));
        metaData.setMaximum(new Integer(10));
        verifyNumberValidation(metaData, new Integer(0), new Integer(3),
                               new Integer(10), new Integer(-1),
                               new Integer(20));

        metaData = new NumberMetaData("age", Short.class);
        metaData.setMinimum(new Short((short)18));
        metaData.setMaximum(new Short((short)120));
        verifyNumberValidation(metaData, new Short((short)18), new Short((short)39),
                               new Short((short)120), new Short((short)5),
                               new Short((short)220));

        metaData = new NumberMetaData("count", Long.class);
        metaData.setMinimum(new Long(100));
        metaData.setMaximum(new Long(1000000));
        verifyNumberValidation(metaData, new Long(100), new Long(111111),
                               new Long(1000000), new Long(10),
                               new Long(1000001));

        metaData = new NumberMetaData("price", Float.class);
        metaData.setMinimum(new Float(1.00));
        metaData.setMaximum(new Float(100.00));
        metaData.setCurrency(true);
        verifyNumberValidation(metaData, new Float(1.00), new Float(33.3),
                               new Float(100.00), new Float(-1.1), new Float(101.1));

        metaData = new NumberMetaData("molecules", Double.class);
        metaData.setMinimum(new Double(0.0));
        metaData.setMaximum(new Double(839329392339.234));
        verifyNumberValidation(metaData, new Double(0.0), new Double(3333333.3),
                               new Double(839329392339.234), new Double(-323.34),
                               new Double(99393999939393.32));
    }

    public void testEnumeratedMetaDataConstructors() {
        EnumeratedMetaData metaData = new EnumeratedMetaData();
        verifyMetaDataProperties(metaData, "enumvalue", String.class,
                                         "enumvalue", 0, 1, false,
                                         Converters.get(String.class), null, null);

        metaData = new EnumeratedMetaData("months");
        verifyMetaDataProperties(metaData, "months", String.class,
                                 "months",0, 1, false,
                                 Converters.get(String.class), null, null);
        verifyEnumeratedMetaDataProperties(metaData, new Object[0]);

        metaData = new EnumeratedMetaData("background", Color.class);
        verifyMetaDataProperties(metaData, "background", Color.class,
                                 "background", 0, 1, false,
                                 null, null, null);
        verifyEnumeratedMetaDataProperties(metaData, new Object[0]);

        metaData = new EnumeratedMetaData("month", String.class, "Month");
        verifyMetaDataProperties(metaData, "month", String.class, "Month",
                                 0, 1, false,
                                 Converters.get(String.class), null, null);
        verifyEnumeratedMetaDataProperties(metaData, new Object[0]);

        Validator validators[] = metaData.getValidators();
        assertEquals(0, validators.length);

    }

    public void testEnumeratedMetaDataProperties() {
        String days[] = {"sunday", "monday", "tuesday", "wednesday",
                       "thursday", "friday", "saturday"};
        EnumeratedMetaData metaData = new EnumeratedMetaData("daysofweek");
        metaData.setEnumeration(days);
        verifyEnumeratedMetaDataProperties(metaData, days);

        ArrayList list = new ArrayList();
        for(int i=1; i < 6; i++) {
            list.add(new String(""+i));
        }
        String listcopy[] = (String[])list.toArray(new String[1]);
        metaData = new EnumeratedMetaData("priority");
        metaData.setEnumeration(list);
        verifyEnumeratedMetaDataProperties(metaData, listcopy);
    }

    public void testMetaDataCustomProperties() {
        MetaData metaData = new MetaData("favoredcustomer");

        String keys[] = metaData.getCustomPropertyKeys();
        assertEquals(0, keys.length);

        // test adding
        metaData.setCustomProperty("hidden", Boolean.TRUE);
        assertEquals(Boolean.TRUE, metaData.getCustomProperty("hidden"));
        assertEquals(1, metaData.getCustomPropertyKeys().length);

        assertNull(metaData.getCustomProperty("missing"));
        assertEquals(Boolean.TRUE, metaData.getCustomProperty("missing", Boolean.TRUE));

        // test property change events on custom properties
        TestSupport.PropertyChangeTracker tracker =
            new TestSupport.PropertyChangeTracker();
        metaData.addPropertyChangeListener(tracker);

        metaData.setCustomProperty("hidden", Boolean.FALSE);
        assertTrue(tracker.gotPropertyChangeEvent("hidden"));
        assertEquals(Boolean.FALSE, tracker.getNewPropertyValue("hidden"));

        // test removal
        metaData.removeCustomProperty("hidden");
        assertNull(metaData.getCustomProperty("hidden"));
    }

    public void testMetaDataPropertyChangeEvents() {
        MetaData metaData = new MetaData("favcolor");

        TestSupport.PropertyChangeTracker tracker =
            new TestSupport.PropertyChangeTracker();
        metaData.addPropertyChangeListener(tracker);

        metaData.setElementClass(Color.class);
        assertTrue(tracker.gotPropertyChangeEvent("elementClass"));
        assertEquals(Color.class, tracker.getNewPropertyValue("elementClass"));

        metaData.setName("favoriteColor");
        assertTrue(tracker.gotPropertyChangeEvent("name"));
        assertEquals("favoriteColor", tracker.getNewPropertyValue("name"));

        metaData.setLabel("Favorite Color");
        assertTrue(tracker.gotPropertyChangeEvent("label"));
        assertEquals("Favorite Color", tracker.getNewPropertyValue("label"));

        metaData.setDisplayWidth(16);
        assertTrue(tracker.gotPropertyChangeEvent("displayWidth"));
        assertEquals(16, ((Integer)tracker.getNewPropertyValue("displayWidth")).intValue());

        metaData.setMinValueCount(1);
        assertTrue(tracker.gotPropertyChangeEvent("minValueCount"));
        assertEquals(new Integer(1), tracker.getNewPropertyValue("minValueCount"));

        metaData.setMaxValueCount(5);
        assertTrue(tracker.gotPropertyChangeEvent("maxValueCount"));
        assertEquals(new Integer(5), tracker.getNewPropertyValue("maxValueCount"));

        metaData.setReadOnly(true);
        assertTrue(tracker.gotPropertyChangeEvent("readOnly"));
        assertEquals(Boolean.TRUE, tracker.getNewPropertyValue("readOnly"));

        Converter dummy = new DummyConverter();
        metaData.setConverter(dummy);
        assertTrue(tracker.gotPropertyChangeEvent("converter"));
        assertEquals(dummy, tracker.getNewPropertyValue("converter"));

        DateFormat format = new SimpleDateFormat();
        metaData.setDecodeFormat(format);
        assertTrue(tracker.gotPropertyChangeEvent("decodeFormat"));
        assertEquals(format, tracker.getNewPropertyValue("decodeFormat"));

        metaData.setEncodeFormat(format);
        assertTrue(tracker.gotPropertyChangeEvent("encodeFormat"));
        assertEquals(format, tracker.getNewPropertyValue("encodeFormat"));

        metaData.setCustomProperty("silly", "hahaha");
        assertTrue(tracker.gotPropertyChangeEvent("silly"));
        assertNull(tracker.getOldPropertyValue("silly"));
        assertEquals("hahaha", tracker.getNewPropertyValue("silly"));
        tracker.clear();
        metaData.setCustomProperty("silly", "heeheehee");
        assertTrue(tracker.gotPropertyChangeEvent("silly"));
        assertEquals("hahaha", tracker.getOldPropertyValue("silly"));
        assertEquals("heeheehee", tracker.getNewPropertyValue("silly"));
        tracker.clear();
        metaData.removeCustomProperty("silly");
        assertTrue(tracker.gotPropertyChangeEvent("silly"));
        assertNull(tracker.getNewPropertyValue("silly"));
        assertEquals("heeheehee", tracker.getOldPropertyValue("silly"));

    }

    public class DummyConverter implements Converter {
        public Object decode(String value, Object format)
            throws ConversionException {
            return null;
        }
        public String encode(Object value, Object format)
            throws ConversionException {
            return null;
        }
    }

    public class DummyValidator implements Validator {
        public boolean validate(Object value, Locale locale, String[] error) {
            return false;
        }
    }

    public static void main(String args[]) {
        MetaDataUnitTest test = new MetaDataUnitTest();
        try {
            test.setUp();
        } catch (Exception e) {

        }
        test.testEnumeratedMetaDataConstructors();
        test.testEnumeratedMetaDataProperties();
        test.testMetaDataConstructors();
        test.testMetaDataProperties();
        test.testMetaDataValidator();
        test.testNumberMetaDataConstructors();
        test.testNumberMetaDataProperties();
        test.testNumberMetaDataValidation();
        test.testStringMetaDataConstructors();
        test.testStringMetaDataProperties();
        test.testMetaDataCustomProperties();
        test.testMetaDataPropertyChangeEvents();

    }
}
