/*
 * $Id: DataModelUnitTest.java,v 1.3 2004/11/29 11:32:43 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test class for data model interface and implementing classes.
 * 
 * JW: Hmmm .. static methods for DefaultDataModels used across test cases.
 * Would like to move into TestDataModelFactory .. 
 *   
 * @author Amy Fowler
 */
public class DataModelUnitTest extends TestCase {
    
    /**
     * Issue #126: AbstractDataModel.getValidators() 
     * was throwing ClassCastException.
     *
     */
    public void testValidatorAccess() {
        DataModel dataModel = TestDataModelFactory.createDataModelWithValidator(false);
        dataModel.getValidators();
    }
    
    public static String statusTypes[] = {
        "new", "existing", "cancelled"
    };
    public static String states[] = {
    "Alabama", "Alaska", "Arizona", "Arkansas",
    "California", "Colorado", "Connecticut",
    "Delaware", "Florida", "Georgia", "Hawaii",
    "Idaho", "Illinois", "Indiana", "Iowa",
    "Kansas", "Kentucky", "Louisiana",
    "Maine", "Mariland", "Massachusetts", "Michegan",
    "Minnesota", "Mississippi", "Missouri", "Montana",
    "Nebraska", "Nevada", "New Hampshire", "New Jersey",
    "New Mexico", "New York", "North Carolina", "North Dakota",
    "Ohio", "Oklahoma", "Oregan", "Pennsylvania",
    "Rhode Island", "South Carolina", "South Dakota",
    "Tennessee", "Texas", "Utah", "Vermont", "Virgina",
    "Washington", "West Virginia", "Wisconsin", "Wyoming" };

    public static DefaultDataModel createPersonModel() {
        DefaultDataModel personModel = new DefaultDataModel();

        StringMetaData stringMetaData = new StringMetaData("firstname", "First Name");
        stringMetaData.setMinValueCount(1); // required
        stringMetaData.setDisplayWidth(14);
        stringMetaData.setMinLength(1);
        stringMetaData.setMaxLength(24);
        personModel.addField(stringMetaData);

        stringMetaData = new StringMetaData("middleinitial", "Middle Initial");
        stringMetaData.setDisplayWidth(2);
        stringMetaData.setMinLength(1);
        stringMetaData.setMaxLength(2);
        personModel.addField(stringMetaData);

        stringMetaData = new StringMetaData("lastname", "Last Name");
        stringMetaData.setMinValueCount(1); // required
        stringMetaData.setDisplayWidth(14);
        stringMetaData.setMinLength(1);
        stringMetaData.setMaxLength(24);
        personModel.addField(stringMetaData);

        NumberMetaData numberMetaData = new NumberMetaData("age", Integer.class,
            "Age");
        numberMetaData.setMinimum(new Integer(0));
        numberMetaData.setMaximum(new Integer(110));
        personModel.addField(numberMetaData);

        MetaData metaData = new MetaData("married", Boolean.class, "Married");
        personModel.addField(metaData);

        numberMetaData = new NumberMetaData("customerid", Integer.class, "Customer ID");
        numberMetaData.setReadOnly(true);
        personModel.addField(numberMetaData, new Integer(112));

        EnumeratedMetaData enumMetaData = new EnumeratedMetaData("status", String.class, "Status");
        enumMetaData.setEnumeration(statusTypes);
        personModel.addField(enumMetaData, "new");

        stringMetaData = new StringMetaData("comments", "Comments");
        stringMetaData.setMaxLength(100);
        stringMetaData.setMultiLine(true);
        personModel.addField(stringMetaData);

        return personModel;

    }

    public static DataModel createFilledPersonModel(boolean valid) {
        DataModel model = createPersonModel();
        model.setValue("firstname", "Melissa");
        model.setValue("lastname", "Etheridge");
        if (valid) {
            model.setValue("age", new Integer(46));
        } else {
            model.setValue("age", new Integer(-2));
        }
        model.setValue("married", Boolean.TRUE);
        return model;
    }
    public static DefaultDataModel createAddressModel() {
        DefaultDataModel addressModel = new DefaultDataModel();

        StringMetaData metaData = new StringMetaData("street", "Street");
        metaData.setMinValueCount(1);
        metaData.setDisplayWidth(18);
        metaData.setMaxLength(32);
        addressModel.addField(metaData);

        metaData = new StringMetaData("city", "City");
        metaData.setMinValueCount(1);
        metaData.setDisplayWidth(16);
        metaData.setMaxLength(24);
        addressModel.addField(metaData);

        EnumeratedMetaData enumMetaData =
            new EnumeratedMetaData("state", String.class, "State");
        enumMetaData.setEnumeration(states);
        enumMetaData.setMinValueCount(1);
        addressModel.addField(enumMetaData);

        metaData =
            new StringMetaData("zipcode", "Zipcode");
        metaData.setMinLength(5);
        metaData.setMaxLength(9);
        metaData.setMinValueCount(1);
        addressModel.addField(metaData);

        return addressModel;
    }

    public static DefaultDataModel createNestedPersonModel() {
        DefaultDataModel personModel = createPersonModel();
        MetaData metaData = new MetaData("address", DataModel.class, "Address");
        personModel.addField(metaData, createAddressModel());
        return personModel;
    }

    public void testDummy() {

    }

    //public void testDefaultDataModelConstructors()
    //public void testDefaultDataModelAddField()
    //public void testDefaultDataModelMetaData()
    //public void testDefaultDataModelGetValue()
    //public void testDefaultDataModelSetValue()
    //public void testDefaultDataModelValidators()


    public static void main(String args[]) {
        DataModelUnitTest test = new DataModelUnitTest();

    }

}
