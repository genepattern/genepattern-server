/*
 * $Id: DOMAdapterUnitTest.java,v 1.1 2004/08/05 01:29:18 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.awt.Dimension;
import java.awt.Point;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.w3c.dom.Document;
import org.jdesktop.swing.JXTreeTable;

import org.jdesktop.swing.treetable.TreeTableModel;

/**
 * DOMAdapterUnitTest
 *
 * @author Ramesh Gupta
 */
public class DOMAdapterUnitTest extends junit.framework.TestCase {

    public DOMAdapterUnitTest() {
	super("DOMAdapterUnitTest");
    }

    public void testDummy() {
	// XXX placeholder test. replace with a real unit test
    }

    public static void main(String[] args) {
        try {
	    // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception ex) {

        }

        final TestCase[] testCases = createTestCases();
        if (testCases.length > 0) {
            // Automatically exit after last window is closed.
            testCases[testCases.length - 1].frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            Point location = testCases[0].frame.getLocation();

            for (int i = testCases.length - 1; i >= 0; i--) {
                location.translate(30, 30); // stagger frames
                testCases[i].frame.setTitle("DOMAdapter Unit Test " + (i + 1));
                testCases[i].frame.setLocation(location);
                testCases[i].frame.setVisible(true);
            }
        }
    }

    /**
     * For unit testing only
     * @return
     */
    private static TestCase[] createTestCases() {
        Document        dom = null;
        DocumentBuilderFactory    dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        dbf.setIgnoringComments(true);
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            dom = db.parse("test/XMLBugQuery4.xml");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        final DOMAdapter treeTableModel = new DOMAdapter();
        treeTableModel.bind(dom);

        final TestCase[] testCases = new TestCase[] {
            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setShowGrid(true);
                    return treeTable;
                }
            },
        };
        return testCases;
    }

    private static abstract class TestCase {

        public TestCase(TreeTableModel model) {
            this.model = model;
            this.frame = wrap(define());
        }

        public abstract JComponent define();

        public JFrame wrap(JComponent component) {
            final JFrame frame = new JFrame();
            final JScrollPane scroller = new JScrollPane(component);
            scroller.setPreferredSize(new Dimension(600, 304));
            frame.getContentPane().add(scroller);
            frame.pack();
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            return frame;
        }

        public final TreeTableModel    model;
        public final JFrame            frame;
    }
}
