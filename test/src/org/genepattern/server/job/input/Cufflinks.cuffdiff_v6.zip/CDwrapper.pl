use strict;
use warnings;

use IPC::Open3;
use IO::Select;
use IO::Handle;
use File::Path;
use File::Basename;
use Getopt::Long;
use File::Spec::Functions qw(catfile);
use Cwd;
use Cwd qw(abs_path);

my $plugindir = "";
my $groupFileList = "";
my $gtf = "";
my $sampleLabels = "";
my $timeSeries = "false";
my $normMethod = "geometric";
my $fpkmScaling = "compatible-hits";
my $fragBiasCorrect = "";
my $multiReadCorrect = "true";
my $minAlignmentCount = 10;
my $fdr = 0.05;
my $maskFile ="";
my $numThreads = 8;
my $skipDiffExp = "false";
my $libType = "";
my $result = GetOptions ("plugindir:s"   => \$plugindir,
                         "groupfile:s"   => \$groupFileList,
                         "gtf:s"         => \$gtf, 
                         "s:s"           => \$sampleLabels,
                         "T:s"           => \$timeSeries,
                         "N:s"           => \$normMethod,
                         "fpkmScaling:s" => \$fpkmScaling,
                         "b:s"           => \$fragBiasCorrect,
                         "u:s"           => \$multiReadCorrect,
                         "c:s"           => \$minAlignmentCount,
                         "fdr:s"         => \$fdr,
                         "M:s"           => \$maskFile,
                         "p:s"           => \$numThreads,
                         "skipDiffExp:s"      => \$skipDiffExp,
                         "libType:s"     => \$libType
                         );                             

wr_die("A GTF file must be specified") unless $gtf !~ /^\s*$/;

# Set the PATH to include the location of the plug-in
$ENV{PATH} .= ':' . $plugindir;

# Build command line call to cuffdiff
my @cmd = ();
push(@cmd, catfile($plugindir,"cuffdiff"), "-v", "--no-update-check");

# List to gather symlinks for later cleanup
my @symlinks = ();

if ($timeSeries eq "true") { push(@cmd, "-T"); }
if ($normMethod eq "geometric") {
    push(@cmd, "--geometric-norm"); 
}
elsif ($normMethod eq "quartile") {
    push(@cmd, "-N");
}
elsif ($normMethod eq "classic-fpkm") {
    push(@cmd, "--raw-mapped-norm"); 
}
else {
    # Should never happen...
    wr_die("Invalid value '$normMethod' provided for normalization.method");
}

if ($fpkmScaling eq "compatible-hits") { push(@cmd, "--compatible-hits-norm"); }
else { push(@cmd, "--total-hits-norm"); }

if ($fragBiasCorrect !~ /^\s*$/) {
    # The tool will try to regenerate the FASTA index if it is not present.  For
    # non-local files, create a symlink so that this file is created in the
    # jobResults dir rather than out on the filesystem.
    push (@cmd, "-b");
    my ($basename,$dir,$ext) = fileparse($fragBiasCorrect);
    my $name = $basename . $ext;

    # Don't create a symlink if $dir resolves to the current working dir.
    my $jobResultsDir = getcwd();
    my $dirPath = abs_path($dir);

    # If the file is local, use it as-is (unless it has spaces in the name)
    if ($jobResultsDir eq $dirPath && $name !~ / /) {
        push(@cmd, $fragBiasCorrect);
    }
    else {
        # Otherwise make a symlink to the file
        $name =~ s/ /_/g; # Replace any spaces with '_'.
        symlinkInputFile($fragBiasCorrect, $name);
    }
}
if ($multiReadCorrect eq "true") { push(@cmd, "-u") }
if ($minAlignmentCount !~ /^\s*$/) { 
    wr_die("min.alignment.count must be an integer") unless ($minAlignmentCount =~ /^\d+$/);
    push(@cmd, "-c", $minAlignmentCount);
}
if ($fdr !~ /^\s*$/) {
    wr_die("FDR must be a float") unless ($fdr =~ /^\d*\.?\d+$/);
    push(@cmd, "--FDR", $fdr);
}
if ($numThreads !~ /^\s*$/) { 
    wr_die("num.threads must be a positive integer") unless ($numThreads =~ /^\d+$/);
    if ($numThreads > 8) { $numThreads = 8; }
    push(@cmd, "-p", $numThreads);
}
if ($maskFile !~ /^\s*$/) { push(@cmd, "-M", $maskFile); }

if ($sampleLabels !~ /^\s*$/ && -e $sampleLabels)
{
    my $labelList = "";
    my $sep = "";
    open(my $LABELS, "<", $sampleLabels) or wr_die("Could not open file containing labels for samples: $sampleLabels");
    foreach my $line (<$LABELS>)
    {
        # Strip leading/trailing whitespace
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;
        if ($line !~ /^\s*$/) { 
            $labelList .= $sep . $line;
            $sep = ","; 
        }
    }
    close($LABELS) or warn "close failed $!";
    if ($labelList ne "") { push(@cmd, "-L", $labelList); }
}

if ($skipDiffExp eq "true") { push(@cmd, "--no-diff"); }

if ($libType eq "fr-unstranded") {
    push(@cmd, "--library-type", "fr-unstranded");
} elsif ($libType eq "fr-firststrand") {
    push(@cmd, "--library-type", "fr-firststrand");
} elsif ($libType eq "fr-secondstrand") {
    push(@cmd, "--library-type", "fr-secondstrand");
} elsif ($libType eq "ff-unstranded") {
    push(@cmd, "--library-type", "ff-unstranded");
} elsif ($libType eq "ff-firststrand") {
    push(@cmd, "--library-type", "ff-firststrand");
} elsif ($libType eq "ff-secondstrand") {
    push(@cmd, "--library-type", "ff-secondstrand");
} elsif ($libType eq "transfrags") {
    push(@cmd, "--library-type", "transfrags");
}
# else pass no library type value

if (@ARGV) {
    print "Use of additional options detected:  @ARGV\n";
    print "WARNING: these options are not directly supported by the module and may lead to unpredictable results.  Please consult the Cufflinks manual for troubleshooting.\n";
    
    # Tokenize the ARGV strings and add these items to @cmd.  This must be split because otherwise the
    # arguments are clumped together with the switches in a single string (e.g. '--foobar 12'
    # instead of '--foobar' '12') and are thus unrecognized.
    foreach my $arg (@ARGV)
    {
       my @opts = split ' ', $arg; 
       push(@cmd, @opts);
    }
}

if ($gtf !~ /^\s*$/) { push(@cmd, $gtf); }

if($groupFileList !~ /^\s*$/)
{
    my $firstLine = 1;
    my @listOfFiles = ();
    my @conditionLabels = ();
    my $numConditions = 0;
    my %groups = ();
    open(my $CONFIG, "<", $groupFileList) or wr_die("Could not open aligned files.");
    foreach my $line (<$CONFIG>)
    {
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;
        if ($line !~ /^\s*$/)
        {
            my @values = split(/\t/, $line);
            my $valuesLength = @values;
            #always skip the first line for group file list
            #and any lines that start with #
            my $commentTag = "#";
            if(($firstLine && $valuesLength > 1) || $line =~ /^$commentTag/)
            {
                $firstLine = 0;
                next;
            }

            if($valuesLength > 1)
            {
                my $group = $values[1];
                my $fileName = $values[0];

                if(!(exists $groups{$group}))
                {
                   @{$groups{$group}} = ();
                   if($group ne "")
                   {
                       push(@conditionLabels, $group);
                       $numConditions++;
                   }
                }

                push(@{$groups{$group}}, $fileName);
            }
            else
            {
                #keep track of all files found from a
                #non-group file list
                #this is here for backwards compatibility
                # for pre GP 3.8.0 servers
                push(@listOfFiles, $line);
            }
        }
    }
    close($CONFIG) or warn "close failed $!";

    #check if all conditions were given a label
    #and labels were not already defined in the sample labels argument
    my $conditionLabelsLength = @conditionLabels;
    if($numConditions > 1 && $numConditions == $conditionLabelsLength)
    {
        if (!($sampleLabels !~ /^\s*$/ && -e $sampleLabels))
        {
            splice(@cmd, 1, 0, "-L", join(",", @conditionLabels));
        }
    }

    #if only one file was found then assume it is a file with
    #one condition per line and replicates separated by commas
    #add the files to groups hash
    if(scalar(@listOfFiles) == 1)
    {
        my $listFile = $listOfFiles[0];
        my $firstFile = 1;
        open(my $CONFIG, "<", $listFile) or wr_die("Could not open $listFile.");
        foreach my $line (<$CONFIG>) {
            $line =~ s/^\s+//;
            $line =~ s/\s+$//;
            if ($line !~ /^\s*$/) {
                if ($firstFile) { $firstFile = 0; }
                push(@cmd, $line);
            }
        }
        close($CONFIG) or warn "close failed $!";
        wr_die("No files present in $listFile") if $firstFile;
    }
    elsif(scalar(@listOfFiles) > 1)
    {
        #this must have been a non-group filelist containing
        # two sam or bam files with one per line
        #with no condition names defined
        my $alignedFile;
        foreach $alignedFile (@listOfFiles)
        {
            push(@cmd, $alignedFile);
        }
    }
    elsif($numConditions > 1) #if two or more conditions found
    {
        my($groupName, @fileNames);

        # Process the groups in the same order they were found in the file
        foreach $groupName ( @conditionLabels )
        {
            my @fileNames = @{$groups{$groupName}};

            push(@cmd, join(",", @fileNames));
        }
    }
    elsif($numConditions == 1)
    {
        wr_die("Only one condition found in $groupFileList.  If conditions are specified there must be more than one.");
    }
    else
    {
        wr_die("No samples were found in $groupFileList");
    }
}

#output command line to a separate file
open (CMDLINEFILE, '> cmdline.log');
print CMDLINEFILE "Command: @cmd\n";

# Execute cuffdiff and capture stdout and stderr
print "\nCommand:\n@cmd", "\n\n";

my $Pin  = new IO::Handle;       $Pin->fdopen(10, "w");
my $Pout = new IO::Handle;       $Pout->fdopen(11, "r");
my $Perr = new IO::Handle;       $Perr->fdopen(12, "r");
my $Proc = open3($Pin, $Pout, $Perr, @cmd);

my $sel = IO::Select->new();
$sel->add($Perr, $Pout);

# Note that we re-route output on STDERR to STDOUT.  The underlying tool uses STDERR for normal output.
while (my @ready = $sel->can_read)
{
    foreach my $handle (@ready)
    {
        if (fileno($handle) == fileno($Perr))
        {
            # process has printed to stder
            my ($count, $data);
            $count = sysread($handle, $data, 1024);
            if ($count == 0)
            {
                $sel->remove($handle);
                next;
            }
            if ($data =~ m/error/i)  #if stderr output looks like an error message, write to stderr
             {
                  print STDERR $data;
                  if ($data =~ m/sqrt\(det\(cov\)\) == 0,/i) {
                         print STDERR "This error may be caused by too little data in complex genes.\n";
                    }
            }
            else
            {
                  print STDOUT $data;
            }
        }
        else
        {
            # process has printed to stdout
            my ($count, $data);
            $count = sysread($handle, $data, 1024);
            if ($count == 0)
            {
                $sel->remove($handle);
                next;
            }
            print STDOUT $data;
        }
    }
}

close($Perr);
close($Pout);

waitpid($Proc, 0);

# Delete symlinked input file(s)
for my $filename (@symlinks) {
    if (-e $filename) {
        unlink($filename);
    }
}

exit(0);

# Subroutine for symlinking
sub symlinkInputFile {
    my ($fullPath, $name) = @_;
    
    # Create a symlink to the file in the jobResults directory.
    # Running only on Mac/Linux, so we know 'symlink' command is present.
    # Make the link and store it for later cleanup
    symlink($fullPath,$name) or wr_die("Trouble during set up.  Could not create symlink '$name' for '$fullPath'");
    push(@symlinks, $name);
    
    # Put it in cmd to be processed
    push(@cmd, $name);
}

# More user-friendly errors than Perl's 'die' for use in the context of a wrapper script.
sub wr_die {
    print STDERR @_, "\n\n";
    exit(1);
}