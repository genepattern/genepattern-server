#!/usr/bin/perl

use Getopt::Long;

GetOptions (\%options,  "singleFile=s",
                        "fileListFile=s");

if($options{singleFile} !~ /^\s*$/)
{
    print "Single file: $options{singleFile}\n";
}

if($options{fileListFile} !~ /^\s*$/)
{
    print "File list file: $options{fileListFile}";
}


