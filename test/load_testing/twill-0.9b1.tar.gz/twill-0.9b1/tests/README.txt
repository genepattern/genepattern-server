These are unit tests that can be executed using 'nose', 

      http://somethingaboutorange.com/mrl/projects/nose/

You can also simply run the test-*.py scripts individually.

CTB 11/10/05
